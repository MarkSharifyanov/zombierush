"""
ZOMBIE RUSH - a reverse tower defense game (you are the zombies!)
Requires:  pip install pygame
Run:       python zombie_rush.py

Controls
  Mouse         click the buttons at the bottom to send zombies
  1-5, TAB      hotkeys for the unit buttons of the open tab; TAB switches Normal / Custom tab
  R             toggle all tower range circles (hover a tower to see its range)
  SPEED button  (bottom right) toggles 2x game speed
  Main menu     UPGRADES: spend coins on permanent zombie upgrades
                CUSTOM ZOMBIES: buy special zombies (then send them for $ in matches)
                ACHIEVEMENTS: one-time coin rewards
  ESC           leave the match (back to menu, no coins)
  F11           toggle full screen / window (the game starts full screen on any display)
"""
import asyncio, pygame, sys, math, json, os, random

import platform
WEB = sys.platform == "emscripten"

def write_save(data):
    text = json.dumps(data)
    if WEB:
        platform.window.localStorage.setItem("zombie_rush_save", text)
    else:
        with open(SAVE, "w") as f:
            f.write(text)

def read_save():
    """Returns the saved dict, or None if there is no save."""
    try:
        if WEB:
            text = platform.window.localStorage.getItem("zombie_rush_save")
            return json.loads(text) if text else None
        with open(SAVE) as f:
            return json.load(f)
    except Exception:
        return None

W = H = 1000
FPS = 60
START_MONEY = 300
BASE_HP = 250
TOTAL_WAVES = 10      # (easy mode; every mode sets its own total)
SAVE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "zombie_rush_save.json")

# map-roulette timings (seconds)
SPIN_T = 5.0      # wheel spinning
HOLD_T = 1.2      # wheel stopped, chosen map highlighted
AUTO_T = 9.0      # match starts automatically (or click after the reveal)
WAVE_END_DELAY = 1.5
MAX_UP = 15        # max level of every upgrade
UP_COST_MULT = 1.25
BASE_SPEED = 70.0   # normal zombie speed (px/s)
STUN_BASE_CD = 7.0  # Stunner: seconds between spits (each upgrade: -STUN_CD_STEP)
STUN_CD_STEP = 0.15
STUN_TIME = 3.0     # seconds a spat-on tower is stunned
STUN_RANGE = 250    # how close a tower must be for the Stunner to spit on it (px)
BONUS_PER = 130    # every $130 earned from kills during a match...
BONUS_COINS = 1    # ...gives this many bonus coins at the end (total rounded down)


# ------------------------------------------------------------------ maps
class Map:
    def __init__(self, name, mult, col, path, slots):
        self.name, self.mult, self.col, self.path, self.slots = name, mult, col, path, slots
        self.seg, t = [], 0.0
        for a, b in zip(path, path[1:]):
            l = math.dist(a, b)
            self.seg.append((a, b, l, t))
            t += l
        self.length = t

    def pos_at(self, d):
        if d < 0:                          # still queued off-screen behind the spawn point
            a, b = self.path[0], self.path[1]
            L = math.dist(a, b) or 1.0
            return (a[0] + (b[0] - a[0]) / L * d, a[1] + (b[1] - a[1]) / L * d)
        d = min(d, self.length)
        for a, b, l, s in self.seg:
            if d <= s + l:
                t = (d - s) / l
                return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        return self.path[-1]


def slots(S1, S2, S3, M1, M2, C1, M3, M4, M5, M6):
    return dict(S1=S1, S2=S2, S3=S3, M1=M1, M2=M2, C1=C1, M3=M3, M4=M4, M5=M5, M6=M6)


EXTRA_SLOTS = {
    "Straight Line": dict(S4=(100, 400), G1=(325, 430), G2=(840, 430), G3=(570, 570), G4=(260, 570)),
    "U-Turn":        dict(S4=(400, 250), G1=(450, 420), G2=(690, 500), G3=(850, 420), G4=(600, 720)),
    "Double U-Turn": dict(S4=(100, 350), G1=(400, 720), G2=(700, 720), G3=(920, 350), G4=(80, 550)),
    "L Road":        dict(S4=(300, 180), G1=(730, 330), G2=(720, 690), G3=(880, 550), G4=(880, 350)),
    "C Road":        dict(S4=(850, 230), G1=(720, 370), G2=(500, 580), G3=(230, 475), G4=(560, 730)),
}

MAPS = [
    Map("Straight Line", 0.8, (200, 90, 70),
        [(0, 500), (900, 500)],
        slots((200, 400), (450, 600), (700, 400), (330, 600), (570, 400), (100, 600),
              (820, 600), (450, 400), (700, 600), (200, 600))),
    Map("U-Turn", 1.0, (70, 130, 200),
        [(0, 350), (780, 350), (780, 650), (300, 650)],
        slots((250, 250), (500, 500), (700, 750), (600, 250), (400, 500), (100, 500),
              (100, 250), (880, 500), (500, 750), (850, 250))),
    Map("Double U-Turn", 1.2, (140, 90, 190),
        [(0, 250), (850, 250), (850, 450), (150, 450), (150, 650), (850, 650)],
        slots((200, 350), (430, 550), (720, 350), (330, 350), (690, 550), (460, 350),
              (590, 350), (300, 550), (560, 550), (820, 550))),
    Map("L Road", 1.0, (220, 170, 60),
        [(0, 250), (800, 250), (800, 780)],
        slots((200, 350), (500, 550), (880, 450), (350, 350), (650, 350), (500, 350),
              (200, 550), (350, 550), (700, 600), (880, 650))),
    Map("C Road", 0.8, (70, 170, 120),
        [(1000, 300), (300, 300), (300, 650), (650, 650)],
        slots((400, 400), (600, 550), (850, 400), (600, 400), (800, 550), (150, 475),
              (400, 550), (150, 300), (150, 650), (500, 780))),
]

MAPS += [
    Map("Zigzag", 1.1, (232, 100, 50),
        [(0, 260), (240, 260), (400, 640), (560, 260), (720, 640), (880, 260), (880, 720)], {}),
    Map("Ice Spiral", 1.3, (120, 190, 235),
        [(0, 230), (860, 230), (860, 740), (140, 740), (140, 440), (620, 440), (620, 590)], {}),
]
HARD_SLOTS = {'Zigzag': {'S1': (54, 192), 'M1': (163, 192), 'S2': (315, 262), 'G1': (364, 379), 'M2': (281, 532), 'C1': (323, 631), 'S3': (490, 601), 'F1': (407, 449), 'M3': (456, 332), 'R1': (623, 235), 'G2': (665, 335), 'T1': (707, 435), 'S4': (624, 588), 'M4': (799, 629), 'F2': (757, 376), 'R2': (785, 309), 'G3': (954, 341), 'M5': (948, 268), 'T2': (948, 449), 'G4': (948, 557), 'M6': (948, 666)}, 'Ice Spiral': {'S1': (72, 298), 'M1': (217, 298), 'S2': (362, 298), 'G1': (506, 298), 'M2': (651, 298), 'C1': (796, 298), 'S3': (928, 310), 'F1': (928, 455), 'M3': (928, 600), 'R1': (856, 808), 'G2': (729, 808), 'T1': (584, 808), 'S4': (440, 808), 'M4': (295, 808), 'F2': (150, 808), 'R2': (72, 606), 'G3': (72, 461), 'M5': (264, 372), 'T2': (408, 372), 'G4': (553, 372), 'M6': (688, 518)}, 'Straight Line': {'F1': (252, 432), 'F2': (378, 400), 'R1': (396, 568), 'R2': (504, 432), 'T1': (648, 432), 'T2': (774, 432)}, 'U-Turn': {'F1': (127, 418), 'F2': (363, 418), 'R1': (653, 418), 'R2': (848, 568), 'T1': (699, 582), 'T2': (427, 718)}, 'Double U-Turn': {'F1': (216, 182), 'F2': (667, 182), 'R1': (918, 446), 'R2': (223, 518), 'T1': (183, 718), 'T2': (634, 750)}, 'L Road': {'F1': (109, 182), 'F2': (383, 182), 'R1': (547, 182), 'R2': (783, 182), 'T1': (732, 452), 'T2': (868, 725)}, 'C Road': {'F1': (927, 368), 'F2': (655, 232), 'R1': (418, 232), 'R2': (232, 400), 'T1': (305, 718), 'T2': (450, 718)}}
# seven more tower spots per map (extra Hard-mode towers)
HARD_SLOTS2 = {'Straight Line': {'S5': (634, 596), 'M7': (514, 626), 'M8': (874, 374), 'F3': (802, 374), 'G5': (754, 566), 'T3': (298, 374), 'R3': (754, 626)}, 'U-Turn': {'S5': (730, 284), 'M7': (578, 584), 'M8': (250, 416), 'F3': (314, 776), 'G5': (490, 284), 'T3': (458, 584), 'R3': (562, 416)}, 'Double U-Turn': {'S5': (394, 184), 'M7': (826, 184), 'M8': (58, 184), 'F3': (538, 184), 'G5': (832, 776), 'T3': (520, 716), 'R3': (280, 716)}, 'L Road': {'S5': (58, 316), 'M7': (658, 184), 'M8': (202, 184), 'F3': (866, 260), 'G5': (274, 316), 'T3': (466, 184), 'R3': (418, 316)}, 'C Road': {'S5': (534, 234), 'M7': (318, 234), 'M8': (234, 574), 'F3': (510, 366), 'G5': (750, 234), 'T3': (942, 234), 'R3': (234, 310)}, 'Zigzag': {'S5': (106, 386), 'M7': (557, 435), 'M8': (229, 405), 'F3': (178, 326), 'G5': (492, 251), 'T3': (754, 702), 'R3': (531, 517)}, 'Ice Spiral': {'S5': (370, 614), 'M7': (222, 536), 'M8': (524, 546), 'F3': (794, 672), 'G5': (236, 682), 'T3': (794, 432), 'R3': (562, 674)}}
for _m in MAPS:
    _m.slots.update(EXTRA_SLOTS.get(_m.name, {}))
    _m.slots.update(HARD_SLOTS.get(_m.name, {}))
    _m.slots.update(HARD_SLOTS2.get(_m.name, {}))

# ------------------------------------------------------------------ units
# speed is in pixels/second; zombie = 70 -> speedy 1.3x, heavy 0.7x, boss 0.8x
UNITS = {
    'zombie': dict(name='Zombie', hp=10,    speed=BASE_SPEED * 1.1, reward=55,   r=8,  col=(90, 180, 80)),
    'speedy': dict(name='Speedy', hp=8,     speed=70.0 * 1.3, reward=70,   r=7,  col=(240, 220, 70)),
    'heavy':  dict(name='Heavy',  hp=80,    speed=70.0 * 0.7, reward=125,  r=11, col=(130, 130, 190)),
    'tank':   dict(name='Tank',   hp=800,   speed=35.0,       reward=750,  r=16, col=(170, 90, 60)),
    'boss':   dict(name='BOSS',   hp=10000, speed=70.0 * 0.8, reward=1000, r=24, col=(150, 40, 170)),
    # custom zombies (bought in the Custom Zombie Shop, sent in matches for $)
    'bolt':   dict(name='Bolt',   hp=150,   speed=BASE_SPEED * 1.75, reward=300, r=9,  col=(90, 210, 255)),
    'rand':   dict(name='Random', hp=15,    speed=BASE_SPEED * 1.2,  reward=70,  r=7,  col=(255, 150, 210)),
    'stun':   dict(name='Stunner', hp=75,   speed=BASE_SPEED * 1.4,  reward=200, r=8,  col=(130, 230, 60)),
    # special zombies (Medium mode): upgradable after you have played Medium once
    'medic':  dict(name='Medic',   hp=150,   speed=BASE_SPEED * 0.9,  reward=100, r=9,  col=(236, 240, 246)),
    'bomber': dict(name='Bomber',  hp=225,   speed=BASE_SPEED * 1.1,  reward=90,  r=8,  col=(230, 120, 50)),
    'leaper': dict(name='Leaper',  hp=350,   speed=BASE_SPEED,        reward=80,  r=8,  col=(80, 210, 180)),
    'riot':   dict(name='Riot',    hp=400,   speed=BASE_SPEED * 0.8,  reward=130, r=10, col=(70, 110, 200)),
    'sboss':  dict(name='SpeedBoss', hp=8000, speed=BASE_SPEED * 1.85, reward=800, r=20, col=(230, 100, 40)),
    # custom zombies #4 and #5
    'ghost':  dict(name='Phantom', hp=200,   speed=BASE_SPEED * 1.2,  reward=250, r=9,  col=(190, 220, 255)),
    'brood':  dict(name='Brood',   hp=550,  speed=BASE_SPEED * 0.75, reward=350, r=12, col=(170, 190, 90)),
    'confuser': dict(name='Confuser', hp=1500, speed=BASE_SPEED * 1.1, reward=2500, r=12, col=(190, 90, 230)),   # mini boss you control
    # elite zombies (Hard mode): upgradable after you have played Hard once
    'splitter':   dict(name='Splitter',   hp=70,    speed=BASE_SPEED * 0.9, reward=120,  r=9,  col=(170, 110, 210)),
    'screamer':   dict(name='Screamer',   hp=50,    speed=BASE_SPEED,       reward=130,  r=8,  col=(240, 150, 150)),
    'juggernaut': dict(name='Juggernaut', hp=600,   speed=BASE_SPEED * 0.6, reward=400,  r=15, col=(120, 126, 140)),
    'overlord':   dict(name='Overlord',   hp=20000, speed=BASE_SPEED * 0.9, reward=2000, r=26, col=(200, 40, 60)),
}
ORDER = ['zombie', 'speedy', 'heavy', 'tank', 'boss', 'medic', 'bomber', 'leaper', 'riot', 'sboss',
         'splitter', 'screamer', 'juggernaut', 'overlord']
NORMAL_KINDS = ['zombie', 'speedy', 'heavy', 'tank', 'boss']
SPECIAL_KINDS = ['medic', 'bomber', 'leaper', 'riot', 'sboss']
ELITE_KINDS = ['splitter', 'screamer', 'juggernaut', 'overlord']
BOSS_KINDS = ('boss', 'sboss', 'overlord')

# special-zombie abilities
HEAL_RANGE = 200      # Medic heals zombies within this many px...
HEAL_PCT = 0.04       # ...for this fraction of their max HP per second
BOMB_RANGE = 350      # Bomber: towers this close are stunned when it dies...
BOMB_STUN = 2.5       # ...for this many seconds
LEAP_CD = 5.0         # Leaper: seconds between leaps
LEAP_TIME = 0.4       # a leap lasts this long...
LEAP_MULT = 6.0       # ...at this multiple of its normal speed
SHIELD_HP = {'riot': 120}   # Riot: shield that absorbs damage before HP
# custom zombie #4 (Phantom) and #5 (Broodmother)
PHASE_TIME = 2.0      # Phantom: seconds it is intangible (towers can't touch it)
PHASE_CD_BASE, PHASE_CD_STEP = 6.0, 0.2
BROOD_CD_BASE, BROOD_CD_STEP, BROOD_COUNT = 6.0, 0.3, 6     # Broodmother: spawns BROOD_COUNT zombies
# elite zombies
SCREAM_RANGE, SCREAM_MULT = 150, 1.3      # Screamer: zombies nearby run 1.3x faster
ARMOR = {'juggernaut': 0.25}              # Juggernaut: takes 25% less damage
SPLIT_COUNT = 2                           # Splitter: becomes 2 zombies when killed
OVERLORD_CD, OVERLORD_RANGE, OVERLORD_STUN = 9.0, 320, 2.0   # Overlord: periodic tower-stunning shockwave

# ---- upgrade store: cost of level n+1 = cost0 * 1.25^n (rounded), max level MAX_UP
UPG_KEYS = ['zombie', 'speedy', 'heavy', 'tank', 'boss', 'zspeed']
UPGRADES = {
    'zombie': dict(label='Zombie HP',    unit='zombie', cost0=10, step=0.5,  stat='hp',    suffix='HP'),
    'speedy': dict(label='Speedy HP',    unit='speedy', cost0=10, step=0.5,  stat='hp',    suffix='HP'),
    'heavy':  dict(label='Heavy HP',     unit='heavy',  cost0=15, step=1,    stat='hp',    suffix='HP'),
    'tank':   dict(label='Tank HP',      unit='tank',   cost0=20, step=50,   stat='hp',    suffix='HP'),
    'boss':   dict(label='Boss HP',      unit='boss',   cost0=40, step=500,  stat='hp',    suffix='HP'),
    'zspeed': dict(label='Zombie Speed', unit='zombie', cost0=10, step=2.5,  stat='speed', suffix='px/s'),
    # custom zombies: 10 levels each
    'bolt':   dict(label='Bolt Zombie HP',   unit='bolt', cost0=35, step=7, stat='hp', suffix='HP', max=10),
    'rand':   dict(label='Small Random HP',  unit='rand', cost0=25, step=2,  stat='hp', suffix='HP', max=10),
    'stun':   dict(label='Stunner HP',       unit='stun', cost0=30, step=2.5, stat='hp', suffix='HP', max=10),
    # special zombies (second page of the Upgrade Store, unlocked by playing Medium once)
    'medic':  dict(label='Medic HP',        unit='medic',  cost0=15, step=2,   stat='hp', suffix='HP'),
    'bomber': dict(label='Bomber HP',       unit='bomber', cost0=15, step=3,   stat='hp', suffix='HP'),
    'leaper': dict(label='Leaper HP',       unit='leaper', cost0=15, step=2,   stat='hp', suffix='HP'),
    'riot':   dict(label='Riot HP',         unit='riot',   cost0=20, step=4,   stat='hp', suffix='HP'),
    'sboss':  dict(label='Speed Boss HP',   unit='sboss',  cost0=50, step=250, stat='hp', suffix='HP'),
    # custom zombies #4 / #5 (10 levels)
    'ghost':  dict(label='Phantom HP',      unit='ghost',  cost0=40, step=10,  stat='hp', suffix='HP', max=10),
    'brood':  dict(label='Broodmother HP',  unit='brood',  cost0=50, step=25,  stat='hp', suffix='HP', max=10),
    'confuser': dict(label='Confuser HP',   unit='confuser', cost0=60, step=60, stat='hp', suffix='HP', max=10),
    # elite zombies (third page of the Upgrade Store, unlocked by playing Hard once)
    'splitter':   dict(label='Splitter HP',   unit='splitter',   cost0=25,  step=5,    stat='hp', suffix='HP'),
    'screamer':   dict(label='Screamer HP',   unit='screamer',   cost0=25,  step=4,    stat='hp', suffix='HP'),
    'juggernaut': dict(label='Juggernaut HP', unit='juggernaut', cost0=40,  step=50,   stat='hp', suffix='HP'),
    'overlord':   dict(label='Overlord HP',   unit='overlord',   cost0=100, step=1000, stat='hp', suffix='HP'),
}
ELITE_KEYS = ['splitter', 'screamer', 'juggernaut', 'overlord']
SPECIAL_KEYS = ['medic', 'bomber', 'leaper', 'riot', 'sboss']

# ---- custom zombie shop
CUSTOM_KEYS = ['bolt', 'rand', 'stun', 'ghost', 'brood', 'confuser']
ALL_KEYS = UPG_KEYS + CUSTOM_KEYS + SPECIAL_KEYS + ELITE_KEYS
CUSTOM = {
    'bolt': dict(title='Bolt Zombie', price=750, spawn_cost=400,
                 desc="A zombie with lightning speed", effect=None),
    'rand': dict(title='Small Random', price=1000, spawn_cost=125,
                 desc="Great starter zombie with 'mysterious' effects",
                 effect="When killed: spawns a normal Zombie or a Speedy"),
    'stun': dict(title='Stunner', price=1500, spawn_cost=350,
                 desc="Zombie spitting everywhere to stun nearby towers", effect=None),
    'ghost': dict(title='Phantom', price=2000, spawn_cost=400,
                  desc="A restless spirit that slips through every shot", effect=None),
    'brood': dict(title='Broodmother', price=2500, spawn_cost=450,
                  desc="Mother of all zombies - her brood never stops coming", effect=None),
    'confuser': dict(title='Confuser', price=3500, spawn_cost=2000,
                     desc="A mini boss that bends reality - YOU control his abilities", effect=None),
}


def max_up(key):
    return UPGRADES[key].get('max', MAX_UP)


def stun_cd_at(lvl):
    return round(STUN_BASE_CD - STUN_CD_STEP * lvl, 2)


def stun_cd(upg):
    return stun_cd_at(upg.get('stun', 0))


def phase_cd(upg):
    return round(PHASE_CD_BASE - PHASE_CD_STEP * upg.get('ghost', 0), 2)


def brood_cd(upg):
    return round(BROOD_CD_BASE - BROOD_CD_STEP * upg.get('brood', 0), 2)


def custom_tag(kind, upg):
    if kind == 'confuser':
        return "Abilities: P / Z keys"
    if kind == 'ghost':
        return f"Phase every {phase_cd(upg):g}s"
    if kind == 'brood':
        return f"Brood every {brood_cd(upg):g}s"
    if kind == 'bolt':
        return f"Speed {UNITS['bolt']['speed'] / UNITS['zombie']['speed']:.2f}x"
    if kind == 'rand':
        return "Splits on death"
    return f"Stun every {stun_cd(upg):g}s"


# ---- achievements (each reward is paid only once)
ACH_MAP_NAME = "Double U-Turn"      # map needed for the Easy 'win on map' achievement
MED_ACH_MAP = "Straight Line"       # map needed for the Medium 'win on map' achievement
HARD_ACH_MAP = "Ice Spiral"         # map needed for the Hard 'win on map' achievement
ACHIEVEMENTS = [
    dict(id='beat_easy',   title='Beat Easy Mode',
         sub='Destroy the enemy base in Easy mode', reward=100),
    dict(id='buy_custom',  title='Buy a Custom Zombie',
         sub='Buy any zombie in the Custom Zombie Shop', reward=450),
    dict(id='map_win',     title=f'Win Easy Mode on the {ACH_MAP_NAME} Map',
         sub=f'Destroy the base on the {ACH_MAP_NAME} map', reward=300),
    dict(id='no_boss',     title='Win Easy Mode Without Using the Boss',
         sub='Destroy the base without ever sending the Boss', reward=350),
    # secret: only listed in the Achievements tab once 'map_win' has been earned
    dict(id='fast_win',    title='Beat Easy Mode in Under 4 Waves',
         sub=f'Destroy the base within the first 3 waves on the {ACH_MAP_NAME} map', reward=800, secret=True, reveal='map_win'),
    # ---- Medium mode
    dict(id='med_win',     title='Beat Medium Mode', mode='medium',
         sub='Destroy the enemy base in Medium mode', reward=200),
    dict(id='med_no_boss', title='Win Medium Mode Without the Speed Boss', mode='medium',
         sub='Destroy the base without ever sending the Speed Boss', reward=450),
    dict(id='med_map',     title=f'Win Medium Mode on the {MED_ACH_MAP} Map', mode='medium',
         sub=f'Destroy the base on the {MED_ACH_MAP} map in Medium', reward=400),
    dict(id='med_special', title='Special Delivery', mode='medium',
         sub='Send a Medic, Bomber, Leaper and Riot in one Medium match', reward=200),
    dict(id='med_boosts',  title='Full Throttle', mode='medium',
         sub='Use all 4 boosts in one Medium match', reward=250),
    # secret: only listed once 'med_win' has been earned
    dict(id='med_fast',    title='Beat Medium Mode in Under 5 Waves', mode='medium',
         sub='Destroy the base within the first 4 waves in Medium', reward=1000, secret=True, reveal='med_win'),
    # ---- Hard mode
    dict(id='hard_win',     title='Beat Hard Mode', mode='hard',
         sub='Destroy the enemy base in Hard mode', reward=600),
    dict(id='hard_no_boss', title='Win Hard Mode Without the Overlord', mode='hard',
         sub='Destroy the base without ever sending the Overlord', reward=800),
    dict(id='hard_map',     title=f'Win Hard Mode on the {HARD_ACH_MAP} Map', mode='hard',
         sub=f'Destroy the base on the {HARD_ACH_MAP} map in Hard', reward=700),
    dict(id='hard_elite',   title='Elite Squad', mode='hard',
         sub='Send a Splitter, Screamer and Juggernaut in one Hard match', reward=400),
    dict(id='hard_fast',    title='Beat Hard Mode in Under 8 Waves', mode='hard',
         sub='Destroy the base within the first 7 waves in Hard', reward=2500, secret=True, reveal='hard_win'),
    # ---- general
    dict(id='collector',    title='Zombie Collector', mode='general',
         sub='Own every custom zombie in the shop', reward=1000),
    dict(id='cartographer', title='Cartographer', mode='general',
         sub='Destroy the enemy base on every map (any mode)', reward=1500),
]
for _a in ACHIEVEMENTS:
    _a.setdefault('mode', 'easy')
ACH = {a['id']: a for a in ACHIEVEMENTS}


def upg_value(key, lvl):
    d = UPGRADES[key]
    return UNITS[d['unit']][d['stat']] + d['step'] * lvl


def upg_cost(key, lvl):
    return int(math.floor(UPGRADES[key]['cost0'] * UP_COST_MULT ** lvl + 0.5))  # round half up


def unit_hp(kind, upg):
    return upg_value(kind, upg.get(kind, 0))


def unit_speed(kind, upg):
    return upg_value('zspeed', upg.get('zspeed', 0)) if kind == 'zombie' else UNITS[kind]['speed']

# wave -> (free units, paid units {kind: (count, price)})
Z3 = {'zombie': (3, 50), 'speedy': (4, 60)}
Z7 = {'zombie': (5, 50), 'speedy': (4, 60), 'heavy': (2, 100)}
Z10 = dict(Z7, tank=(1, 700))
WAVES = {
    1:  ({'zombie': 3}, {'zombie': (4, 50)}),
    2:  ({'zombie': 5}, {'zombie': (3, 50)}),
    3:  ({'zombie': 5, 'speedy': 2}, Z3),
    4:  ({'zombie': 7, 'speedy': 5}, Z3),
    5:  ({'zombie': 7, 'speedy': 5}, Z3),
    6:  ({'zombie': 7, 'speedy': 5}, Z3),
    7:  ({'zombie': 10, 'speedy': 5, 'heavy': 3}, Z7),
    8:  ({'zombie': 10, 'speedy': 5, 'heavy': 4}, Z7),
    9:  ({'zombie': 10, 'speedy': 5, 'heavy': 4, 'tank': 1}, Z7),
    10: ({'zombie': 10, 'speedy': 10, 'heavy': 7, 'tank': 3, 'boss': 1}, Z10),
}

# ------------------------------------------------------------------ towers
# kind -> level -> (damage, cooldown seconds, range px[, cone angle in degrees for the shotgunner])
TOWER_STATS = {
    'scout': {2: (3, 0.7, 400), 3: (4, 0.5, 450), 4: (10, 0.3, 500)},
    'mini':  {1: (1, 0.25, 350), 3: (2, 0.2, 450), 4: (4, 0.15, 550)},
    'cmd':   {4: (5, 0.4, 700)},
    'shot':  {1: (25, 1.0, 150, 50), 2: (40, 0.8, 175, 50), 3: (55, 0.65, 225, 65), 4: (120, 0.5, 275, 90)},
    # new towers (Hard mode)
    'cryo':   {1: (4, 0.6, 300), 2: (6, 0.5, 330), 3: (8, 0.45, 360), 4: (12, 0.4, 400)},
    'mortar': {1: (60, 2.5, 420), 2: (90, 2.2, 460), 3: (130, 2.0, 500), 4: (220, 1.8, 560)},
    'tesla':  {1: (14, 0.9, 260), 2: (20, 0.8, 290), 3: (28, 0.7, 320), 4: (40, 0.6, 360)},
}
TOWER_NAMES = {'scout': 'Scout', 'mini': 'Minigunner', 'cmd': 'Commander', 'shot': 'Shotgunner',
               'cryo': 'Cryo', 'mortar': 'Mortar', 'tesla': 'Tesla'}
CRYO_SLOW = {1: (0.7, 1.5), 2: (0.6, 1.8), 3: (0.5, 2.2), 4: (0.4, 2.8)}   # (speed multiplier, seconds)
MORTAR_R = {1: 55, 2: 60, 3: 70, 4: 80}                                      # shell blast radius (px)
MORTAR_FLIGHT = 0.45                                                         # shell flight time (s)
TESLA_JUMPS = {1: 2, 2: 2, 3: 3, 4: 3}                                       # extra zombies the arc jumps to
TESLA_RANGE, TESLA_FALLOFF = 100, 0.7

# what the defender does at the start of each wave (positions come from the map's slots)
TOWER_OPS = {
    1:  [('add', 'S1', 'scout', 2), ('add', 'S2', 'scout', 2)],
    2:  [('up', 'S1', 3)],
    3:  [('add', 'S3', 'scout', 2)],
    4:  [('up', 'S1', 4)],
    5:  [('up', 'S2', 3), ('up', 'S3', 3)],
    6:  [('up', 'S2', 4), ('up', 'S3', 4)],
    7:  [('add', 'M1', 'mini', 1), ('add', 'M2', 'mini', 1)],
    8:  [('up', 'M1', 3), ('up', 'M2', 3)],
    9:  [('up', 'M1', 4), ('up', 'M2', 4), ('add', 'C1', 'cmd', 4)],
    10: [('add', 'M3', 'mini', 4), ('add', 'M4', 'mini', 4),
         ('add', 'M5', 'mini', 4), ('add', 'M6', 'mini', 4)],
}

# ---- MEDIUM mode (15 waves)
# waves 1-3 = easy; waves 4-10 = easy with fewer units; waves 11-15 introduce the special zombies
M_Z4 = {'zombie': (2, 50), 'speedy': (3, 60)}
M_Z5 = {'zombie': (2, 50), 'speedy': (3, 60), 'heavy': (1, 100)}
M_Z7 = {'zombie': (2, 50), 'speedy': (1, 60), 'heavy': (1, 100)}
WAVES_MED = {
    1:  WAVES[1], 2: WAVES[2], 3: WAVES[3],
    4:  ({'zombie': 6, 'speedy': 4}, M_Z4),
    5:  ({'zombie': 5, 'speedy': 3, 'heavy': 1}, M_Z5),
    6:  ({'zombie': 5, 'speedy': 3, 'heavy': 1}, M_Z5),
    7:  ({'zombie': 7, 'speedy': 2, 'heavy': 1}, M_Z7),
    8:  ({'zombie': 7, 'speedy': 2, 'heavy': 2}, M_Z7),
    9:  ({'zombie': 7, 'speedy': 2, 'heavy': 2}, M_Z7),                        # same as 8, no tank
    10: ({'zombie': 7, 'speedy': 7, 'heavy': 5, 'tank': 2}, dict(M_Z7, tank=(1, 700))),   # no boss, 2 free tanks
    11: ({'zombie': 8, 'speedy': 4, 'heavy': 3, 'medic': 2, 'leaper': 2},
         dict(M_Z7, medic=(1, 90), leaper=(1, 70))),
    12: ({'zombie': 8, 'speedy': 5, 'heavy': 3, 'tank': 1, 'medic': 2, 'bomber': 2, 'leaper': 2},
         dict(M_Z7, medic=(1, 90), bomber=(1, 90), leaper=(1, 70))),
    13: ({'zombie': 8, 'speedy': 5, 'heavy': 4, 'tank': 1, 'medic': 2, 'bomber': 2, 'leaper': 2, 'riot': 3},
         dict(M_Z7, zombie=(3, 50), medic=(1, 90), bomber=(1, 90), riot=(1, 110))),
    14: ({'zombie': 9, 'speedy': 6, 'heavy': 4, 'tank': 2, 'medic': 3, 'bomber': 3, 'leaper': 3, 'riot': 3},
         dict(M_Z7, zombie=(3, 50), heavy=(2, 100), medic=(1, 90), bomber=(1, 90), leaper=(1, 70), riot=(2, 110))),
    15: ({'zombie': 10, 'speedy': 8, 'heavy': 5, 'tank': 2, 'medic': 3, 'bomber': 3, 'leaper': 3, 'riot': 4, 'sboss': 1},
         dict(M_Z7, zombie=(4, 50), speedy=(3, 60), heavy=(2, 100), tank=(1, 700), bomber=(1, 90), riot=(2, 110))),
}
TOWER_OPS_MED = {
    1: TOWER_OPS[1], 2: TOWER_OPS[2], 3: TOWER_OPS[3], 4: TOWER_OPS[4],
    5:  [('up', 'S2', 4), ('up', 'S3', 4)],                  # both lvl 2 scouts straight to lvl 4
    6:  [('add', 'S4', 'scout', 4)],                          # one more lvl 4 scout
    7: TOWER_OPS[7], 8: TOWER_OPS[8], 9: TOWER_OPS[9], 10: TOWER_OPS[10],
    11: [('add', 'G1', 'shot', 2), ('add', 'G2', 'shot', 2)],
    12: [('up', 'G1', 3), ('up', 'G2', 3)],
    13: [('add', 'G3', 'shot', 3)],
    14: [('up', 'G1', 4), ('up', 'G2', 4), ('up', 'G3', 4)],
    15: [('add', 'G4', 'shot', 4)],
}
# ---- HARD mode (20 waves): stronger towers (Cryo, Mortar, Tesla join the Shotgunners), elite zombies, Overlord finale
def _hw(free, paid=None):
    base = {'zombie': (3, 50), 'speedy': (3, 60), 'heavy': (2, 100)}
    base.update(paid or {})
    return (free, base)


_SP = {'medic': (1, 90), 'bomber': (1, 90), 'leaper': (1, 70), 'riot': (1, 110), 'tank': (1, 700)}
_EL = dict(_SP, splitter=(1, 120), screamer=(1, 130), juggernaut=(1, 450))
WAVES_HARD = {
    1:  ({'zombie': 5}, {'zombie': (3, 50)}),
    2:  ({'zombie': 6, 'speedy': 2}, {'zombie': (3, 50), 'speedy': (2, 60)}),
    3:  ({'zombie': 6, 'speedy': 4}, {'zombie': (3, 50), 'speedy': (3, 60)}),
    4:  _hw({'zombie': 7, 'speedy': 4, 'heavy': 1}),
    5:  _hw({'zombie': 7, 'speedy': 5, 'heavy': 2}),
    6:  _hw({'zombie': 8, 'speedy': 5, 'heavy': 2, 'medic': 1, 'leaper': 1}, _SP),
    7:  _hw({'zombie': 8, 'speedy': 6, 'heavy': 3, 'tank': 1, 'medic': 2, 'leaper': 2}, _SP),
    8:  _hw({'zombie': 9, 'speedy': 6, 'heavy': 3, 'tank': 1, 'medic': 2, 'bomber': 2, 'leaper': 2}, _SP),
    9:  _hw({'zombie': 9, 'speedy': 6, 'heavy': 3, 'tank': 1, 'medic': 2, 'bomber': 2, 'leaper': 2, 'riot': 2}, _SP),
    10: _hw({'zombie': 10, 'speedy': 8, 'heavy': 4, 'tank': 2, 'medic': 2, 'bomber': 2, 'leaper': 2, 'riot': 3}, _SP),
    11: _hw({'zombie': 10, 'speedy': 8, 'heavy': 4, 'tank': 2, 'medic': 3, 'bomber': 3, 'leaper': 3, 'riot': 3}, _SP),
    12: _hw({'zombie': 10, 'speedy': 8, 'heavy': 4, 'tank': 2, 'bomber': 2, 'riot': 3, 'splitter': 2, 'screamer': 1}, _EL),
    13: _hw({'zombie': 10, 'speedy': 8, 'heavy': 4, 'tank': 2, 'medic': 2, 'riot': 3, 'splitter': 3, 'screamer': 2, 'juggernaut': 1}, _EL),
    14: _hw({'zombie': 11, 'speedy': 9, 'heavy': 5, 'tank': 2, 'medic': 3, 'leaper': 3, 'riot': 3, 'splitter': 3, 'screamer': 2, 'juggernaut': 1}, _EL),
    15: _hw({'zombie': 11, 'speedy': 9, 'heavy': 5, 'tank': 3, 'medic': 3, 'bomber': 3, 'riot': 4, 'splitter': 3, 'screamer': 2, 'juggernaut': 2, 'boss': 1}, _EL),
    16: _hw({'zombie': 12, 'speedy': 10, 'heavy': 5, 'tank': 3, 'medic': 3, 'bomber': 3, 'leaper': 3, 'riot': 4, 'splitter': 4, 'screamer': 3, 'juggernaut': 2}, _EL),
    17: _hw({'zombie': 12, 'speedy': 10, 'heavy': 6, 'tank': 3, 'medic': 4, 'bomber': 4, 'leaper': 3, 'riot': 4, 'splitter': 4, 'screamer': 3, 'juggernaut': 2}, _EL),
    18: _hw({'zombie': 13, 'speedy': 10, 'heavy': 6, 'tank': 4, 'medic': 4, 'bomber': 4, 'leaper': 4, 'riot': 5, 'splitter': 5, 'screamer': 3, 'juggernaut': 3}, _EL),
    19: _hw({'zombie': 14, 'speedy': 12, 'heavy': 6, 'tank': 4, 'medic': 4, 'bomber': 4, 'leaper': 4, 'riot': 5, 'splitter': 5, 'screamer': 4, 'juggernaut': 3, 'sboss': 1}, _EL),
    20: _hw({'zombie': 14, 'speedy': 12, 'heavy': 7, 'tank': 4, 'medic': 4, 'bomber': 4, 'leaper': 4, 'riot': 5, 'splitter': 5, 'screamer': 4, 'juggernaut': 4, 'overlord': 1}, _EL),
}
TOWER_OPS_HARD = {
    1:  [('add', 'S1', 'scout', 3), ('add', 'S2', 'scout', 3)],
    2:  [('up', 'S1', 4), ('add', 'M1', 'mini', 1)],
    3:  [('add', 'S3', 'scout', 3)],
    4:  [('up', 'S2', 4), ('up', 'S3', 4), ('add', 'M2', 'mini', 1)],
    5:  [('up', 'M1', 3), ('up', 'M2', 3), ('add', 'F1', 'cryo', 1)],
    6:  [('add', 'S4', 'scout', 4), ('up', 'F1', 2), ('add', 'M7', 'mini', 1)],
    7:  [('up', 'M1', 4), ('up', 'M2', 4), ('add', 'G1', 'shot', 2)],
    8:  [('add', 'C1', 'cmd', 4)],
    9:  [('add', 'R1', 'mortar', 1), ('up', 'G1', 3), ('add', 'F3', 'cryo', 2)],
    10: [('add', 'M3', 'mini', 4), ('add', 'M4', 'mini', 4), ('add', 'T1', 'tesla', 2)],
    11: [('add', 'G2', 'shot', 3), ('up', 'R1', 2), ('up', 'F1', 3)],
    12: [('add', 'F2', 'cryo', 3), ('up', 'T1', 3), ('add', 'G5', 'shot', 3), ('up', 'M7', 3)],
    13: [('add', 'M5', 'mini', 4), ('add', 'M6', 'mini', 4), ('add', 'R2', 'mortar', 2)],
    14: [('up', 'G1', 4), ('up', 'G2', 4), ('up', 'R1', 3), ('up', 'R2', 3), ('add', 'T3', 'tesla', 3), ('add', 'S5', 'scout', 4)],
    15: [('add', 'T2', 'tesla', 3), ('up', 'F1', 4), ('up', 'F2', 4)],
    16: [('add', 'G3', 'shot', 4), ('up', 'T1', 4), ('up', 'T2', 4), ('add', 'M8', 'mini', 4), ('add', 'R3', 'mortar', 3)],
    17: [('add', 'G4', 'shot', 4), ('up', 'R1', 4), ('up', 'R2', 4)],
    18: [('up', 'M7', 4), ('up', 'T3', 4), ('up', 'R3', 4)],
    19: [('up', 'F3', 4), ('up', 'G5', 4)],
    20: [],
}
MODES = {
    'easy':   dict(name='Easy',   waves=WAVES,      ops=TOWER_OPS,      total=10, win_boss=150, win_clean=200, lose=50),
    'medium': dict(name='Medium', waves=WAVES_MED,  ops=TOWER_OPS_MED,  total=15, win_boss=300, win_clean=350, lose=50),
    'hard':   dict(name='Hard',   waves=WAVES_HARD, ops=TOWER_OPS_HARD, total=20, win_boss=500, win_clean=600, lose=75),
}

TOWER_DMG_MULT = 0.75   # every tower's damage is multiplied by this

# ---- Confuser (custom mini boss - its abilities are triggered by YOU)
ILLUSION_TIME = 5.0     # Illusionary Path: seconds the path stays a straight line (one use per Confuser)
ALIKE_CD = 20.0         # Zombie-Alike: cooldown (per Confuser)
ALIKE_STUN = 7.0        # ...the targeted tower is stunned this long
ALIKE_SHOOT = 4.0       # ...the hijacked tower shoots at its target(s) this long
ALIKE_LVL2 = 5          # Confuser upgrade level at which Zombie-Alike can hijack for TWO targets
SPREAD_GAP = 34         # px between zombies sent in SPREAD formation

# ---- strategy layer ---------------------------------------------------
# How each tower picks its target (this is what makes unit mixes and spacing matter)
TARGET_INFO = {
    'scout':  "Snipes the STRONGEST zombie (most HP)",
    'mini':   "Shoots the FRONT zombie (closest to your base)",
    'shot':   "Aims where the cone catches the MOST zombies",
    'cryo':   "Chills the FRONT zombie that isn't slowed yet",
    'mortar': "Lobs shells at the DENSEST group",
    'tesla':  "Zaps the FRONT zombie, then chains onward",
    'cmd':    "Boosts every other tower (no gun)",
}
# In-match research (spent with match $). Tier-2 techs need their tier-1 and are an either/or choice.
TECHS = {
    'hp1':  dict(branch='FORTITUDE', tier=1, name='Thick Skin',      cost=800, desc=["All zombies", "+8% HP"]),
    'hp2a': dict(branch='FORTITUDE', tier=2, name='Iron Hide',       cost=1400, desc=["Zombies take", "5% less dmg"], req='hp1', excl='hp2b'),
    'hp2b': dict(branch='FORTITUDE', tier=2, name='Regeneration',    cost=1400, desc=["Zombies heal", "0.8% HP / sec"], req='hp1', excl='hp2a'),
    'sp1':  dict(branch='TEMPO',     tier=1, name='Sprint Training', cost=800, desc=["All zombies", "+4% speed"]),
    'sp2a': dict(branch='TEMPO',     tier=2, name='Marathon',        cost=1400, desc=["Zombies", "+5% more speed"], req='sp1', excl='sp2b'),
    'sp2b': dict(branch='TEMPO',     tier=2, name='Evasion',         cost=1400, desc=["5% of tower", "shots miss"], req='sp1', excl='sp2a'),
    'ec1':  dict(branch='ECONOMY',   tier=1, name='Scavengers',      cost=700, desc=["Kills pay", "+6% money"]),
    'ec2a': dict(branch='ECONOMY',   tier=2, name='Bulk Orders',     cost=1200, desc=["Paid units", "cost 6% less"], req='ec1', excl='ec2b'),
    'ec2b': dict(branch='ECONOMY',   tier=2, name='Reinforcements',  cost=1200, desc=["+1 free Zombie", "every wave"], req='ec1', excl='ec2a'),
    'sb1':  dict(branch='SABOTAGE',  tier=1, name='Rust',            cost=1200, desc=["Towers deal", "4% less dmg"]),
    'sb2a': dict(branch='SABOTAGE',  tier=2, name='Static',          cost=1600, desc=["Towers fire", "6% slower"], req='sb1', excl='sb2b'),
    'sb2b': dict(branch='SABOTAGE',  tier=2, name='Blinders',        cost=1600, desc=["Towers lose", "6% range"], req='sb1', excl='sb2a'),
}
TECH_BRANCHES = ['FORTITUDE', 'TEMPO', 'ECONOMY', 'SABOTAGE']
# A random modifier hits some waves - it changes what the best plan is (shown during planning)
MODIFIERS = {
    'fog':       dict(name='Dense Fog',        desc="Towers see 20% less far",        col=(190, 205, 220), trng=0.8),
    'night':     dict(name='Night Raid',       desc="Zombies move 12% faster",        col=(150, 150, 255), spd=1.12),
    'frenzy':    dict(name='Overcharged',      desc="Towers deal 20% more damage",    col=(255, 120, 90),  tdmg=1.2),
    'rain':      dict(name='Heavy Rain',       desc="Towers fire 20% slower",         col=(120, 170, 255), tcd=1.2),
    'bounty':    dict(name='Bounty Day',       desc="Kills pay 30% more",             col=(255, 220, 90),  rew=1.3),
    'inflation': dict(name='Inflation',        desc="Paid units cost 25% more",       col=(255, 150, 150), price=1.25),
    'sale':      dict(name='Clearance Sale',   desc="Paid units cost 20% less",       col=(130, 240, 150), price=0.8),
    'tough':     dict(name='Hardened Zombies', desc="Zombies have 15% more HP",       col=(220, 170, 120), hp=1.15),
}
HEAT_MAX = 200.0        # damage-per-second that shows as full red on the planning heat-map
MOD_CHANCE = 0.6        # chance that a wave (from wave 2) has a modifier
# ---- boosts (bought with coins in the Boost Shop, used during a match with the BOOSTS panel / E key)
SPEED_SHOP = {2: 500, 3: 1000}      # game-speed unlocks (coins), bought in the Boost Shop
BOOST_KEYS = ['spit', 'boots', 'big', 'drunk']
BOOSTS = {
    'spit':  dict(name='Big Spit', price=100, col=(130, 235, 70),
                  desc=["Stuns ALL towers for 3 seconds.", "Doesn't stack while active."]),
    'boots': dict(name='Heaven Boots', price=100, col=(120, 220, 255),
                  desc=["All zombies run 1.5x faster for 5 seconds.", "Using more only adds time."]),
    'big':   dict(name='Bigger Zombies', price=150, col=(255, 170, 90),
                  desc=["Every zombie gets 2x HP but moves slower for 5s.", "With Heaven Boots: normal speed. Only time stacks."]),
    'drunk': dict(name='Drunk Towers', price=150, col=(200, 150, 255),
                  desc=["Towers miss 30% of shots + slower fire for 5s.", "Use 2: 10s / 60%.  Use 3: 15s / 90%.  Max 3."]),
}
SPIT_STUN = 3.0        # Big Spit: seconds all towers are stunned
BOOTS_TIME = 5.0       # Heaven Boots: seconds per use
BOOTS_MULT = 1.5       # ...speed multiplier
BIG_TIME = 5.0         # Bigger Zombies: seconds per use
BIG_HP = 2.0           # ...HP multiplier
BIG_SPEED = 1 / BOOTS_MULT   # ...speed multiplier (cancels out with Heaven Boots)
BIG_SCALE = 1.35       # ...how much bigger they are drawn
DRUNK_TIME = 5.0       # Drunk Towers: seconds per stack (max 3 stacks)
DRUNK_MISS = 0.30      # ...miss chance per stack
DRUNK_CD_MULT = 1.25   # ...slower fire rate while drunk

CMD_DMG_BONUS = 1.25   # +25% damage
CMD_CD_MULT = 0.90     # -10% cooldown


class Tower:
    def __init__(self, tid, kind, lvl, pos):
        self.id, self.kind, self.lvl, self.pos, self.cd = tid, kind, lvl, pos, 0.0
        self.stun = 0.0          # seconds of stun left
        self.aim = 0.0           # direction the Shotgunner last fired in (radians)
        self.fire_t = 0.0        # recoil / muzzle-flash timer
        self.hijack_t = 0.0      # >0 while a Confuser's Zombie-Alike has taken this tower over
        self.hijack_targets = [] # the towers it is shooting at

    @property
    def stats(self):
        return TOWER_STATS[self.kind][self.lvl]


class Zombie:
    def __init__(self, kind, mp, upg):
        u = UNITS[kind]
        self.map = mp
        hp = float(unit_hp(kind, upg))
        self.kind, self.hp, self.max = kind, hp, hp
        self.speed, self.reward, self.r, self.col = unit_speed(kind, upg), u['reward'], u['r'], u['col']
        self.dist = random.uniform(0, 14)
        self.stun_cd = stun_cd(upg) if kind == 'stun' else None
        self.ability_t = self.stun_cd or 0.0
        self.cd_total = self.stun_cd
        if kind == 'ghost':
            self.cd_total = phase_cd(upg)
            self.ability_t = random.uniform(2.0, self.cd_total)
        elif kind == 'brood':
            self.cd_total = brood_cd(upg)
            self.ability_t = random.uniform(2.0, self.cd_total)
        elif kind == 'overlord':
            self.cd_total = OVERLORD_CD
            self.ability_t = OVERLORD_CD * 0.6
        self.phased, self.phase_t = False, 0.0          # Phantom: intangible while True
        self.clevel = upg.get('confuser', 0) if kind == 'confuser' else 0     # Confuser upgrade level
        self.path_used = False                          # Confuser: Illusionary Path is one use per Confuser
        self.alike_cd = 0.0                             # Confuser: Zombie-Alike cooldown left
        self.tech_m = 1.0                               # HP multiplier from research already applied
        self.slow_t, self.slow_mult = 0.0, 1.0          # Cryo tower slow
        self.scream_t = 0.0                             # >0 while a Screamer is boosting this zombie
        self.off = random.uniform(-9, 9)  # small visual offset so they don't stack perfectly
        self.flash = 0.0                  # >0 while the white hit-flash is showing
        self.big = False                  # True while the 'Bigger Zombies' boost is on
        self.shield = float(SHIELD_HP.get(kind, 0))      # Riot's shield soaks damage before HP
        self.shield_max = self.shield
        self.leap_cd = random.uniform(2.0, LEAP_CD) if kind == 'leaper' else 0.0
        self.leap_t = 0.0                 # >0 while mid-leap
        self.leaped = False               # set for one frame when a leap starts (dust puff)
        self.age = 0.0                    # seconds since spawning (pop-in animation)
        self.angle = 0.0
        self.angle = self._target_angle()

    @property
    def pos(self):
        return self.map.pos_at(self.dist)

    def _target_angle(self):
        a, b = self.map.pos_at(self.dist), self.map.pos_at(self.dist + 6)
        if a == b:
            return self.angle
        return math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))

    def set_big(self, on):
        """Bigger Zombies boost: more HP while it lasts (HP fraction is kept when it ends)."""
        if on and not self.big:
            self.hp *= BIG_HP
            self.max *= BIG_HP
        elif self.big and not on:
            self.hp /= BIG_HP
            self.max /= BIG_HP
        self.big = on

    def move(self, dt, boost=1.0):
        mult = 1.0
        if self.kind == 'leaper':
            if self.leap_t > 0:
                self.leap_t -= dt
                mult = LEAP_MULT
            else:
                self.leap_cd -= dt
                if self.leap_cd <= 0:
                    self.leap_t, self.leap_cd, self.leaped = LEAP_TIME, LEAP_CD, True
        if self.slow_t > 0:
            mult *= self.slow_mult
        if self.scream_t > 0:
            mult *= SCREAM_MULT
        self.dist += self.speed * mult * boost * dt

    def animate(self, dt):
        """Smoothly turn to face the walking direction; count down the hit flash."""
        self.age += dt
        self.flash = max(0.0, self.flash - dt)
        self.scream_t = max(0.0, self.scream_t - dt)
        if self.slow_t > 0:
            self.slow_t -= dt
            if self.slow_t <= 0:
                self.slow_mult = 1.0
        diff = (self._target_angle() - self.angle + 180) % 360 - 180
        step = 540 * dt
        self.angle += max(-step, min(step, diff))


# ------------------------------------------------------------------ save
def load_save():
    coins, upg, owned, achieved, medium = 0, {k: 0 for k in ALL_KEYS}, [], [], False
    boosts = {k: 0 for k in BOOST_KEYS}
    extra = {'hard': False, 'won_maps': [], 'speeds': []}
    try:
        data = read_save()

        coins = int(data.get("coins", 0))
        for k in ALL_KEYS:
            upg[k] = max(0, min(max_up(k), int(data.get("upgrades", {}).get(k, 0))))
        owned = [k for k in data.get("owned", []) if k in CUSTOM_KEYS]
        achieved = [k for k in data.get("achievements", []) if k in ACH]
        medium = bool(data.get("medium_played", False))
        for k in BOOST_KEYS:
            boosts[k] = max(0, int(data.get("boosts", {}).get(k, 0)))
        extra['hard'] = bool(data.get("hard_played", False))
        extra['won_maps'] = [m for m in data.get("won_maps", []) if isinstance(m, str)]
        extra['speeds'] = sorted({int(v) for v in data.get("speeds", []) if int(v) in SPEED_SHOP})
    except Exception:
        pass
    return coins, upg, owned, achieved, medium, boosts, extra


def save_game(coins, upg, owned, achieved, medium=False, boosts=None, extra=None):
    try:
        write_save({"coins": coins, "upgrades": upg, "owned": owned, "achievements": achieved,
                    "medium_played": medium, "boosts": boosts or {},
                    "hard_played": (extra or {}).get('hard', False), "won_maps": (extra or {}).get('won_maps', []),
                    "speeds": (extra or {}).get('speeds', [])})
    except Exception:
        pass


# ======================================================================
#  ZOMBIE ART - every sprite is painted with code (no image files needed)
#  Each zombie is painted big (256x256) for 8 walk-cycle frames, shrunk
#  with smoothing, then rotated to face its walking direction in-game.
# ======================================================================
HI = 256              # size of the hi-res canvas a sprite is painted on
C = HI // 2           # canvas centre
FRAMES = 8            # frames in one walk cycle
ROT_STEP = 10         # degrees per cached rotation step
OUT = (18, 24, 18)    # outline colour
GOLD = (236, 196, 60)
BONE = (236, 228, 205)
SIZE = dict(zombie=72, speedy=68, heavy=84, tank=100, boss=140, bolt=72, rand=64, stun=74)   # on-screen px
SWAY = dict(zombie=5, speedy=8, heavy=3, tank=2, boss=2, bolt=8, rand=7, stun=5)             # waddle (degrees)
SPRITES, SHADOWS, SPR_CACHE = {}, {}, {}

ZSPEC = {
    'zombie': dict(skin=(120, 176, 94), cloth=(78, 98, 156), boots=(74, 50, 38), eye=(240, 235, 170), pupil=(170, 30, 30),
                   torso=(70, 108), head=34, hx=16, arm_len=60, arm_w=17, hand_r=11, swing=16, foot=26, foot_x=-26,
                   boot_len=40, boot_w=24, fingers=True),
    'speedy': dict(skin=(196, 208, 96), cloth=(232, 196, 52), boots=(235, 235, 235), eye=(255, 255, 255), pupil=(30, 30, 30),
                   torso=(58, 86), head=30, hx=16, arm_len=58, arm_w=14, hand_r=10, swing=28, foot=36, foot_x=-26,
                   boot_len=40, boot_w=22, fingers=True),
    'heavy':  dict(skin=(132, 152, 122), cloth=(122, 128, 144), boots=(60, 62, 72), eye=(255, 210, 120), pupil=(200, 40, 30),
                   torso=(98, 140), head=36, hx=14, arm_len=56, arm_w=28, hand_r=17, swing=8, foot=18, foot_x=-22,
                   boot_len=46, boot_w=34, forearm=(104, 110, 126), handcol=(150, 156, 172), noface=True),
    'tank':   dict(skin=(150, 116, 92), cloth=(192, 98, 56), boots=(70, 58, 52), eye=(255, 70, 50), pupil=(255, 230, 120),
                   torso=(112, 152), head=34, hx=12, arm_len=54, arm_w=30, hand_r=19, swing=6, foot=14, foot_x=-22,
                   boot_len=52, boot_w=38, forearm=(120, 62, 38), handcol=(90, 92, 100), noface=True),
    'boss':   dict(skin=(146, 76, 168), cloth=(66, 28, 88), boots=(36, 24, 44), eye=(255, 230, 80), pupil=(220, 20, 40),
                   torso=(104, 152), head=40, hx=14, arm_len=60, arm_w=28, hand_r=18, swing=8, foot=16, foot_x=-24,
                   boot_len=50, boot_w=34, forearm=(120, 60, 140), claws=True),
    'bolt':   dict(skin=(150, 224, 240), cloth=(52, 112, 232), boots=(255, 226, 60), eye=(255, 240, 120), pupil=(255, 255, 255),
                   torso=(62, 96), head=32, hx=16, arm_len=60, arm_w=15, hand_r=11, swing=28, foot=36, foot_x=-26,
                   boot_len=40, boot_w=22, handcol=(255, 226, 60)),
    'rand':   dict(skin=(255, 176, 208), cloth=(164, 104, 224), boots=(110, 60, 170), eye=(255, 255, 255), pupil=(40, 20, 60),
                   torso=(54, 76), head=36, hx=14, arm_len=54, arm_w=14, hand_r=10, swing=16, foot=24, foot_x=-22,
                   boot_len=34, boot_w=22, fingers=True, oddeyes=True),
    'stun':   dict(skin=(150, 222, 72), cloth=(66, 112, 52), boots=(52, 70, 40), eye=(255, 255, 120), pupil=(40, 90, 20),
                   torso=(68, 104), head=34, hx=16, arm_len=60, arm_w=17, hand_r=11, swing=16, foot=26, foot_x=-26,
                   boot_len=40, boot_w=24, fingers=True, bigmouth=True, spread=0.62),
}


# ---------- tiny drawing helpers (all coordinates are relative to the canvas centre)
def _i(v):
    return int(round(v))


def _col(c, f=1.0):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3])


def _ell(sf, col, cx, cy, w, h):
    pygame.draw.ellipse(sf, col, pygame.Rect(_i(C + cx - w / 2), _i(C + cy - h / 2), max(2, _i(w)), max(2, _i(h))))


def _circ(sf, col, cx, cy, r):
    pygame.draw.circle(sf, col, (_i(C + cx), _i(C + cy)), max(1, _i(r)))


def _ring(sf, col, cx, cy, r, w):
    pygame.draw.circle(sf, col, (_i(C + cx), _i(C + cy)), max(2, _i(r)), max(1, _i(w)))


def _poly(sf, col, pts, width=0):
    pygame.draw.polygon(sf, col, [(_i(C + x), _i(C + y)) for x, y in pts], width)


def _line(sf, col, a, b, w):
    pygame.draw.line(sf, col, (_i(C + a[0]), _i(C + a[1])), (_i(C + b[0]), _i(C + b[1])), max(1, _i(w)))


def _blob(sf, col, cx, cy, w, h, ow=5):
    """Outlined, shaded ellipse (dark rim, base tone, soft highlight)."""
    _ell(sf, OUT, cx, cy, w + 2 * ow, h + 2 * ow)
    _ell(sf, _col(col, 0.75), cx, cy, w, h)
    _ell(sf, col, cx - w * 0.04, cy - h * 0.06, w * 0.88, h * 0.84)
    _ell(sf, _col(col, 1.2), cx - w * 0.12, cy - h * 0.17, w * 0.48, h * 0.38)


def _limb(sf, col, a, b, w):
    for color, ww in ((OUT, w + 8), (col, w)):
        _line(sf, color, a, b, ww)
        _circ(sf, color, a[0], a[1], ww / 2)
        _circ(sf, color, b[0], b[1], ww / 2)


def _speckle(sf, rng, col, cx, cy, w, h, n, rmin=2, rmax=4):
    """Random dots inside an ellipse - gives skin / cloth a grainy texture."""
    for _ in range(n):
        a = rng.uniform(0, 2 * math.pi)
        d = math.sqrt(rng.random()) * 0.88
        _circ(sf, col, cx + math.cos(a) * d * w / 2, cy + math.sin(a) * d * h / 2, rng.uniform(rmin, rmax))


def _zig(sf, col, x0, x1, y, amp, w, n=5):
    pts = [(x0 + (x1 - x0) * k / n, y + (0 if k in (0, n) else (amp if k % 2 else -amp))) for k in range(n + 1)]
    for a, b in zip(pts, pts[1:]):
        _line(sf, col, a, b, w)


def _face(sf, S):
    hr, hx = S['head'], S['hx']
    odd = S.get('oddeyes')
    spread = S.get('spread', 0.4)
    for side in (-1, 1):
        er = (14 if side < 0 else 7) if odd else 10
        ex, ey = hx + hr * 0.5, side * hr * spread
        _circ(sf, OUT, ex, ey, er + 3)
        _circ(sf, S['eye2'] if (side > 0 and 'eye2' in S) else S['eye'], ex, ey, er)
        _circ(sf, S['pupil'], ex + er * 0.35, ey, er * 0.5)
        if not odd:
            _line(sf, OUT, (ex - 3, ey - side * (er + 7)), (ex + 9, ey - side * (er + 1)), 5)    # angry brow
    if not S.get('bigmouth'):
        _line(sf, OUT, (hx + hr * 0.8, -hr * 0.28), (hx + hr * 0.8, hr * 0.28), 6)
        for k in (-1, 0, 1):
            _line(sf, (236, 236, 214), (hx + hr * 0.8, k * hr * 0.15), (hx + hr * 0.8 + 5, k * hr * 0.15), 3)


# ---------- per-zombie decorations.  stage = 'back' | 'torso' | 'head' | 'front'
def deco_zombie(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':
        for sd in (-1, 1):                              # torn shirt: skin shows through
            pts = [(-26, sd * 38), (-10, sd * 31), (-2, sd * 46), (12, sd * 35), (22, sd * 49), (10, sd * 55), (-22, sd * 55)]
            _poly(sf, S['skin'], pts)
            _poly(sf, OUT, pts, 3)
        _line(sf, OUT, (-24, -12), (8, -6), 3)          # stitches
        for k in range(5):
            _line(sf, OUT, (-22 + k * 7.5, -17 + k * 1.5), (-20 + k * 7.5, -7 + k * 1.5), 3)
        _ell(sf, (126, 34, 34), 6, 20, 22, 14)          # stain
        _ell(sf, (96, 24, 24), 8, 22, 10, 6)
    elif st == 'head':
        for x, y, r in ((-20, -22, 11), (-26, -6, 12), (-24, 10, 12), (-18, 24, 10), (-4, -31, 8)):
            _circ(sf, OUT, hx + x, y, r + 3)
            _circ(sf, (84, 58, 36), hx + x, y, r)
        _line(sf, (170, 64, 64), (hx - 6, -26), (hx + 14, -16), 4)       # scar
        for k in range(3):
            _line(sf, (120, 40, 40), (hx - 1 + k * 6, -27 + k * 4), (hx + 3 + k * 6, -19 + k * 4), 3)


def deco_speedy(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        for k, y in enumerate((-34, 0, 34)):             # speed lines
            _line(sf, (255, 255, 255, 150), (-58 - k * 5, y), (-112 - k * 12, y), 6)
    elif st == 'torso':
        for sd in (-1, 1):                               # racing stripes
            _line(sf, (200, 40, 40), (-34, sd * th * 0.26), (30, sd * th * 0.26), 8)
            _line(sf, (255, 255, 255), (-34, sd * th * 0.26), (30, sd * th * 0.26), 3)
    elif st == 'head':
        _ring(sf, (210, 40, 50), hx, 0, hr * 0.8, 9)     # headband
        for sd in (-1, 1):
            _line(sf, (210, 40, 50), (hx - hr * 0.78, 0), (hx - hr - 26, sd * (10 + 9 * math.sin(phi + sd))), 7)


def deco_heavy(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':
        _blob(sf, (150, 156, 172), -6, 0, td * 0.62, th * 0.7, 4)         # chest plate
        _line(sf, OUT, (-6, -th * 0.35), (-6, th * 0.35), 4)
        for x, y in ((-28, -40), (-28, 40), (16, -40), (16, 40), (-6, -50), (-6, 50)):
            _circ(sf, OUT, x, y, 6)
            _circ(sf, (214, 218, 228), x, y, 4)
        for sd in (-1, 1):                                                 # shoulder pauldrons
            _circ(sf, OUT, 2, sd * th / 2, 29)
            _circ(sf, (118, 124, 140), 2, sd * th / 2, 25)
            _circ(sf, (172, 178, 194), -3, sd * th / 2 - 6, 12)
            _circ(sf, OUT, 2, sd * th / 2, 5)
    elif st == 'front':                                                    # helmet with a glowing visor
        _circ(sf, OUT, hx, 0, hr + 7)
        _circ(sf, (112, 118, 134), hx, 0, hr + 2)
        _circ(sf, (156, 162, 178), hx - hr * 0.2, -hr * 0.28, hr * 0.55)
        _line(sf, (80, 84, 98), (hx - hr, 0), (hx + hr * 0.2, 0), 9)
        _poly(sf, OUT, [(hx + hr * 0.35, -hr * 0.62), (hx + hr * 1.0, -hr * 0.4), (hx + hr * 1.0, hr * 0.4), (hx + hr * 0.35, hr * 0.62)])
        for sd in (-1, 1):
            _circ(sf, (255, 90, 40), hx + hr * 0.72, sd * hr * 0.22, 5)


def deco_tank(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        for sd in (-1, 1):                                                 # exhaust pipes
            _blob(sf, (110, 112, 120), -64, sd * 26, 30, 22, 4)
    elif st == 'torso':
        # hazard-striped chest plate
        _poly(sf, OUT, [(-34, -34), (30, -34), (30, 34), (-34, 34)])
        for k in range(6):
            y0 = -30 + k * 10.4
            _poly(sf, (240, 200, 40) if k % 2 == 0 else (34, 34, 38), [(-30, y0), (26, y0), (26, y0 + 10.4), (-30, y0 + 10.4)])
        for sd in (-1, 1):                                                 # shoulder cannons + spikes
            y = sd * (th / 2 + 6)
            _poly(sf, OUT, [(-24, y - 14), (70, y - 12), (70, y + 12), (-24, y + 14)])
            _poly(sf, (118, 120, 130), [(-20, y - 9), (66, y - 8), (66, y + 8), (-20, y + 9)])
            _poly(sf, (160, 162, 174), [(-20, y - 9), (66, y - 8), (66, y - 3), (-20, y - 3)])
            _poly(sf, (50, 52, 58), [(56, y - 12), (72, y - 13), (72, y + 13), (56, y + 12)])
            _circ(sf, OUT, -2, y, 24)
            _circ(sf, (96, 98, 108), -2, y, 20)
            _circ(sf, (140, 142, 154), -6, y - 5, 9)
            sp = [(-8, sd * (th / 2 + 18)), (6, sd * (th / 2 + 46)), (18, sd * (th / 2 + 18))]
            _poly(sf, (200, 200, 208), sp)
            _poly(sf, OUT, sp, 3)
    elif st == 'front':
        _circ(sf, OUT, hx, 0, hr + 7)
        _circ(sf, (150, 76, 46), hx, 0, hr + 2)
        _circ(sf, (196, 112, 70), hx - hr * 0.2, -hr * 0.28, hr * 0.5)
        for k in range(3):                                                 # crest spikes
            sp = [(hx - 4 - k * 12, -7), (hx - 22 - k * 12, 0), (hx - 4 - k * 12, 7)]
            _poly(sf, (214, 214, 222), sp)
            _poly(sf, OUT, sp, 3)
        _poly(sf, OUT, [(hx + hr * 0.3, -hr * 0.6), (hx + hr * 1.0, -hr * 0.42), (hx + hr * 1.0, hr * 0.42), (hx + hr * 0.3, hr * 0.6)])
        for sd in (-1, 1):
            _circ(sf, (255, 60, 40), hx + hr * 0.7, sd * hr * 0.24, 6)
            _circ(sf, (255, 220, 120), hx + hr * 0.72, sd * hr * 0.24, 3)


def deco_boss(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (170, 70, 220, 45), 0, 0, 122)                          # purple aura
        _circ(sf, (200, 100, 255, 55), 0, 0, 100)
        sw = math.sin(phi)
        cape = [(-30, -52), (-100, -70 + 8 * sw), (-124, 10 * math.sin(phi + 1)), (-100, 70 + 8 * math.sin(phi + 2)), (-30, 52)]
        _poly(sf, (52, 16, 74), cape)
        _poly(sf, GOLD, cape, 6)
    elif st == 'torso':
        for sd in (-1, 1):                                                 # golden shoulder spikes
            sp = [(-4, sd * (th / 2 - 2)), (16, sd * (th / 2 + 36)), (28, sd * (th / 2 - 2))]
            _poly(sf, GOLD, sp)
            _poly(sf, OUT, sp, 4)
        _line(sf, GOLD, (-40, -th / 2 + 10), (-40, th / 2 - 10), 6)       # trim
        _line(sf, GOLD, (24, -th / 2 + 10), (24, th / 2 - 10), 6)
        _circ(sf, OUT, 4, 0, 18)                                           # amulet
        _circ(sf, GOLD, 4, 0, 14)
        _circ(sf, (220, 30, 60), 4, 0, 8)
        _circ(sf, (255, 150, 160), 2, -2, 3)
    elif st == 'head':
        for sd in (-1, 1):                                                 # horns
            horn = [(hx + 0, sd * hr * 0.8), (hx + hr * 0.45, sd * (hr + 36)), (hx + hr * 0.98, sd * (hr + 22)), (hx + hr * 0.6, sd * hr * 0.66)]
            _poly(sf, BONE, horn)
            _poly(sf, OUT, horn, 4)
    elif st == 'front':                                                    # crown
        _ring(sf, GOLD, hx, 0, hr * 0.94, 9)
        for k in range(7):
            a = k * 2 * math.pi / 7 + 0.2
            bl = (hx + math.cos(a - 0.2) * hr * 0.94, math.sin(a - 0.2) * hr * 0.94)
            br = (hx + math.cos(a + 0.2) * hr * 0.94, math.sin(a + 0.2) * hr * 0.94)
            tip = (hx + math.cos(a) * hr * 1.42, math.sin(a) * hr * 1.42)
            _poly(sf, GOLD, [bl, tip, br])
            _poly(sf, OUT, [bl, tip, br], 3)
            _circ(sf, (220, 40, 60), tip[0], tip[1], 4)


def deco_bolt(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (110, 220, 255, 55), 0, 0, 112)                         # electric glow
        _circ(sf, (255, 255, 160, 60), 0, 0, 92)
        for y in (-28, 0, 28):                                             # lightning trails
            _zig(sf, (255, 240, 80, 210), -58, -124, y, 9, 5)
    elif st == 'torso':
        bolt = [(10, -38), (-18, 4), (0, 4), (-10, 38), (20, -8), (2, -8), (14, -38)]
        _poly(sf, (255, 226, 60), bolt)
        _poly(sf, OUT, bolt, 4)
    elif st == 'head':
        for k in range(7):                                                 # spiky hair
            a = math.radians(115 + k * 21.6)
            tip = (hx + math.cos(a) * hr * 1.55, math.sin(a) * hr * 1.55)
            lp = (hx + math.cos(a - 0.3) * hr * 0.8, math.sin(a - 0.3) * hr * 0.8)
            rp = (hx + math.cos(a + 0.3) * hr * 0.8, math.sin(a + 0.3) * hr * 0.8)
            _poly(sf, (255, 226, 60), [lp, tip, rp])
            _poly(sf, OUT, [lp, tip, rp], 3)
        sp = [(hx + hr * 0.1, -hr * 0.55), (hx + hr * 0.9, -hr * 0.2), (hx + hr * 0.15, -hr * 0.1)]
        _poly(sf, (255, 226, 60), sp)


def deco_rand(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':
        for x, y in ((-24, -26), (14, -30), (22, 6), (-20, 22), (4, 30), (-6, -10)):      # polka dots
            _circ(sf, (214, 170, 255), x, y, 5)
    elif st == 'head':
        for sd in (-1, 1):                                                 # fluffy hair puffs
            _circ(sf, OUT, hx - 8, sd * (hr - 2), 15)
            _circ(sf, (255, 110, 190), hx - 8, sd * (hr - 2), 12)
        for x, y in ((-6, -18), (10, 16), (-14, 8), (20, -4)):
            _circ(sf, (255, 130, 176), hx + x, y, 4)
    elif st == 'front':                                                    # party hat seen from above
        _circ(sf, OUT, hx - 10, 0, 21)
        _circ(sf, (255, 210, 70), hx - 10, 0, 18)
        _circ(sf, (255, 90, 140), hx - 10, 0, 12)
        _circ(sf, (70, 200, 255), hx - 10, 0, 9)
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):                  # '?' on the hat
            _q(sf, hx - 10 + dx, dy, OUT, 22)
        _q(sf, hx - 10, 0, (255, 255, 255), 22)


_QFONTS = {}


def _q(sf, cx, cy, col, size):
    """Draw a '?' with a font, centred on (cx, cy)."""
    try:
        f = _QFONTS.get(size)
        if f is None:
            f = _QFONTS[size] = pygame.font.SysFont("arial", size, bold=True)
        img = f.render("?", True, col)
        sf.blit(img, img.get_rect(center=(C + cx, C + cy)))
    except Exception:
        pass


def deco_stun(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (120, 230, 60, 50), 0, 0, 108)                           # toxic glow
        for x, y, r in ((-70, -14, 10), (-92, 8, 8), (-110, -6, 6)):       # slime trail
            _circ(sf, (120, 230, 60, 150), x, y, r)
    elif st == 'torso':
        for x, y, w, h in ((-14, -22, 28, 18), (12, 24, 24, 16), (-24, 18, 14, 10)):   # slime splats
            _ell(sf, OUT, x, y, w + 6, h + 6)
            _ell(sf, (164, 240, 80), x, y, w, h)
            _ell(sf, (206, 255, 130), x - 3, y - 3, w * 0.4, h * 0.35)
        for sd in (-1, 1):
            pts = [(-22, sd * 40), (-8, sd * 33), (0, sd * 48), (14, sd * 36), (8, sd * 55), (-18, sd * 55)]
            _poly(sf, S['skin'], pts)
            _poly(sf, OUT, pts, 3)
    elif st == 'head':
        for sd in (-1, 1):                                                 # swollen spit sacs
            _blob(sf, (206, 246, 120), hx + 10, sd * hr * 0.74, 32, 28, 4)
            _line(sf, (120, 190, 60), (hx + 2, sd * hr * 0.62), (hx + 18, sd * hr * 0.84), 3)
    elif st == 'front':                                                    # wide-open dripping mouth
        mx = hx + hr * 0.8
        _ell(sf, OUT, mx, 0, 30, 30)
        _ell(sf, (40, 100, 20), mx, 0, 22, 22)
        _ell(sf, (200, 70, 100), mx - 2, 3, 12, 10)
        for sd in (-1, 1):
            _circ(sf, (170, 245, 90), mx + 14, sd * 9, 5)
        _circ(sf, (170, 245, 90), mx + 18, 0, 6)


DECO = dict(zombie=deco_zombie, speedy=deco_speedy, heavy=deco_heavy, tank=deco_tank,
            boss=deco_boss, bolt=deco_bolt, rand=deco_rand, stun=deco_stun)


# ---------- Medium-mode zombies: medic, bomber, leaper, riot, speed boss
ZSPEC.update({
    'medic':  dict(skin=(176, 208, 170), cloth=(236, 240, 246), boots=(120, 130, 140), eye=(255, 255, 255), pupil=(40, 120, 60),
                   torso=(70, 108), head=34, hx=16, arm_len=60, arm_w=17, hand_r=11, swing=16, foot=26, foot_x=-26,
                   boot_len=40, boot_w=24, fingers=True),
    'bomber': dict(skin=(218, 160, 120), cloth=(190, 84, 44), boots=(60, 50, 48), eye=(255, 255, 200), pupil=(60, 20, 20),
                   torso=(76, 110), head=34, hx=16, arm_len=60, arm_w=18, hand_r=11, swing=18, foot=26, foot_x=-26,
                   boot_len=40, boot_w=26, fingers=True),
    'leaper': dict(skin=(140, 220, 196), cloth=(44, 112, 124), boots=(255, 200, 60), eye=(255, 255, 255), pupil=(20, 40, 60),
                   torso=(56, 88), head=32, hx=16, arm_len=62, arm_w=14, hand_r=10, swing=30, foot=38, foot_x=-26,
                   boot_len=44, boot_w=24, fingers=True),
    'riot':   dict(skin=(150, 150, 160), cloth=(40, 52, 84), boots=(30, 34, 44), eye=(200, 230, 255), pupil=(30, 60, 160),
                   torso=(98, 134), head=36, hx=14, arm_len=54, arm_w=26, hand_r=15, swing=8, foot=18, foot_x=-22,
                   boot_len=46, boot_w=32, forearm=(52, 66, 104), handcol=(70, 76, 94), noface=True),
    'sboss':  dict(skin=(236, 150, 60), cloth=(172, 40, 30), boots=(60, 30, 24), eye=(255, 255, 255), pupil=(255, 40, 40),
                   torso=(100, 142), head=38, hx=14, arm_len=62, arm_w=26, hand_r=17, swing=22, foot=30, foot_x=-24,
                   boot_len=50, boot_w=32, forearm=(220, 110, 40), claws=True),
})
SIZE.update(medic=74, bomber=74, leaper=68, riot=86, sboss=136, ghost=72, brood=100, splitter=74, screamer=74, juggernaut=112, overlord=164)
SWAY.update(medic=5, bomber=6, leaper=9, riot=3, sboss=4, ghost=8, brood=3, splitter=6, screamer=7, juggernaut=2, overlord=2)


def _cross(sf, cx, cy, arm, th, col, ow=4):
    for c, e in ((OUT, ow), (col, 0)):
        _poly(sf, c, [(cx - arm - e, cy - th - e), (cx + arm + e, cy - th - e), (cx + arm + e, cy + th + e), (cx - arm - e, cy + th + e)])
        _poly(sf, c, [(cx - th - e, cy - arm - e), (cx + th + e, cy - arm - e), (cx + th + e, cy + arm + e), (cx - th - e, cy + arm + e)])


def deco_medic(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':                                  # white coat with a big red cross on the back
        _line(sf, (170, 178, 194), (22, -th * 0.4), (22, th * 0.4), 3)
        _cross(sf, -8, 0, 21, 7, (214, 44, 52))
    elif st == 'head':
        for x, y in ((-18, -20), (-24, -4), (-20, 14)):          # wispy grey hair
            _circ(sf, OUT, hx + x, y, 9)
            _circ(sf, (200, 200, 205), hx + x, y, 6)
    elif st == 'front':                                # nurse cap
        _circ(sf, OUT, hx - 8, 0, 22)
        _circ(sf, (246, 246, 250), hx - 8, 0, 19)
        _cross(sf, hx - 8, 0, 11, 3.5, (214, 44, 52), 3)


def deco_bomber(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':                                  # vest of dynamite + a fizzing fuse
        for y in (-28, 0, 28):
            _poly(sf, OUT, [(-24, y - 11), (22, y - 11), (22, y + 11), (-24, y + 11)])
            _poly(sf, (206, 44, 44), [(-21, y - 8), (19, y - 8), (19, y + 8), (-21, y + 8)])
            _poly(sf, (240, 110, 100), [(-21, y - 8), (19, y - 8), (19, y - 3), (-21, y - 3)])
            for x in (-9, 8):
                _line(sf, (30, 30, 30), (x, y - 9), (x, y + 9), 4)
        pts = [(-24, 0), (-40, 10), (-54, 2), (-64, 12)]
        for a, b in zip(pts, pts[1:]):
            _line(sf, (70, 56, 40), a, b, 4)
        r = 8 + 3 * math.sin(phi * 2)
        _circ(sf, (255, 120, 30), -64, 12, r + 3)
        _circ(sf, (255, 210, 70), -64, 12, r)
        _circ(sf, (255, 255, 220), -64, 12, r * 0.45)
    elif st == 'head':                                 # spiky mohawk
        for k in range(4):
            bx = hx + hr * 0.3 - k * hr * 0.42
            tri = [(bx, -9), (bx - hr * 0.5, 0), (bx, 9)]
            _poly(sf, (70, 46, 46), tri)
            _poly(sf, OUT, tri, 3)


def deco_leaper(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':                                   # streaming scarf
        sw = math.sin(phi)
        scarf = [(-8, -10), (-60, -14 + 10 * sw), (-98, 6 + 8 * math.sin(phi + 1)), (-60, 22 + 10 * math.sin(phi + 2)), (-8, 12)]
        _poly(sf, (222, 56, 70), scarf)
        _poly(sf, OUT, scarf, 4)
    elif st == 'torso':                                # chevrons
        for k in (0, 1):
            x = -26 + k * 18
            _line(sf, (255, 200, 60), (x, -18), (x + 14, 0), 6)
            _line(sf, (255, 200, 60), (x + 14, 0), (x, 18), 6)
    elif st == 'front':                                # big goggles
        _ring(sf, (40, 40, 52), hx, 0, hr * 0.92, 7)
        for sd in (-1, 1):
            gx, gy = hx + hr * 0.38, sd * hr * 0.42
            _circ(sf, OUT, gx, gy, 15)
            _circ(sf, (40, 40, 52), gx, gy, 13)
            _circ(sf, (120, 220, 255), gx, gy, 10)
            _circ(sf, (30, 30, 40), gx + 3, gy, 4)
            _circ(sf, (255, 255, 255), gx - 3, gy - 4, 3)


def deco_riot(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':                                  # body armour
        for sd in (-1, 1):
            _blob(sf, (64, 80, 124), 4, sd * th / 2, 38, 30, 4)
        _blob(sf, (48, 60, 96), -6, 0, td * 0.6, th * 0.62, 4)
        _line(sf, OUT, (-6, -th * 0.31), (-6, th * 0.31), 4)
    elif st == 'front':                                # helmet, visor and a big riot shield
        _circ(sf, OUT, hx, 0, hr + 7)
        _circ(sf, (50, 64, 104), hx, 0, hr + 2)
        _circ(sf, (84, 102, 150), hx - hr * 0.2, -hr * 0.28, hr * 0.5)
        _line(sf, (30, 38, 64), (hx - hr, 0), (hx + hr * 0.1, 0), 8)
        _poly(sf, OUT, [(hx + hr * 0.3, -hr * 0.62), (hx + hr * 1.0, -hr * 0.45), (hx + hr * 1.0, hr * 0.45), (hx + hr * 0.3, hr * 0.62)])
        _poly(sf, (150, 214, 255), [(hx + hr * 0.38, -hr * 0.5), (hx + hr * 0.92, -hr * 0.36), (hx + hr * 0.92, hr * 0.36), (hx + hr * 0.38, hr * 0.5)])
        _line(sf, (230, 246, 255), (hx + hr * 0.5, -hr * 0.35), (hx + hr * 0.8, -hr * 0.25), 4)
        _blob(sf, (86, 146, 230), 78, 0, 30, 124, 5)
        for y in (-34, 0, 34):
            _line(sf, (232, 236, 246), (66, y), (92, y), 5)
        _circ(sf, OUT, 78, 0, 12)
        _circ(sf, (250, 210, 60), 78, 0, 9)


def deco_sboss(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':                                   # glow + rocket flames
        _circ(sf, (255, 150, 50, 45), 0, 0, 122)
        _circ(sf, (255, 220, 100, 50), 0, 0, 98)
        for k, y in enumerate((-40, 0, 40)):
            ln = 70 + 10 * math.sin(phi + k)
            _poly(sf, (255, 150, 40), [(-44, y - 14), (-44 - ln, y), (-44, y + 14)])
            _poly(sf, (255, 224, 90), [(-44, y - 7), (-44 - ln * 0.65, y), (-44, y + 7)])
    elif st == 'torso':
        for sd in (-1, 1):                             # swept-back golden fins
            fin = [(-6, sd * (th / 2 - 2)), (-46, sd * (th / 2 + 32)), (16, sd * (th / 2 + 4))]
            _poly(sf, GOLD, fin)
            _poly(sf, OUT, fin, 4)
        _line(sf, GOLD, (-30, -th / 2 + 8), (-30, th / 2 - 8), 7)
        bolt = [(10, -30), (-14, 3), (0, 3), (-8, 30), (16, -6), (2, -6), (12, -30)]
        _poly(sf, (255, 226, 60), bolt)
        _poly(sf, OUT, bolt, 4)
    elif st == 'head':                                 # flaming mohawk
        strip = [(hx + hr * 0.45, -8), (hx - hr * 1.0, -7), (hx - hr * 1.0, 7), (hx + hr * 0.45, 8)]
        _poly(sf, (255, 140, 40), strip)
        _poly(sf, OUT, strip, 3)
        for k in range(4):
            x = hx - hr * 0.3 - k * hr * 0.4
            _poly(sf, (255, 214, 60), [(x, -9), (x - hr * 0.55 - 4 * math.sin(phi + k), 0), (x, 9)])
    elif st == 'front':                                # gold band + speed visor
        _ring(sf, GOLD, hx, 0, hr * 0.92, 8)
        _poly(sf, OUT, [(hx + hr * 0.15, -hr * 0.78), (hx + hr * 1.0, -hr * 0.62), (hx + hr * 1.0, hr * 0.62), (hx + hr * 0.15, hr * 0.78)])
        for sd in (-1, 1):
            _ell(sf, (255, 255, 255), hx + hr * 0.62, sd * hr * 0.32, 16, 9)
            _ell(sf, (255, 50, 50), hx + hr * 0.68, sd * hr * 0.32, 8, 6)


DECO.update(medic=deco_medic, bomber=deco_bomber, leaper=deco_leaper, riot=deco_riot, sboss=deco_sboss)

# ---------- Phantom, Broodmother (custom) + Splitter, Screamer, Juggernaut, Overlord (elite)
ZSPEC.update({
    'ghost':  dict(skin=(214, 232, 255), cloth=(170, 200, 245), boots=(190, 214, 250), eye=(20, 30, 60), pupil=(150, 240, 255),
                   torso=(60, 96), head=34, hx=16, arm_len=64, arm_w=14, hand_r=10, swing=24, foot=20, foot_x=-34,
                   boot_len=34, boot_w=20, fingers=True),
    'brood':  dict(skin=(166, 184, 96), cloth=(112, 92, 60), boots=(80, 64, 44), eye=(255, 236, 120), pupil=(60, 20, 20),
                   torso=(108, 138), head=36, hx=20, arm_len=56, arm_w=22, hand_r=14, swing=10, foot=18, foot_x=-26,
                   boot_len=46, boot_w=30, fingers=True),
    'splitter': dict(skin=(184, 124, 220), cloth=(98, 66, 130), boots=(60, 40, 80), eye=(255, 240, 160), eye2=(150, 240, 255),
                     pupil=(60, 20, 80), torso=(72, 108), head=34, hx=16, arm_len=60, arm_w=17, hand_r=11, swing=16, foot=26,
                     foot_x=-26, boot_len=40, boot_w=24, fingers=True),
    'screamer': dict(skin=(238, 160, 160), cloth=(200, 70, 80), boots=(80, 40, 50), eye=(255, 255, 255), pupil=(30, 10, 10),
                     torso=(66, 100), head=36, hx=16, arm_len=58, arm_w=16, hand_r=10, swing=18, foot=26, foot_x=-26,
                     boot_len=38, boot_w=22, fingers=True, bigmouth=True, spread=0.62),
    'juggernaut': dict(skin=(120, 126, 140), cloth=(86, 90, 104), boots=(46, 48, 56), eye=(255, 90, 60), pupil=(255, 230, 120),
                       torso=(132, 172), head=30, hx=10, arm_len=54, arm_w=36, hand_r=22, swing=5, foot=10, foot_x=-22,
                       boot_len=58, boot_w=46, forearm=(70, 74, 86), handcol=(60, 62, 72), noface=True),
    'overlord': dict(skin=(120, 30, 46), cloth=(40, 24, 44), boots=(24, 16, 28), eye=(255, 60, 70), pupil=(255, 230, 120),
                     torso=(116, 160), head=42, hx=14, arm_len=62, arm_w=30, hand_r=20, swing=8, foot=16, foot_x=-26,
                     boot_len=56, boot_w=38, forearm=(90, 24, 40), claws=True),
})


def deco_ghost(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (180, 220, 255, 50), 0, 0, 108)
        sw = math.sin(phi)
        tail = [(-20, -28), (-70, -20 + 8 * sw), (-118, 10 * math.sin(phi + 1)), (-70, 20 + 8 * math.sin(phi + 2)), (-20, 28)]
        _poly(sf, (200, 224, 255, 170), tail)
    elif st == 'torso':
        for k in range(3):
            _line(sf, (236, 246, 255), (-34 + k * 4, -22 + k * 22), (10 + k * 4, -22 + k * 22), 3)
    elif st == 'front':
        _ell(sf, OUT, hx + hr * 0.8, 0, 14, 20)
        _ell(sf, (10, 14, 34), hx + hr * 0.8, 0, 10, 15)


def deco_brood(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        for sd in (-1, 1):                              # writhing tendrils
            for k in range(2):
                a = (-52, sd * (14 + k * 14))
                b = (-96 - k * 10, sd * (34 + k * 16) + 8 * math.sin(phi + k + sd))
                _line(sf, OUT, a, b, 12)
                _line(sf, (112, 92, 60), a, b, 8)
    elif st == 'torso':                                  # clustered egg sacs on the back
        for x, y, r in ((-30, -24, 13), (-40, 6, 15), (-28, 30, 12), (-12, -6, 11), (-46, -14, 9)):
            _circ(sf, OUT, x, y, r + 3)
            _circ(sf, (232, 232, 176), x, y, r)
            _circ(sf, (255, 255, 220), x - r * 0.3, y - r * 0.3, r * 0.35)
            for dx, dy in ((0.3, 0.2), (-0.2, 0.4), (0.1, -0.3)):
                _circ(sf, (150, 170, 80), x + dx * r, y + dy * r, 2)
    elif st == 'head':
        for dy in (-0.78, 0.78):                         # extra eyes
            for k in range(2):
                _circ(sf, OUT, hx + hr * (0.05 + k * 0.28), dy * hr, 6)
                _circ(sf, (255, 236, 120), hx + hr * (0.05 + k * 0.28), dy * hr, 4)
    elif st == 'front':
        for sd in (-1, 1):                               # mandibles
            tri = [(hx + hr * 0.7, sd * 4), (hx + hr * 1.25, sd * 16), (hx + hr * 0.9, sd * 8)]
            _poly(sf, BONE, tri)
            _poly(sf, OUT, tri, 3)


def deco_splitter(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':                                    # glowing seam down the middle
        pts = [(-38 + k * 8, (5 if k % 2 else -5)) for k in range(10)]
        for a, b in zip(pts, pts[1:]):
            _line(sf, OUT, a, b, 7)
        for a, b in zip(pts, pts[1:]):
            _line(sf, (255, 220, 255), a, b, 3)
    elif st == 'head':
        pts = [(hx - hr + 4 + k * 7, (4 if k % 2 else -4)) for k in range(10)]
        for a, b in zip(pts, pts[1:]):
            _line(sf, OUT, a, b, 6)
        for a, b in zip(pts, pts[1:]):
            _line(sf, (255, 220, 255), a, b, 2)


def deco_screamer(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'torso':
        _circ(sf, OUT, -6, 0, 20)                        # speaker grille on the chest
        _circ(sf, (60, 30, 40), -6, 0, 17)
        for r in (5, 10, 14):
            pygame.draw.circle(sf, (230, 120, 130), (_i(C - 6), _i(C)), r, 2)
    elif st == 'front':
        mx = hx + hr * 0.8
        _ell(sf, OUT, mx, 0, 34, 38)                     # huge screaming mouth
        _ell(sf, (60, 12, 20), mx, 0, 26, 30)
        _ell(sf, (220, 90, 110), mx - 3, 6, 14, 12)
        for k in range(3):                               # sound waves
            x = hx + hr + 12 + k * 14
            for a, b in (((x, -14 - k * 5), (x + 9, 0)), ((x + 9, 0), (x, 14 + k * 5))):
                _line(sf, OUT, a, b, 8)
            for a, b in (((x, -14 - k * 5), (x + 9, 0)), ((x + 9, 0), (x, 14 + k * 5))):
                _line(sf, (255, 236, 120), a, b, 4)


def deco_juggernaut(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        for sd in (-1, 1):
            _blob(sf, (70, 72, 82), -70, sd * 34, 36, 28, 4)       # exhaust stacks
    elif st == 'torso':
        _blob(sf, (112, 118, 134), -6, 0, td * 0.7, th * 0.72, 4)
        for x, y in ((-34, -44), (-34, 44), (24, -44), (24, 44), (-6, -64), (-6, 64)):
            _circ(sf, OUT, x, y, 7)
            _circ(sf, (200, 204, 214), x, y, 5)
        _circ(sf, OUT, -2, 0, 24)                                  # glowing core
        _circ(sf, (255, 120, 40), -2, 0, 20)
        _circ(sf, (255, 200, 90), -2, 0, 12)
        _circ(sf, (255, 250, 210), -2, 0, 5)
        for sd in (-1, 1):                                         # massive shoulder spikes
            sp = [(-18, sd * (th / 2 - 4)), (2, sd * (th / 2 + 46)), (22, sd * (th / 2 - 4))]
            _poly(sf, (176, 180, 190), sp)
            _poly(sf, OUT, sp, 4)
    elif st == 'front':
        _circ(sf, OUT, hx, 0, hr + 7)
        _circ(sf, (96, 100, 114), hx, 0, hr + 2)
        _circ(sf, (140, 146, 162), hx - hr * 0.2, -hr * 0.3, hr * 0.5)
        _poly(sf, OUT, [(hx + hr * 0.3, -hr * 0.5), (hx + hr * 1.0, -hr * 0.36), (hx + hr * 1.0, hr * 0.36), (hx + hr * 0.3, hr * 0.5)])
        for sd in (-1, 1):
            _circ(sf, (255, 80, 50), hx + hr * 0.68, sd * hr * 0.2, 5)


def deco_overlord(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (255, 50, 80, 45), 0, 0, 124)
        _circ(sf, (255, 120, 60, 50), 0, 0, 100)
        sw = math.sin(phi)
        cape = [(-34, -56), (-104, -72 + 8 * sw), (-124, 12 * math.sin(phi + 1)), (-104, 72 + 8 * math.sin(phi + 2)), (-34, 56)]
        _poly(sf, (90, 20, 40), cape)
        _poly(sf, (210, 50, 70), cape, 6)
    elif st == 'torso':
        for sd in (-1, 1):                                         # skull pauldrons
            _circ(sf, OUT, 4, sd * (th / 2 + 4), 30)
            _circ(sf, BONE, 4, sd * (th / 2 + 4), 26)
            _circ(sf, OUT, 12, sd * (th / 2 + 4) - 7, 6)
            _circ(sf, OUT, 12, sd * (th / 2 + 4) + 7, 6)
            _circ(sf, (255, 60, 70), 12, sd * (th / 2 + 4) - 7, 3)
            _circ(sf, (255, 60, 70), 12, sd * (th / 2 + 4) + 7, 3)
        _circ(sf, OUT, -6, 0, 26)                                  # glowing rune
        _circ(sf, (200, 30, 50), -6, 0, 22)
        tri = [(8, 0), (-14, -14), (-14, 14)]
        _poly(sf, (255, 200, 110), tri)
        _poly(sf, OUT, tri, 3)
    elif st == 'head':
        for sd in (-1, 1):                                         # great curved horns
            horn = [(hx - 6, sd * hr * 0.7), (hx + hr * 0.3, sd * (hr + 46)), (hx + hr * 1.05, sd * (hr + 34)), (hx + hr * 0.5, sd * hr * 0.6)]
            _poly(sf, (60, 30, 40), horn)
            _poly(sf, OUT, horn, 4)
            _line(sf, (230, 70, 80), (hx + hr * 0.2, sd * (hr + 4)), (hx + hr * 0.7, sd * (hr + 26)), 4)
    elif st == 'front':
        _ring(sf, (200, 40, 60), hx, 0, hr * 0.94, 9)             # flame crown
        for k in range(8):
            a = k * 2 * math.pi / 8 + 0.2
            bl = (hx + math.cos(a - 0.2) * hr * 0.94, math.sin(a - 0.2) * hr * 0.94)
            br = (hx + math.cos(a + 0.2) * hr * 0.94, math.sin(a + 0.2) * hr * 0.94)
            tip = (hx + math.cos(a) * hr * (1.4 + 0.08 * math.sin(phi + k)), math.sin(a) * hr * (1.4 + 0.08 * math.sin(phi + k)))
            _poly(sf, (255, 140, 50) if k % 2 else (255, 214, 70), [bl, tip, br])
            _poly(sf, OUT, [bl, tip, br], 3)


DECO.update(ghost=deco_ghost, brood=deco_brood, splitter=deco_splitter, screamer=deco_screamer,
            juggernaut=deco_juggernaut, overlord=deco_overlord)


# ---------- Confuser: a purple jester-wizard with a third eye and orbiting mirror shards
ZSPEC['confuser'] = dict(skin=(190, 164, 228), cloth=(72, 36, 112), boots=(40, 26, 70), eye=(255, 240, 170), pupil=(210, 40, 210),
                         torso=(92, 128), head=36, hx=14, arm_len=60, arm_w=22, hand_r=14, swing=10, foot=18, foot_x=-22,
                         boot_len=46, boot_w=30, forearm=(150, 108, 200))
SIZE['confuser'] = 98
SWAY['confuser'] = 4


def deco_confuser(sf, S, phi, rng, st):
    td, th = S['torso']
    hr, hx = S['head'], S['hx']
    if st == 'back':
        _circ(sf, (200, 120, 255, 45), 0, 0, 118)
        _circ(sf, (240, 200, 255, 50), 0, 0, 96)
        for k in range(4):                                     # orbiting mirror shards
            a = phi * 0.5 + k * math.pi / 2
            cx, cy = math.cos(a) * 104, math.sin(a) * 104
            shard = [(cx, cy - 11), (cx + 7, cy), (cx, cy + 11), (cx - 7, cy)]
            _poly(sf, (232, 214, 255), shard)
            _poly(sf, OUT, shard, 3)
    elif st == 'torso':
        for r_ in (32, 23, 14):                                # hypnotic spiral on the cloak
            _ring(sf, (232, 200, 255), -6, 0, r_, 4)
        _circ(sf, (255, 240, 170), -6, 0, 5)
        _line(sf, GOLD, (22, -th / 2 + 10), (22, th / 2 - 10), 6)
    elif st == 'head':
        for sd in (-1, 1):                                     # two-pointed jester hat
            tip = (hx - hr * 1.3, sd * (hr * 0.95 + 6 * math.sin(phi + sd)))
            horn = [(hx - 2, sd * hr * 0.25), tip, (hx - hr * 0.55, sd * hr * 0.98)]
            _poly(sf, (150, 60, 200), horn)
            _poly(sf, OUT, horn, 4)
            _circ(sf, OUT, tip[0], tip[1], 8)
            _circ(sf, GOLD, tip[0], tip[1], 6)
    elif st == 'front':
        for sd in (-1, 1):                                     # swirly eyes
            _ring(sf, (210, 40, 210), hx + hr * 0.5, sd * hr * 0.4, 6, 2)
        _circ(sf, OUT, hx - hr * 0.1, 0, 12)                  # third eye
        _circ(sf, (255, 240, 170), hx - hr * 0.1, 0, 10)
        _circ(sf, (210, 40, 210), hx - hr * 0.1 + 2, 0, 5)
        _circ(sf, (255, 255, 255), hx - hr * 0.1, -3, 2)


DECO['confuser'] = deco_confuser


def make_frame(kind, frame):
    """Paint one walk-cycle frame of a zombie (facing right) and return it shrunk to its on-screen size."""
    S = ZSPEC[kind]
    sf = pygame.Surface((HI, HI), pygame.SRCALPHA)
    phi = 2 * math.pi * frame / FRAMES
    sn = math.sin(phi)
    rng = random.Random(kind)                         # same texture on every frame
    deco = DECO[kind]
    td, th = S['torso']
    hr, hx = S['head'], S['hx']

    deco(sf, S, phi, rng, 'back')
    for side in (-1, 1):                              # boots (alternate forward/back)
        fx = S['foot_x'] + S['foot'] * math.sin(phi + (math.pi if side > 0 else 0.0))
        _blob(sf, S['boots'], fx, side * th * 0.26, S['boot_len'], S['boot_w'], 4)
    for side in (-1, 1):                              # arms swing opposite to each other
        shoulder = (0, side * (th / 2 - 8))
        hand = (S['arm_len'] - side * S['swing'] * sn, side * th * 0.34)
        elbow = ((shoulder[0] + hand[0]) / 2, (shoulder[1] + hand[1]) / 2 + side * 9)
        _limb(sf, S['cloth'], shoulder, elbow, S['arm_w'])
        _limb(sf, S.get('forearm', S['skin']), elbow, hand, S['arm_w'] * 0.9)
        hc, hrad = S.get('handcol', S['skin']), S['hand_r']
        _circ(sf, OUT, hand[0], hand[1], hrad + 4)
        _circ(sf, hc, hand[0], hand[1], hrad)
        _circ(sf, _col(hc, 1.2), hand[0] - hrad * 0.25, hand[1] - hrad * 0.3, hrad * 0.45)
        if S.get('fingers'):
            for dy in (-6, 0, 6):
                _limb(sf, hc, (hand[0] + hrad * 0.5, hand[1] + dy), (hand[0] + hrad + 9, hand[1] + dy * 1.2), 5)
        if S.get('claws'):
            for dy in (-8, 0, 8):
                _poly(sf, BONE, [(hand[0] + hrad * 0.4, hand[1] + dy - 4), (hand[0] + hrad + 16, hand[1] + dy * 1.3),
                                 (hand[0] + hrad * 0.4, hand[1] + dy + 4)])
    _blob(sf, S['cloth'], -4, 0, td, th, 5)           # torso
    _speckle(sf, rng, _col(S['cloth'], 0.72), -4, 0, td, th, 28, 2, 4)
    deco(sf, S, phi, rng, 'torso')
    for side in (-1, 1):                              # ears + head
        _circ(sf, OUT, hx - 4, side * (hr + 2), 9)
        _circ(sf, S['skin'], hx - 4, side * (hr + 2), 7)
    _blob(sf, S['skin'], hx, 0, 2 * hr, 2 * hr, 5)
    _speckle(sf, rng, _col(S['skin'], 0.8), hx, 0, 2 * hr, 2 * hr, 16, 1.5, 3)
    deco(sf, S, phi, rng, 'head')
    if not S.get('noface'):
        _face(sf, S)
    deco(sf, S, phi, rng, 'front')
    return pygame.transform.smoothscale(sf, (SIZE[kind], SIZE[kind]))


def build_sprites():
    """Pre-render every zombie (normal + white hit-flash version) and its ground shadow."""
    for kind in ZSPEC:
        normal, flash = [], []
        for f in range(FRAMES):
            fr = make_frame(kind, f)
            fl = fr.copy()
            fl.fill((45, 45, 45, 0), special_flags=pygame.BLEND_RGB_ADD)
            normal.append(fr)
            flash.append(fl)
        SPRITES[kind] = (normal, flash)
        sh = pygame.Surface((_i(SIZE[kind] * 0.8), _i(SIZE[kind] * 0.42)), pygame.SRCALPHA)
        pygame.draw.ellipse(sh, (0, 0, 0, 70), pygame.Rect(0, 0, sh.get_width(), sh.get_height()))
        SHADOWS[kind] = sh


def get_sprite(kind, frame, ang, flash=False, scale=1.0):
    """Sprite rotated to `ang` degrees (screen angle, 0 = facing right). Cached unless scaled."""
    base = SPRITES[kind][1 if flash else 0][frame % FRAMES]
    if scale != 1.0 and scale != BIG_SCALE:
        return pygame.transform.rotozoom(base, -ang, scale)
    qa = int(round(ang / ROT_STEP)) % (360 // ROT_STEP)
    key = (kind, frame % FRAMES, qa, flash, scale)
    spr = SPR_CACHE.get(key)
    if spr is None:
        if len(SPR_CACHE) > 3000:
            SPR_CACHE.clear()
        spr = pygame.transform.rotozoom(base, -qa * ROT_STEP, scale)
        SPR_CACHE[key] = spr
    return spr


# ======================================================================
#  MAP SCENERY - every map gets its own theme, painted once and cached
# ======================================================================
THEMES = {
    "Zigzag":        dict(kind='lava',   ground=(66, 48, 46),   path=(104, 96, 100)),    # volcanic field
    "Ice Spiral":    dict(kind='snow',   ground=(222, 234, 244), path=(172, 198, 222)),  # frozen tundra
    "Straight Line": dict(kind='road',   ground=(92, 140, 74),  path=(74, 76, 84)),      # highway
    "U-Turn":        dict(kind='forest', ground=(44, 98, 52),   path=(128, 102, 66)),    # forest trail
    "Double U-Turn": dict(kind='grave',  ground=(56, 76, 62),   path=(116, 114, 120)),   # graveyard
    "L Road":        dict(kind='farm',   ground=(124, 152, 64), path=(142, 110, 70)),    # farmland
    "C Road":        dict(kind='desert', ground=(218, 188, 124), path=(178, 142, 92)),   # desert canyon
}
MAP_BG = {}
CLOUDS = []


def _bc(sf, col, x, y, r):
    pygame.draw.circle(sf, col, (int(x), int(y)), max(1, int(r)))


def _be(sf, col, x, y, w, h, width=0):
    pygame.draw.ellipse(sf, col, pygame.Rect(int(x - w / 2), int(y - h / 2), max(2, int(w)), max(2, int(h))), width)


def _bp(sf, col, pts, width=0):
    pygame.draw.polygon(sf, col, [(int(a), int(b)) for a, b in pts], width)


def _bl(sf, col, a, b, w=1):
    pygame.draw.line(sf, col, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), max(1, int(w)))


def _rot(cx, cy, w, h, ang):
    ca, sa = math.cos(ang), math.sin(ang)
    return [(cx + dx * ca - dy * sa, cy + dx * sa + dy * ca) for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]


def _seg_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy)))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


# ----- scenery pieces (top-down, cartoon outlines to match the zombies)
def bg_tree(sf, rng, x, y, r, tc, sh):
    _be(sf, sh, x + 5, y + r * 0.6, r * 2.1, r * 1.3)
    _bc(sf, OUT, x, y, r + 2)
    _bc(sf, _col(tc, 0.72), x, y, r)
    for k in range(5):
        a = k * 1.257 + rng.random()
        _bc(sf, tc, x + math.cos(a) * r * 0.45, y + math.sin(a) * r * 0.45, r * 0.55)
    _bc(sf, _col(tc, 1.28), x - r * 0.25, y - r * 0.3, r * 0.34)
    for _ in range(6):
        a, d = rng.uniform(0, 6.28), rng.uniform(0.2, 0.8) * r
        _bc(sf, _col(tc, 0.6), x + math.cos(a) * d, y + math.sin(a) * d, 2)


def bg_pine(sf, rng, x, y, r, tc, sh):
    _be(sf, sh, x + 5, y + r * 0.6, r * 2.0, r * 1.2)
    for k, f in enumerate((0.7, 0.9, 1.1, 1.35)):
        rr = r * (1 - k * 0.22)
        _bc(sf, OUT, x, y, rr + 2)
        _bc(sf, _col(tc, f), x, y, rr)
    for k in range(8):
        a = k * 0.785
        _bl(sf, _col(tc, 0.62), (x, y), (x + math.cos(a) * r * 0.9, y + math.sin(a) * r * 0.9), 2)
    _bc(sf, _col(tc, 1.5), x, y, 3)


def bg_bush(sf, rng, x, y, r, tc, sh):
    _be(sf, sh, x + 3, y + r * 0.6, r * 2.2, r)
    for dx, dy, rr in ((-r * 0.5, 0, r * 0.7), (r * 0.5, 0, r * 0.7), (0, -r * 0.4, r * 0.8)):
        _bc(sf, OUT, x + dx, y + dy, rr + 2)
    for dx, dy, rr in ((-r * 0.5, 0, r * 0.7), (r * 0.5, 0, r * 0.7), (0, -r * 0.4, r * 0.8)):
        _bc(sf, tc, x + dx, y + dy, rr)
    _bc(sf, _col(tc, 1.3), x - r * 0.2, y - r * 0.6, r * 0.3)
    for _ in range(3):                                           # berries
        _bc(sf, (220, 60, 70), x + rng.uniform(-r, r) * 0.7, y + rng.uniform(-r, r) * 0.5, 2)


def bg_rock(sf, rng, x, y, r, col, sh):
    n = 7
    pts = [(x + math.cos(i * 6.283 / n) * r * rng.uniform(0.78, 1.1), y + math.sin(i * 6.283 / n) * r * rng.uniform(0.66, 1.0)) for i in range(n)]
    _be(sf, sh, x + 4, y + r * 0.55, r * 2.1, r * 1.1)
    _bp(sf, OUT, [(x + (px - x) * 1.14, y + (py - y) * 1.14) for px, py in pts])
    _bp(sf, col, pts)
    _bp(sf, _col(col, 1.22), [pts[4], pts[5], pts[6], pts[0], (x, y)])
    _bp(sf, _col(col, 0.8), [pts[1], pts[2], pts[3], (x, y)])


def bg_flower(sf, rng, x, y):
    c = rng.choice(((250, 230, 90), (250, 250, 250), (240, 120, 170), (160, 150, 255), (255, 150, 70)))
    for k in range(5):
        a = k * 1.257
        _bc(sf, c, x + math.cos(a) * 3, y + math.sin(a) * 3, 2)
    _bc(sf, (240, 190, 40), x, y, 2)


def bg_pond(sf, rng, x, y, w, h):
    _be(sf, (50, 40, 30), x, y, w + 14, h + 14)
    _be(sf, (46, 110, 170), x, y, w, h)
    _be(sf, (74, 146, 206), x - w * 0.08, y - h * 0.08, w * 0.8, h * 0.7)
    _be(sf, (160, 210, 240), x, y, w * 0.55, h * 0.45, 2)
    _be(sf, (160, 210, 240), x + w * 0.1, y, w * 0.3, h * 0.25, 2)
    for _ in range(3):                                           # lily pads
        a = rng.uniform(0, 6.28)
        px, py = x + math.cos(a) * w * 0.3, y + math.sin(a) * h * 0.3
        _bc(sf, (60, 150, 70), px, py, 6)
        _bp(sf, (46, 110, 170), [(px, py), (px + 6, py - 2), (px + 6, py + 2)])


def bg_stump(sf, rng, x, y, r, sh):
    _be(sf, sh, x + 3, y + r * 0.6, r * 2.1, r)
    _bc(sf, OUT, x, y, r + 2)
    _bc(sf, (120, 84, 50), x, y, r)
    _bc(sf, (176, 132, 82), x, y, r * 0.8)
    pygame.draw.circle(sf, (130, 92, 56), (int(x), int(y)), max(2, int(r * 0.5)), 1)
    pygame.draw.circle(sf, (130, 92, 56), (int(x), int(y)), max(2, int(r * 0.25)), 1)


def bg_log(sf, rng, x, y, ang, ln):
    a = (x - math.cos(ang) * ln / 2, y - math.sin(ang) * ln / 2)
    b = (x + math.cos(ang) * ln / 2, y + math.sin(ang) * ln / 2)
    _bl(sf, OUT, a, b, 18)
    _bl(sf, (122, 86, 52), a, b, 14)
    _bl(sf, (156, 116, 74), (a[0] - 2, a[1] - 3), (b[0] - 2, b[1] - 3), 3)
    _bc(sf, (190, 150, 100), b[0], b[1], 6)


def bg_tomb(sf, rng, x, y, sh):
    _be(sf, (44, 56, 46), x, y + 14, 30, 14)                     # dirt mound
    pygame.draw.rect(sf, OUT, pygame.Rect(int(x - 11), int(y - 14), 22, 28), border_radius=9)
    pygame.draw.rect(sf, (150, 150, 158), pygame.Rect(int(x - 9), int(y - 12), 18, 25), border_radius=8)
    pygame.draw.rect(sf, (188, 188, 196), pygame.Rect(int(x - 8), int(y - 11), 7, 22), border_radius=6)
    _bl(sf, (92, 92, 100), (x, y - 8), (x, y + 2), 2)
    _bl(sf, (92, 92, 100), (x - 4, y - 4), (x + 4, y - 4), 2)


def bg_deadtree(sf, rng, x, y, r, sh, col=(92, 70, 52)):
    _be(sf, sh, x + 4, y + 6, r * 1.6, r * 0.7)

    def branch(px, py, ang, ln, w, depth):
        ex, ey = px + math.cos(ang) * ln, py + math.sin(ang) * ln
        _bl(sf, OUT, (px, py), (ex, ey), w + 3)
        _bl(sf, col, (px, py), (ex, ey), w)
        if depth > 0:
            for da in (-0.55, 0.5):
                branch(ex, ey, ang + da + rng.uniform(-0.2, 0.2), ln * 0.68, max(2, w - 2), depth - 1)
    for k in range(4):
        branch(x, y, k * 1.57 + rng.uniform(-0.3, 0.3), r * 0.7, 6, 2)
    _bc(sf, col, x, y, 6)


def bg_pumpkin(sf, rng, x, y):
    _be(sf, (40, 50, 42), x + 2, y + 6, 22, 8)
    _be(sf, OUT, x, y, 22, 18)
    _be(sf, (240, 130, 30), x, y, 19, 15)
    _be(sf, (255, 170, 60), x - 3, y - 2, 8, 6)
    _bp(sf, (50, 40, 30), [(x - 4, y - 1), (x - 2, y - 4), (x, y - 1)])
    _bp(sf, (50, 40, 30), [(x + 1, y - 1), (x + 3, y - 4), (x + 5, y - 1)])
    _bl(sf, (60, 100, 40), (x, y - 8), (x + 2, y - 11), 3)


def bg_fence(sf, rng, x, y, ang, n):
    pts = [(x + math.cos(ang) * 20 * i, y + math.sin(ang) * 20 * i) for i in range(n)]
    for a, b in zip(pts, pts[1:]):
        _bl(sf, OUT, a, b, 6)
        _bl(sf, (170, 130, 84), a, b, 3)
    for px, py in pts:
        _bc(sf, OUT, px, py, 5)
        _bc(sf, (190, 150, 100), px, py, 3)


def bg_hay(sf, rng, x, y, r, sh):
    _be(sf, sh, x + 3, y + r * 0.6, r * 2.1, r)
    _bc(sf, OUT, x, y, r + 2)
    _bc(sf, (222, 184, 80), x, y, r)
    for k in range(1, 4):
        pygame.draw.circle(sf, (184, 142, 50), (int(x), int(y)), max(2, int(r * k / 4)), 1)
    _bc(sf, (244, 214, 120), x - r * 0.3, y - r * 0.3, r * 0.25)


def bg_barn(sf, rng, x, y):
    w, h = 110, 78
    _be(sf, (60, 80, 40), x + 8, y + 10, w + 10, h)
    pts = _rot(x, y, w + 6, h + 6, 0)
    _bp(sf, OUT, pts)
    _bp(sf, (168, 50, 44), _rot(x, y, w, h, 0))
    for i in range(1, 6):                                        # roof planks
        _bl(sf, (130, 36, 34), (x - w / 2 + i * w / 6, y - h / 2), (x - w / 2 + i * w / 6, y + h / 2), 2)
    _bl(sf, (230, 200, 190), (x - w / 2, y), (x + w / 2, y), 5)   # ridge
    _bp(sf, (205, 74, 64), _rot(x, y - h / 4, w - 4, h / 2 - 4, 0))
    for i in range(1, 6):
        _bl(sf, (150, 44, 40), (x - w / 2 + i * w / 6, y - h / 2 + 2), (x - w / 2 + i * w / 6, y - 2), 2)
    _bl(sf, (230, 200, 190), (x - w / 2, y), (x + w / 2, y), 5)


def bg_crops(sf, rng, x, y, w, h, col):
    _bp(sf, _col(col, 0.7), _rot(x, y, w + 6, h + 6, 0))
    _bp(sf, _col((110, 80, 50), 1.0), _rot(x, y, w, h, 0))
    for i in range(int(h // 12)):
        yy = y - h / 2 + 7 + i * 12
        _bl(sf, _col(col, 0.8), (x - w / 2 + 3, yy), (x + w / 2 - 3, yy), 6)
        for j in range(int(w // 10)):
            xx = x - w / 2 + 6 + j * 10
            _bc(sf, _col(col, 1.2), xx, yy - 1, 3)


def bg_cactus(sf, rng, x, y, r, sh):
    _be(sf, sh, x + 3, y + r * 0.6, r * 2, r)
    _bc(sf, OUT, x, y, r + 2)
    _bc(sf, (70, 140, 84), x, y, r)
    for k in range(8):
        a = k * 0.785
        _bl(sf, (230, 220, 150), (x + math.cos(a) * r * 0.5, y + math.sin(a) * r * 0.5), (x + math.cos(a) * r * 1.2, y + math.sin(a) * r * 1.2), 1)
    _bc(sf, (100, 170, 110), x - r * 0.25, y - r * 0.3, r * 0.3)
    _bc(sf, (240, 120, 170), x, y, 3)


def bg_skull(sf, rng, x, y):
    _bc(sf, OUT, x, y, 9)
    _bc(sf, (236, 232, 214), x, y, 7)
    _bc(sf, (50, 44, 40), x - 3, y - 1, 2)
    _bc(sf, (50, 44, 40), x + 3, y - 1, 2)
    _bl(sf, (50, 44, 40), (x - 2, y + 4), (x + 2, y + 4), 1)


def bg_bone(sf, rng, x, y, ang):
    a = (x - math.cos(ang) * 9, y - math.sin(ang) * 9)
    b = (x + math.cos(ang) * 9, y + math.sin(ang) * 9)
    _bl(sf, OUT, a, b, 6)
    _bl(sf, (236, 232, 214), a, b, 3)
    for p in (a, b):
        _bc(sf, (236, 232, 214), p[0] + 2, p[1] - 2, 3)
        _bc(sf, (236, 232, 214), p[0] - 2, p[1] + 2, 3)


def bg_dune(sf, rng, x, y, w, h, col):
    _be(sf, _col(col, 1.08), x, y, w, h)
    _be(sf, _col(col, 0.92), x + w * 0.12, y + h * 0.18, w * 0.7, h * 0.5)


def bg_car(sf, rng, x, y, ang, col):
    _bp(sf, (30, 40, 30), _rot(x + 4, y + 5, 64, 32, ang))
    _bp(sf, OUT, _rot(x, y, 64, 32, ang))
    _bp(sf, col, _rot(x, y, 60, 28, ang))
    ca, sa = math.cos(ang), math.sin(ang)
    _bp(sf, (60, 90, 120), _rot(x + 4 * ca, y + 4 * sa, 22, 22, ang))
    _bp(sf, (110, 150, 190), _rot(x + 2 * ca, y + 2 * sa, 10, 18, ang))
    _bp(sf, _col(col, 1.3), _rot(x - 18 * ca, y - 18 * sa, 14, 22, ang))


def bg_barrel(sf, rng, x, y):
    _be(sf, (40, 50, 40), x + 2, y + 5, 18, 8)
    _bc(sf, OUT, x, y, 10)
    _bc(sf, (196, 92, 44), x, y, 8)
    pygame.draw.circle(sf, (230, 150, 90), (int(x), int(y)), 5, 1)
    _bc(sf, (150, 66, 30), x, y, 2)


def bg_lamp(sf, rng, x, y):
    _be(sf, (40, 52, 44), x + 3, y + 5, 16, 8)
    _bc(sf, OUT, x, y, 8)
    _bc(sf, (110, 114, 124), x, y, 6)
    _bc(sf, (255, 236, 150), x, y, 4)


def bg_sign(sf, rng, x, y):
    _bl(sf, OUT, (x, y), (x, y + 10), 4)
    pygame.draw.rect(sf, OUT, pygame.Rect(int(x - 13), int(y - 12), 26, 16), border_radius=3)
    pygame.draw.rect(sf, (40, 124, 78), pygame.Rect(int(x - 11), int(y - 10), 22, 12), border_radius=2)
    _bl(sf, (240, 240, 240), (x - 7, y - 4), (x + 7, y - 4), 2)



def bg_lava(sf, rng, x, y, w, h):
    _be(sf, (30, 20, 20), x, y, w + 16, h + 16)
    _be(sf, (196, 56, 20), x, y, w, h)
    _be(sf, (255, 128, 30), x, y, w * 0.82, h * 0.78)
    _be(sf, (255, 206, 80), x - w * 0.05, y - h * 0.04, w * 0.5, h * 0.42)
    for _ in range(5):
        a = rng.uniform(0, 6.28)
        _bc(sf, (255, 236, 150), x + math.cos(a) * w * 0.28, y + math.sin(a) * h * 0.26, rng.uniform(2, 4))


def bg_vent(sf, rng, x, y, r):
    _be(sf, (30, 26, 28), x + 4, y + 6, r * 2.2, r * 1.3)
    _bc(sf, OUT, x, y, r + 3)
    _bc(sf, (84, 78, 86), x, y, r)
    _bc(sf, (120, 114, 124), x - r * 0.25, y - r * 0.25, r * 0.5)
    _bc(sf, (50, 40, 44), x, y, r * 0.55)
    _bc(sf, (255, 120, 30), x, y, r * 0.38)
    for k, (dx, dy, rr) in enumerate(((r * 0.5, -r * 1.0, r * 0.4), (r * 0.9, -r * 1.7, r * 0.3), (r * 1.4, -r * 2.2, r * 0.25))):
        _bc(sf, (110 + k * 12, 104 + k * 12, 110 + k * 12), x + dx, y + dy, rr)


def bg_ember(sf, rng, x, y):
    _bc(sf, (255, rng.randint(90, 170), 40), x, y, rng.choice((1, 2)))


def bg_ashpile(sf, rng, x, y, r):
    _be(sf, (46, 38, 38), x + 2, y + 4, r * 2.2, r * 1.2)
    _be(sf, (122, 116, 120), x, y, r * 2, r * 1.1)
    _be(sf, (160, 154, 158), x - r * 0.3, y - r * 0.2, r, r * 0.5)


def bg_snowpine(sf, rng, x, y, r, sh):
    _be(sf, sh, x + 5, y + r * 0.6, r * 2.0, r * 1.2)
    for k, f in enumerate((0.78, 0.95, 1.1)):
        rr = r * (1 - k * 0.25)
        _bc(sf, OUT, x, y, rr + 2)
        _bc(sf, _col((38, 100, 74), f), x, y, rr)
    for k in range(7):
        a = k * 0.9 + rng.random() * 0.3
        _bc(sf, (244, 250, 255), x + math.cos(a) * r * 0.5, y + math.sin(a) * r * 0.5, r * 0.2)
    _bc(sf, (255, 255, 255), x - r * 0.15, y - r * 0.2, r * 0.3)


def bg_snowman(sf, rng, x, y):
    _be(sf, (160, 180, 200), x + 3, y + 8, 34, 14)
    _bc(sf, OUT, x, y + 2, 14)
    _bc(sf, (248, 252, 255), x, y + 2, 12)
    _bc(sf, OUT, x + 2, y - 11, 10)
    _bc(sf, (248, 252, 255), x + 2, y - 11, 8)
    _bc(sf, (40, 40, 50), x - 1, y - 13, 1)
    _bc(sf, (40, 40, 50), x + 5, y - 13, 1)
    _bp(sf, (240, 130, 40), [(x + 2, y - 10), (x + 10, y - 9), (x + 2, y - 8)])
    pygame.draw.circle(sf, (210, 50, 60), (int(x + 2), int(y - 3)), 7, 3)
    _bc(sf, (40, 40, 50), x, y + 3, 2)


def bg_icepond(sf, rng, x, y, w, h):
    _be(sf, (96, 140, 190), x, y, w + 14, h + 14)
    _be(sf, (176, 216, 244), x, y, w, h)
    _be(sf, (214, 238, 252), x - w * 0.1, y - h * 0.1, w * 0.6, h * 0.5)
    for _ in range(5):
        a = rng.uniform(0, 6.28)
        r1 = rng.uniform(0.1, 0.4)
        _bl(sf, (250, 254, 255), (x + math.cos(a) * w * r1, y + math.sin(a) * h * r1), (x + math.cos(a + 0.4) * w * 0.42, y + math.sin(a + 0.4) * h * 0.42), 2)


def bg_drift(sf, rng, x, y, w, h):
    _be(sf, (186, 206, 228), x + 3, y + 5, w, h)
    _be(sf, (250, 253, 255), x, y, w, h)
    _be(sf, (230, 242, 252), x - w * 0.1, y + h * 0.15, w * 0.7, h * 0.5)


def bg_igloo(sf, rng, x, y):
    _be(sf, (160, 180, 200), x + 6, y + 10, 84, 74)
    _bc(sf, OUT, x, y, 38)
    _bc(sf, (238, 246, 255), x, y, 35)
    for r in (10, 20, 30):
        pygame.draw.circle(sf, (176, 196, 218), (int(x), int(y)), r, 1)
    for k in range(8):
        a = k * 0.785
        _bl(sf, (176, 196, 218), (x + math.cos(a) * 8, y + math.sin(a) * 8), (x + math.cos(a) * 33, y + math.sin(a) * 33), 1)
    _bc(sf, (252, 254, 255), x - 10, y - 12, 10)
    pygame.draw.rect(sf, OUT, pygame.Rect(int(x + 22), int(y - 12), 28, 24), border_radius=8)
    pygame.draw.rect(sf, (238, 246, 255), pygame.Rect(int(x + 24), int(y - 10), 24, 20), border_radius=7)
    _be(sf, (40, 50, 70), x + 44, y, 12, 14)


def build_map_bg(mp):
    """Paint the whole battlefield (ground, road, scenery) once and cache it."""
    th = THEMES[mp.name]
    kind, ground, pcol = th['kind'], th['ground'], th['path']
    rng = random.Random(mp.name)
    sf = pygame.Surface((W, H))
    sf.fill(ground)
    sh = _col(ground, 0.68)                                       # shadow colour on this ground
    # ---- ground texture
    for _ in range(2800):
        _bc(sf, _col(ground, rng.choice((0.9, 0.94, 1.07, 1.12))), rng.randrange(W), rng.randrange(H), rng.choice((2, 3, 4)))
    for _ in range(420):
        x, y = rng.randrange(W), rng.randrange(H)
        if kind == 'desert':                                      # wind ripples in the sand
            _bl(sf, _col(ground, 0.92), (x, y), (x + rng.randint(14, 34), y + rng.randint(-2, 2)), 2)
        else:                                                     # grass tufts
            c = _col(ground, rng.choice((0.78, 1.22)))
            for dx in (-3, 0, 3):
                _bl(sf, c, (x + dx, y), (x + dx + rng.randint(-2, 2), y - rng.randint(4, 8)), 1)
    # ---- the road
    pw = 44
    edge = (224, 224, 226) if kind == 'road' else _col(pcol, 0.7)
    for a, b, _l, _s in mp.seg:
        _bl(sf, _col(pcol, 0.5) if kind != 'road' else (40, 42, 48), a, b, pw + 14)
    for pt in mp.path[1:-1]:
        _bc(sf, _col(pcol, 0.5) if kind != 'road' else (40, 42, 48), pt[0], pt[1], pw / 2 + 7)
    for a, b, _l, _s in mp.seg:
        _bl(sf, pcol, a, b, pw)
    for pt in mp.path[1:-1]:
        _bc(sf, pcol, pt[0], pt[1], pw / 2)
    for a, b, L, _s in mp.seg:
        dx, dy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
        nx, ny = -dy, dx
        for _ in range(int(L / 5)):                               # pebbles / grit
            t, off = rng.random() * L, rng.uniform(-pw / 2 + 4, pw / 2 - 4)
            _bc(sf, _col(pcol, rng.choice((0.8, 0.88, 1.12, 1.22))), a[0] + dx * t + nx * off, a[1] + dy * t + ny * off, rng.choice((1, 2, 3)))
        if kind == 'road':
            for t in range(0, int(L), 36):                        # dashed centre line + edge lines
                _bl(sf, (244, 204, 60), (a[0] + dx * t, a[1] + dy * t), (a[0] + dx * min(t + 20, L), a[1] + dy * min(t + 20, L)), 3)
            for off in (-17, 17):
                _bl(sf, edge, (a[0] + nx * off, a[1] + ny * off), (b[0] + nx * off, b[1] + ny * off), 2)
        elif kind == 'grave':
            for t in range(0, int(L), 24):                        # flagstone seams
                _bl(sf, _col(pcol, 0.72), (a[0] + dx * t + nx * -pw / 2, a[1] + dy * t + ny * -pw / 2), (a[0] + dx * t + nx * pw / 2, a[1] + dy * t + ny * pw / 2), 2)
            _bl(sf, _col(pcol, 0.78), (a[0], a[1]), (b[0], b[1]), 2)
        elif kind == 'lava':
            for _ in range(int(L / 26)):                          # glowing cracks in the ash road
                t, off = rng.random() * L, rng.uniform(-pw / 2 + 5, pw / 2 - 5)
                px_, py_ = a[0] + dx * t + nx * off, a[1] + dy * t + ny * off
                ang = rng.uniform(0, 6.28)
                ln = rng.uniform(8, 18)
                _bl(sf, (60, 30, 26), (px_, py_), (px_ + math.cos(ang) * ln, py_ + math.sin(ang) * ln), 4)
                _bl(sf, (240, 110, 40), (px_, py_), (px_ + math.cos(ang) * ln, py_ + math.sin(ang) * ln), 2)
        elif kind == 'snow':
            for t in range(10, int(L), 22):                       # trampled snow prints
                for off in (-8, 8):
                    _bc(sf, _col(pcol, 0.86), a[0] + dx * t + nx * off, a[1] + dy * t + ny * off, 3)
        else:
            for off in (-9, 9):                                   # cart ruts
                _bl(sf, _col(pcol, 0.8), (a[0] + nx * off, a[1] + ny * off), (b[0] + nx * off, b[1] + ny * off), 3)
    # ---- tower pads (a subtle trodden circle under every tower spot)
    for pos in mp.slots.values():
        _bc(sf, _col(ground, 0.85), pos[0], pos[1], 27)
        pygame.draw.circle(sf, _col(ground, 0.74), (int(pos[0]), int(pos[1])), 27, 2)
    # ---- scenery, placed only where it won't clash with the road or towers
    placed = []

    def free(x, y, r):
        if not (r + 8 <= x <= W - r - 8 and 62 + r <= y <= 846 - r):
            return False
        if min(_seg_dist((x, y), a, b) for a, b, _l, _s in mp.seg) < r + 36:
            return False
        if any(math.hypot(x - q[0], y - q[1]) < r + 38 for q in mp.slots.values()):
            return False
        if math.hypot(x - mp.path[-1][0], y - mp.path[-1][1]) < r + 62:
            return False
        return all(math.hypot(x - ox, y - oy) >= r + orr + 3 for ox, oy, orr in placed)

    def scatter(n, rmin, rmax, fn, tries=60):
        for _ in range(n):
            for _t in range(tries):
                r = rng.uniform(rmin, rmax)
                x, y = rng.uniform(20, W - 20), rng.uniform(70, 840)
                if free(x, y, r):
                    placed.append((x, y, r))
                    fn(x, y, r)
                    break

    greens = {'forest': (58, 134, 62), 'road': (74, 150, 70), 'farm': (96, 160, 56)}
    gt = greens.get(kind, (60, 120, 60))
    if kind == 'forest':
        scatter(2, 70, 70, lambda x, y, r: bg_pond(sf, rng, x, y, 130, 84))
        scatter(16, 22, 34, lambda x, y, r: bg_tree(sf, rng, x, y, r, _col(gt, rng.uniform(0.85, 1.15)), sh))
        scatter(12, 22, 32, lambda x, y, r: bg_pine(sf, rng, x, y, r, (34, 100, 62), sh))
        scatter(14, 11, 16, lambda x, y, r: bg_bush(sf, rng, x, y, r, (70, 150, 70), sh))
        scatter(10, 9, 15, lambda x, y, r: bg_rock(sf, rng, x, y, r, (128, 130, 134), sh))
        scatter(6, 10, 12, lambda x, y, r: bg_stump(sf, rng, x, y, r, sh))
        scatter(4, 28, 28, lambda x, y, r: bg_log(sf, rng, x, y, rng.uniform(0, 3.14), 54))
    elif kind == 'grave':
        scatter(30, 15, 18, lambda x, y, r: bg_tomb(sf, rng, x, y, sh))
        scatter(9, 26, 34, lambda x, y, r: bg_deadtree(sf, rng, x, y, r, sh))
        scatter(12, 9, 15, lambda x, y, r: bg_rock(sf, rng, x, y, r, (110, 112, 118), sh))
        scatter(8, 12, 14, lambda x, y, r: bg_pumpkin(sf, rng, x, y))
        scatter(8, 30, 30, lambda x, y, r: bg_fence(sf, rng, x, y, rng.choice((0, 1.57)), 4))
        scatter(10, 10, 12, lambda x, y, r: bg_bone(sf, rng, x, y, rng.uniform(0, 3.14)))
        scatter(5, 10, 12, lambda x, y, r: bg_skull(sf, rng, x, y))
        scatter(8, 10, 15, lambda x, y, r: bg_bush(sf, rng, x, y, r, (50, 96, 62), sh))
    elif kind == 'farm':
        scatter(1, 70, 70, lambda x, y, r: bg_barn(sf, rng, x, y))
        scatter(2, 80, 80, lambda x, y, r: bg_crops(sf, rng, x, y, 130, 96, (200, 168, 60)))
        scatter(2, 80, 80, lambda x, y, r: bg_crops(sf, rng, x, y, 130, 96, (76, 140, 54)))
        scatter(12, 15, 19, lambda x, y, r: bg_hay(sf, rng, x, y, r, sh))
        scatter(9, 22, 32, lambda x, y, r: bg_tree(sf, rng, x, y, r, rng.choice(((98, 160, 60), (214, 150, 48), (190, 90, 44))), sh))
        scatter(8, 30, 30, lambda x, y, r: bg_fence(sf, rng, x, y, rng.choice((0, 1.57)), 5))
        scatter(8, 10, 15, lambda x, y, r: bg_rock(sf, rng, x, y, r, (140, 134, 122), sh))
        scatter(1, 52, 52, lambda x, y, r: bg_pond(sf, rng, x, y, 100, 62))
    elif kind == 'desert':
        scatter(8, 50, 50, lambda x, y, r: bg_dune(sf, rng, x, y, 150, 56, ground))
        scatter(18, 10, 17, lambda x, y, r: bg_cactus(sf, rng, x, y, r, sh))
        scatter(16, 10, 18, lambda x, y, r: bg_rock(sf, rng, x, y, r, (176, 110, 80), sh))
        scatter(8, 10, 12, lambda x, y, r: bg_bone(sf, rng, x, y, rng.uniform(0, 3.14)))
        scatter(6, 10, 12, lambda x, y, r: bg_skull(sf, rng, x, y))
        scatter(8, 10, 15, lambda x, y, r: bg_bush(sf, rng, x, y, r, (150, 140, 70), sh))
        scatter(3, 70, 70, lambda x, y, r: bg_pond(sf, rng, x, y, 70, 42))
    elif kind == 'lava':
        scatter(5, 62, 62, lambda x, y, r: bg_lava(sf, rng, x, y, rng.uniform(110, 150), rng.uniform(60, 84)))
        scatter(14, 9, 16, lambda x, y, r: bg_rock(sf, rng, x, y, r, (58, 52, 70), sh))
        scatter(9, 26, 34, lambda x, y, r: bg_deadtree(sf, rng, x, y, r, sh, (40, 34, 34)))
        scatter(6, 14, 18, lambda x, y, r: bg_vent(sf, rng, x, y, r))
        scatter(8, 12, 16, lambda x, y, r: bg_ashpile(sf, rng, x, y, r))
        scatter(8, 10, 12, lambda x, y, r: bg_bone(sf, rng, x, y, rng.uniform(0, 3.14)))
        scatter(4, 10, 12, lambda x, y, r: bg_skull(sf, rng, x, y))
        for _ in range(90):
            ex_, ey_ = rng.uniform(10, W - 10), rng.uniform(70, 840)
            if free(ex_, ey_, 3):
                bg_ember(sf, rng, ex_, ey_)
    elif kind == 'snow':
        scatter(18, 22, 32, lambda x, y, r: bg_snowpine(sf, rng, x, y, r, sh))
        scatter(3, 20, 20, lambda x, y, r: bg_snowman(sf, rng, x, y))
        scatter(2, 60, 60, lambda x, y, r: bg_icepond(sf, rng, x, y, 120, 78))
        scatter(14, 24, 30, lambda x, y, r: bg_drift(sf, rng, x, y, rng.uniform(70, 100), rng.uniform(26, 38)))
        scatter(1, 52, 52, lambda x, y, r: bg_igloo(sf, rng, x, y))
        scatter(10, 9, 15, lambda x, y, r: bg_rock(sf, rng, x, y, r, (150, 156, 168), sh))
        scatter(8, 11, 15, lambda x, y, r: bg_bush(sf, rng, x, y, r, (110, 160, 150), sh))
    else:                                                          # roadside: trees, bushes, wrecks, signs, lamps
        scatter(14, 22, 34, lambda x, y, r: bg_tree(sf, rng, x, y, r, _col(gt, rng.uniform(0.85, 1.15)), sh))
        scatter(12, 11, 16, lambda x, y, r: bg_bush(sf, rng, x, y, r, (80, 156, 72), sh))
        scatter(3, 34, 34, lambda x, y, r: bg_car(sf, rng, x, y, rng.uniform(-0.6, 0.6), rng.choice(((196, 60, 60), (70, 120, 200), (220, 190, 60)))))
        scatter(8, 10, 12, lambda x, y, r: bg_barrel(sf, rng, x, y))
        scatter(6, 14, 16, lambda x, y, r: bg_sign(sf, rng, x, y))
        scatter(8, 9, 15, lambda x, y, r: bg_rock(sf, rng, x, y, r, (130, 132, 138), sh))
        for a, b, L, _s in mp.seg:                                 # lamp posts along the road
            dx, dy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
            for t in range(60, int(L) - 20, 150):
                bg_lamp(sf, rng, a[0] + dx * t - dy * 36, a[1] + dy * t + dx * 36)
    for _ in range(36 if kind in ('forest', 'farm', 'road') else 6 if kind in ('grave', 'desert') else 0):   # wild flowers
        x, y = rng.uniform(20, W - 20), rng.uniform(70, 840)
        if free(x, y, 4):
            bg_flower(sf, rng, x, y)
    return sf


def get_map_bg(mp):
    if mp.name not in MAP_BG:
        MAP_BG[mp.name] = build_map_bg(mp)
    if not CLOUDS:                                                 # drifting cloud shadows (shared by all maps)
        for i in range(3):
            cs = pygame.Surface((380, 200), pygame.SRCALPHA)
            for k in range(7):
                pygame.draw.ellipse(cs, (0, 0, 0, 30), pygame.Rect(20 + k * 44 - (k % 2) * 10, 40 + (k % 3) * 22, 110, 80))
            CLOUDS.append(cs)
    return MAP_BG[mp.name]


# ------------------------------------------------------------------ game
class Game:
    def __init__(self, screen):
        self.screen = screen
        self.f_xs = pygame.font.SysFont("arial", 13)
        self.f_s = pygame.font.SysFont("arial", 16)
        self.f_m = pygame.font.SysFont("arial", 22, bold=True)
        self.f_l = pygame.font.SysFont("arial", 44, bold=True)
        self.f_xl = pygame.font.SysFont("arial", 76, bold=True)
        self.coins, self.upg, self.owned, self.achieved, self.medium_played, self.boosts, _extra = load_save()
        self.hard_played, self.won_maps = _extra['hard'], _extra['won_maps']
        self.speeds = _extra['speeds']                        # unlocked game speeds (2 and/or 3)
        self.boost_open = False
        self.mode, self.cfg, self.total_waves = 'easy', MODES['easy'], MODES['easy']['total']
        self.store_page = 0
        self.ach_page = 0
        self.custom_page = 0
        self.toasts = []          # [text, seconds_left] pop-up banners
        self.new_achs = []
        if not SPRITES:
            build_sprites()
        self.t = 0.0              # running clock for animations
        self.fx = []              # particles, corpses, rings, floating text
        self.base_flash = 0.0
        self.state = "menu"
        self.show_ranges = False
        self.speed = 1
        self.map = MAPS[1]

    # ---------- map roulette
    def start_spin(self, mode='easy'):
        self.mode = mode
        self.state = "spin"
        self.spin_t = 0.0
        self.map_idx = random.randrange(len(MAPS))
        self.map = MAPS[self.map_idx]
        get_map_bg(self.map)
        step = 360 / len(MAPS)
        # wedge i centre is at (angle + (i+0.5)*step); pointer is at -90 degrees (top)
        target = (-90 - (self.map_idx + 0.5) * step) % 360
        self.spin_final = target + 360 * 6 + random.uniform(-0.35, 0.35) * step

    # ---------- match setup
    def new_match(self):
        self.cfg = MODES[self.mode]
        self.total_waves = self.cfg['total']
        self.state = "play"
        self.speed = 1
        self.money = START_MONEY
        self.base_hp = BASE_HP
        self.wave = 0
        self.towers, self.zombies, self.shots = [], [], []
        self.boss_sent = False
        self.fx = []
        self.base_flash = 0.0
        self.spit_t = self.boots_t = self.big_t = self.drunk_t = self.spit_flash = 0.0
        self.drunk_n = 0
        self.boost_open = False
        self.pmap = self.map                      # the path zombies currently follow (changes during Illusionary Path)
        self.illusion_t, self.illusion_fade, self.straight = 0.0, 0.0, None
        self.alike_mode, self.alike_user, self.alike_src, self.alike_picks = None, None, None, []
        self.tech, self.mod_id, self.m = set(), None, {}
        self.formation = 'cluster'
        self.phase = 'plan'
        self.research_open = False
        self.show_heat = False
        self.fade_straight = None
        self.conf_path_btn = pygame.Rect(698, 88, 140, 70)
        self.conf_alike_btn = pygame.Rect(846, 88, 136, 70)
        self.recompute_mult()
        self.sp_sent = set()
        self.el_sent = set()
        self.shells = []
        self.boosts_used = set()
        self.boost_btn = pygame.Rect(835, 852, 150, 28)
        self.research_btn = pygame.Rect(675, 852, 150, 28)
        self.start_btn = pygame.Rect(370, 775, 260, 54)
        self.tab = 'normal'
        self.new_achs = []
        self.money_earned = 0     # total $ earned from kills this match
        self.messages, self.msg_timer = [], 0.0
        self.complete_timer = 0.0
        self.result = None
        self.start_wave(1)

    def start_wave(self, n):
        self.wave = n
        self.complete_timer = 0.0
        msgs = []
        for op in self.cfg['ops'][n]:
            if op[0] == 'add':
                _, tid, kind, lvl = op
                self.towers.append(Tower(tid, kind, lvl, self.map.slots[tid]))
                msgs.append(f"Enemy placed a LVL {lvl} {TOWER_NAMES[kind]}")
            else:
                _, tid, lvl = op
                t = next(t for t in self.towers if t.id == tid)
                t.lvl = lvl
                msgs.append(f"Enemy upgraded a {TOWER_NAMES[t.kind]} to LVL {lvl}" + (" (MAX)" if lvl == 4 else ""))
        free, paid = self.cfg['waves'][n]
        free = dict(free)
        self.roll_modifier(n)
        if self.m['free_z']:
            free['zombie'] = free.get('zombie', 0) + self.m['free_z']
        prev = self.cfg['waves'].get(n - 1)
        has_sp = any(k in SPECIAL_KINDS for k in list(free) + list(paid))
        had_sp = prev is not None and any(k in SPECIAL_KINDS for k in list(prev[0]) + list(prev[1]))
        if has_sp and not had_sp:
            msgs.append("New zombies available - check the SPECIAL tab (TAB key)")
        has_el = any(k in ELITE_KINDS for k in list(free) + list(paid))
        had_el = prev is not None and any(k in ELITE_KINDS for k in list(prev[0]) + list(prev[1]))
        if has_el and not had_el:
            msgs.append("Elite zombies available - check the ELITE tab (TAB key)")
        self.messages, self.msg_timer = msgs, 6.0
        self.phase = 'plan'                      # every wave starts with a planning phase
        self.free = dict(free)
        self.paid = dict(paid)
        self.kinds = [k for k in ORDER if k in free or k in paid]
        self.build_buttons()
        self.speed_btn = pygame.Rect(835, 885, 150, 48)
        self.form_btn = pygame.Rect(835, 937, 150, 48)
        self.exit_btn = pygame.Rect(706, 913, 90, 62)

    def build_buttons(self):
        if self.tab == 'normal':
            ks = [k for k in self.kinds if k in NORMAL_KINDS]
        elif self.tab == 'special':
            ks = [k for k in self.kinds if k in SPECIAL_KINDS]
        elif self.tab == 'elite':
            ks = [k for k in self.kinds if k in ELITE_KINDS]
        else:
            ks = [k for k in CUSTOM_KEYS if k in self.owned]
        n, gap = max(1, len(ks)), 6
        w = min(200 if self.tab == 'custom' else 150, (650 - (n - 1) * gap) // n)
        self.buttons = [(k, pygame.Rect(15 + i * (w + gap), 885, w, 100)) for i, k in enumerate(ks)]
        self.tab_rects = {'normal': pygame.Rect(15, 852, 150, 28), 'special': pygame.Rect(171, 852, 150, 28),
                          'elite': pygame.Rect(327, 852, 150, 28), 'custom': pygame.Rect(483, 852, 150, 28)}

    def price(self, p):
        """A listed price after research + the wave modifier."""
        return max(1, int(round(p * self.m['price'])))

    def can_spawn(self):
        if any(n > 0 for n in self.free.values()):
            return True
        return any(n > 0 and self.money >= self.price(p) for n, p in self.paid.values())

    def spawn(self, kind):
        if self.phase != 'run':                 # nothing can be sent during the planning phase
            return
        if kind in CUSTOM:
            cost = self.price(CUSTOM[kind]['spawn_cost'])
            if kind not in self.owned or self.money < cost:
                return
            self.money -= cost
        elif self.free.get(kind, 0) > 0:
            self.free[kind] -= 1
        elif kind in self.paid and self.paid[kind][0] > 0 and self.money >= self.price(self.paid[kind][1]):
            n, p = self.paid[kind]
            self.paid[kind] = (n - 1, p)
            self.money -= self.price(p)
        else:
            return
        z_new = Zombie(kind, self.pmap, self.upg)
        if self.formation == 'spread':           # SPREAD: queue them up one behind the other
            z_new.dist = -SPREAD_GAP * sum(1 for o in self.zombies if o.dist < 0) - 2
        self.zombies.append(z_new)
        self.spawn_fx(self.zombies[-1])
        if kind in BOSS_KINDS:
            self.boss_sent = True
        if self.mode == 'hard' and kind in ('splitter', 'screamer', 'juggernaut'):
            self.el_sent.add(kind)
            if len(self.el_sent) == 3:
                self.unlock('hard_elite')
        if self.mode == 'medium' and kind in ('medic', 'bomber', 'leaper', 'riot'):
            self.sp_sent.add(kind)
            if len(self.sp_sent) == 4:
                self.unlock('med_special')

    # ---------- strategy layer: research, modifiers, target priorities, planning
    def recompute_mult(self):
        """Combine research and the wave modifier into one set of multipliers."""
        T = self.tech
        m = dict(hp=1.0, dr=0.0, regen=0.0, spd=1.0, rew=1.0, price=1.0, free_z=0, tdmg=1.0, tcd=1.0, trng=1.0, miss=0.0)
        if 'hp1' in T: m['hp'] *= 1.08
        if 'hp2a' in T: m['dr'] = 0.05
        if 'hp2b' in T: m['regen'] = 0.008
        if 'sp1' in T: m['spd'] *= 1.04
        if 'sp2a' in T: m['spd'] *= 1.05
        if 'sp2b' in T: m['miss'] = 0.05
        if 'ec1' in T: m['rew'] *= 1.06
        if 'ec2a' in T: m['price'] *= 0.94
        if 'ec2b' in T: m['free_z'] = 1
        if 'sb1' in T: m['tdmg'] *= 0.96
        if 'sb2a' in T: m['tcd'] *= 1.06
        if 'sb2b' in T: m['trng'] *= 0.94
        md = MODIFIERS.get(self.mod_id) if self.mod_id else None
        if md:
            for k in ('hp', 'spd', 'rew', 'price', 'tdmg', 'tcd', 'trng'):
                m[k] *= md.get(k, 1.0)
        self.m = m

    def roll_modifier(self, n):
        self.mod_id = None
        if n >= 2 and random.random() < MOD_CHANCE:
            self.mod_id = random.choice(list(MODIFIERS))
        self.recompute_mult()

    def tech_state(self, key):
        """'owned' | 'locked' | 'excluded' | 'afford' | 'poor'"""
        d = TECHS[key]
        if key in self.tech:
            return 'owned'
        if d.get('excl') in self.tech:
            return 'excluded'
        if d.get('req') and d['req'] not in self.tech:
            return 'locked'
        return 'afford' if self.money >= d['cost'] else 'poor'

    def buy_tech(self, key):
        if self.state != 'play' or self.tech_state(key) != 'afford':
            return False
        self.money -= TECHS[key]['cost']
        self.tech.add(key)
        self.recompute_mult()
        self.add_fx(type='text', pos=[500, 150], txt=TECHS[key]['name'] + " researched!", t=0.0, life=1.4, col=(150, 230, 255), layer=1)
        return True

    def begin_wave(self):
        if self.phase == 'plan':
            self.phase = 'run'
            self.research_open = False
            self.msg_timer = min(self.msg_timer, 3.0)

    def pick_target(self, t, rng):
        """Each tower type chooses its target differently - spread out, mix units and bait them!"""
        cand = [z for z in self.zombies if z.dist >= 0 and not z.phased and math.dist(t.pos, z.pos) <= rng]
        if not cand:
            return None
        k = t.kind
        if k == 'scout':
            return max(cand, key=lambda z: (z.hp + z.shield, z.dist))
        if k == 'cryo':                                   # the FRONT zombie that isn't slowed yet
            return max(cand, key=lambda z: (z.slow_t <= 0, z.dist))
        if k in ('shot', 'mortar'):
            best, bs = None, (-1, -1)
            half = math.radians(t.stats[3] / 2) if k == 'shot' else 0
            for z in cand:
                zx, zy = z.pos
                if k == 'shot':
                    aim = math.atan2(zy - t.pos[1], zx - t.pos[0])
                    n = 0
                    for o in cand:
                        ox, oy = o.pos
                        d = (math.atan2(oy - t.pos[1], ox - t.pos[0]) - aim + math.pi) % (2 * math.pi) - math.pi
                        if abs(d) <= half:
                            n += 1
                elif k == 'mortar':
                    lx, ly = z.map.pos_at(z.dist + z.speed * MORTAR_FLIGHT)
                    n = sum(1 for o in cand if math.dist((lx, ly), o.pos) <= MORTAR_R[t.lvl])
                else:
                    n = sum(1 for o in cand if math.dist(z.pos, o.pos) <= TESLA_RANGE)
                if (n, z.dist) > bs:
                    best, bs = z, (n, z.dist)
            return best
        return max(cand, key=lambda z: z.dist)

    def threat_at(self, x, y):
        """Total tower DPS covering a point (for the planning heat-map)."""
        tot = 0.0
        for t in self.towers:
            st = t.stats
            if t.kind != 'cmd' and math.dist((x, y), t.pos) <= st[2] * self.m['trng']:
                tot += st[0] * TOWER_DMG_MULT * self.m['tdmg'] / (st[1] * self.m['tcd'])
        return tot

    # ---------- Confuser abilities
    def confusers(self):
        return [z for z in self.zombies if z.kind == 'confuser']

    def path_ready(self):
        return sum(1 for z in self.confusers() if not z.path_used)

    def alike_ready(self):
        return [z for z in self.confusers() if z.alike_cd <= 0]

    def use_path(self):
        """Illusionary Path: the path becomes a straight line (and the base moves) for a few seconds."""
        if self.phase != 'run' or self.illusion_t > 0:
            return False
        c = next((z for z in self.confusers() if not z.path_used), None)
        if c is None:
            return False
        c.path_used = True
        orig = self.map
        sx, sy = orig.path[0]
        dx = 1 if sx < W / 2 else -1
        ln = min(orig.length, 880.0)
        self.straight = Map(orig.name, orig.mult, orig.col, [(sx, sy), (sx + dx * ln, sy)], orig.slots)
        for z in self.zombies:
            f = z.dist / z.map.length
            z.map = self.straight
            z.dist = f * self.straight.length
        self.pmap = self.straight
        self.fade_straight = self.straight
        self.illusion_t = ILLUSION_TIME
        self.add_fx(type='text', pos=[500, 120], txt="ILLUSIONARY PATH!", t=0.0, life=1.4, col=(220, 150, 255), layer=1)
        return True

    def end_illusion(self):
        if self.straight is None:
            return
        for z in self.zombies:
            f = z.dist / self.straight.length
            z.map = self.map
            z.dist = f * self.map.length
        self.pmap = self.map
        self.straight = None
        self.add_fx(type='text', pos=[500, 120], txt="The path returns", t=0.0, life=1.2, col=(200, 200, 255), layer=1)

    def alike_start(self):
        if self.phase != 'run' or not self.alike_ready() or self.alike_mode:
            return False
        if not any(t.stun <= 0 and t.kind != 'cmd' for t in self.towers):      # nothing to hijack: don't freeze time
            self.toasts.append(["Zombie-Alike: no tower available to hijack", 2.5])
            return False
        self.alike_user = self.alike_ready()[0]
        self.alike_mode, self.alike_src, self.alike_picks = 'source', None, []
        return True

    def alike_cancel(self):
        self.alike_mode, self.alike_user, self.alike_src, self.alike_picks = None, None, None, []

    def alike_targets_needed(self):
        return 2 if self.alike_user is not None and self.alike_user.clevel >= ALIKE_LVL2 else 1

    def tower_at(self, pos):
        best = None
        for t in self.towers:
            d = math.dist(pos, t.pos)
            if d <= 30 and (best is None or d < best[0]):
                best = (d, t)
        return best[1] if best else None

    def alike_click(self, pos):
        """Zombie-Alike picking: 1) click the tower to hijack  2) click the tower(s) it should shoot."""
        t = self.tower_at(pos)
        if self.alike_mode == 'source':
            if t is not None and t.stun <= 0 and t.kind != 'cmd':
                self.alike_src, self.alike_mode, self.alike_picks = t, 'target', []
            elif t is None:
                self.alike_cancel()
            return True
        if self.alike_mode == 'target':
            src = self.alike_src
            if t is src and self.alike_picks:
                self.alike_fire()
            elif t is not None and t is not src and t not in self.alike_picks \
                    and math.dist(src.pos, t.pos) <= src.stats[2] * self.m['trng']:
                self.alike_picks.append(t)
                if len(self.alike_picks) >= self.alike_targets_needed():
                    self.alike_fire()
            elif t is None:
                self.alike_cancel()
            return True
        return False

    def alike_fire(self):
        src, user = self.alike_src, self.alike_user
        if src is None or not self.alike_picks:
            return
        src.hijack_t = ALIKE_SHOOT
        src.hijack_targets = list(self.alike_picks)
        for tg in self.alike_picks:
            tg.stun = max(tg.stun, ALIKE_STUN)
            self.splash_fx(tg.pos)
        if user is not None:
            user.alike_cd = ALIKE_CD
        self.add_fx(type='text', pos=[500, 120], txt="ZOMBIE-ALIKE!", t=0.0, life=1.4, col=(255, 150, 220), layer=1)
        self.alike_cancel()

    def bonus_coins(self):
        return int((self.money_earned // BONUS_PER) * BONUS_COINS)

    @staticmethod
    def menu_buttons():
        out = [('easy', 'EASY MODE', pygame.Rect(100, 450, 220, 76)),
               ('medium', 'MEDIUM MODE', pygame.Rect(390, 450, 220, 76)),
               ('hard', 'HARD MODE', pygame.Rect(680, 450, 220, 76)),
               ('store', 'UPGRADES', pygame.Rect(180, 542, 310, 64)),
               ('custom', 'CUSTOM ZOMBIES', pygame.Rect(510, 542, 310, 64)),
               ('boosts', 'BOOST SHOP', pygame.Rect(180, 622, 310, 64)),
               ('ach', 'ACHIEVEMENTS', pygame.Rect(510, 622, 310, 64)),
               ('quit', 'QUIT', pygame.Rect(350, 702, 300, 64))]
        return out

    def hard_ok(self):
        return len(self.owned) >= 2 and self.medium_played

    def save(self):
        save_game(self.coins, self.upg, self.owned, self.achieved, self.medium_played, self.boosts,
                  {'hard': self.hard_played, 'won_maps': self.won_maps, 'speeds': self.speeds})

    def unlock(self, aid, toast=True):
        """Grant an achievement once. Returns True only the first time."""
        if aid in self.achieved:
            return False
        self.achieved.append(aid)
        self.coins += ACH[aid]['reward']
        self.save()
        if toast:
            self.toasts.append([f"Achievement unlocked: {ACH[aid]['title']}  +{ACH[aid]['reward']} coins", 5.0, aid])
        return True

    # ---------- boosts
    def buy_boost(self, key):
        price = BOOSTS[key]['price']
        if self.coins >= price:
            self.coins -= price
            self.boosts[key] = self.boosts.get(key, 0) + 1
            self.save()

    def boost_state(self, key):
        """(usable, status text) for the in-match boosts panel."""
        if key == 'spit':
            return (self.spit_t <= 0, f"Active {self.spit_t:.1f}s" if self.spit_t > 0 else "Ready")
        if key == 'boots':
            return (True, f"Active {self.boots_t:.1f}s (+{BOOTS_TIME:g}s)" if self.boots_t > 0 else "Ready")
        if key == 'big':
            return (True, f"Active {self.big_t:.1f}s (+{BIG_TIME:g}s)" if self.big_t > 0 else "Ready")
        if self.drunk_n >= 3:
            return (False, f"MAX x3  {self.drunk_t:.1f}s")
        return (True, f"x{self.drunk_n} {self.drunk_t:.1f}s" if self.drunk_t > 0 else "Ready")

    def use_boost(self, key):
        if self.state != "play" or self.boosts.get(key, 0) <= 0 or not self.boost_state(key)[0]:
            return False
        if key == 'spit':
            self.spit_t = SPIT_STUN
            self.spit_flash = 0.45
            for t in self.towers:
                t.stun = max(t.stun, SPIT_STUN)
                self.splash_fx(t.pos)
        elif key == 'boots':
            self.boots_t += BOOTS_TIME
        elif key == 'big':
            self.big_t += BIG_TIME
        elif key == 'drunk':
            self.drunk_n += 1
            self.drunk_t += DRUNK_TIME
        self.boosts[key] -= 1
        self.save()
        self.boosts_used.add(key)
        if self.mode == 'medium' and len(self.boosts_used) == len(BOOST_KEYS):
            self.unlock('med_boosts')
        self.add_fx(type='text', pos=[500, 120], txt=BOOSTS[key]['name'] + "!", t=0.0, life=1.2, col=BOOSTS[key]['col'], layer=1)
        return True

    def miss_fx(self, pos):
        if random.random() < 0.3:
            self.add_fx(type='text', pos=[pos[0], pos[1] - 10], txt="MISS", t=0.0, life=0.6, col=(210, 210, 255), layer=1)

    def buy_speed(self, n):
        if n in self.speeds or self.coins < SPEED_SHOP[n]:
            return
        self.coins -= SPEED_SHOP[n]
        self.speeds = sorted(self.speeds + [n])
        self.save()

    def cycle_speed(self):
        owned = [1] + sorted(self.speeds)
        if len(owned) == 1:
            self.toasts.append(["Buy 2x / 3x speed in the Boost Shop (main menu)", 3.5])
            return
        self.speed = owned[(owned.index(self.speed) + 1) % len(owned)] if self.speed in owned else 1

    @staticmethod
    def speed_rows():
        return [pygame.Rect(90, 665 + i * 72, 820, 62) for i in range(2)]

    @staticmethod
    def speed_buy_rect(r):
        return pygame.Rect(r.right - 230, r.y + 7, 200, 48)

    @staticmethod
    def boost_rows():
        return [pygame.Rect(90, 140 + i * 130, 820, 115) for i in range(len(BOOST_KEYS))]

    @staticmethod
    def boost_buy_rect(r):
        return pygame.Rect(r.right - 230, r.y + 28, 200, 58)

    @staticmethod
    def boost_panel_rows():
        return [(k, pygame.Rect(492, 588 + i * 62, 486, 56)) for i, k in enumerate(BOOST_KEYS)]

    @staticmethod
    def boost_use_rect(r):
        return pygame.Rect(r.right - 100, r.y + 8, 90, 40)

    def buy(self, key):
        if key in CUSTOM and key not in self.owned:
            return                      # must own a custom zombie before upgrading it
        if key in SPECIAL_KEYS and not self.medium_played:
            return                      # special zombies unlock after playing Medium once
        if key in ELITE_KEYS and not self.hard_played:
            return                      # elite zombies unlock after playing Hard once
        lvl = self.upg[key]
        if lvl >= max_up(key):
            return
        cost = upg_cost(key, lvl)
        if self.coins >= cost:
            self.coins -= cost
            self.upg[key] = lvl + 1
            self.save()

    def buy_custom(self, key):
        c = CUSTOM[key]
        if key in self.owned or self.coins < c['price']:
            return
        self.coins -= c['price']
        self.owned.append(key)
        self.save()
        self.unlock('buy_custom')
        if len(self.owned) >= len(CUSTOM_KEYS):
            self.unlock('collector')

    def custom_keys_page(self):
        return CUSTOM_KEYS[:3] if self.custom_page == 0 else CUSTOM_KEYS[3:]

    @staticmethod
    def custom_tabs():
        return [pygame.Rect(40, 28, 130, 40), pygame.Rect(180, 28, 130, 40)]

    def custom_cards(self):
        return [pygame.Rect(90, 125 + i * 220, 820, 205) for i in range(len(self.custom_keys_page()))]

    @staticmethod
    def custom_buy_rect(r):
        return pygame.Rect(r.right - 240, r.y + 18, 220, 52)

    @staticmethod
    def custom_up_rect(r):
        return pygame.Rect(r.right - 240, r.y + 132, 220, 52)

    def store_keys(self):
        return (UPG_KEYS, SPECIAL_KEYS, ELITE_KEYS)[self.store_page]

    def store_rows(self):
        return [pygame.Rect(90, 140 + i * 100, 820, 90) for i in range(len(self.store_keys()))]

    @staticmethod
    def store_tabs():
        return [pygame.Rect(20, 28, 100, 40), pygame.Rect(130, 28, 135, 40), pygame.Rect(275, 28, 120, 40)]

    @staticmethod
    def buy_rect(r):
        return pygame.Rect(r.right - 200, r.y + 17, 180, 56)

    def next_wave(self):
        if self.zombies:
            return
        if self.wave >= self.total_waves:
            self.finish(False)
        else:
            self.start_wave(self.wave + 1)

    def finish(self, base_destroyed):
        cfg = self.cfg
        if base_destroyed:
            base = cfg['win_boss'] if self.boss_sent else cfg['win_clean']
        else:
            base = cfg['lose']
        earned = int(round(base * self.map.mult))
        bonus = self.bonus_coins()
        self.coins += earned + bonus
        new = []
        if base_destroyed and self.mode == 'easy':          # achievements are for Easy mode
            won = ['beat_easy']
            if self.map.name == ACH_MAP_NAME:
                won.append('map_win')
            if not self.boss_sent:
                won.append('no_boss')
            if self.map.name == ACH_MAP_NAME and self.wave <= 3:
                won.append('fast_win')
            for aid in won:
                if self.unlock(aid, toast=False):
                    new.append(aid)
        if base_destroyed:
            if self.map.name not in self.won_maps:
                self.won_maps.append(self.map.name)
            if len(self.won_maps) >= len(MAPS) and self.unlock('cartographer', toast=False):
                new.append('cartographer')
        if base_destroyed and self.mode == 'hard':
            won = ['hard_win']
            if not self.boss_sent:
                won.append('hard_no_boss')
            if self.map.name == HARD_ACH_MAP:
                won.append('hard_map')
            if self.wave <= 7:
                won.append('hard_fast')
            for aid in won:
                if self.unlock(aid, toast=False):
                    new.append(aid)
        if self.mode == 'hard':
            if not self.hard_played:
                self.toasts.append(["Elite zombie upgrades unlocked in the Upgrade Store!", 5.0])
            self.hard_played = True
        if base_destroyed and self.mode == 'medium':
            won = ['med_win']
            if not self.boss_sent:
                won.append('med_no_boss')
            if self.map.name == MED_ACH_MAP:
                won.append('med_map')
            if self.wave <= 4:
                won.append('med_fast')
            for aid in won:
                if self.unlock(aid, toast=False):
                    new.append(aid)
        self.new_achs = new
        if self.mode == 'medium':
            if not self.medium_played:
                self.toasts.append(["Special zombie upgrades unlocked in the Upgrade Store!", 5.0])
            self.medium_played = True
        self.save()
        self.result = (base_destroyed, earned, base, bonus)
        self.state = "result"

    # ---------- events
    def handle(self, e):
        if e.type == pygame.QUIT:
            pygame.quit(); sys.exit()
        if self.state == "menu":
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for action, _label, r in self.menu_buttons():
                    if r.collidepoint(e.pos):
                        if action == 'easy':
                            self.start_spin('easy')
                        elif action == 'medium':
                            if self.owned:
                                self.start_spin('medium')
                            else:
                                self.toasts.append(["Medium mode needs a custom zombie (buy one in the shop)", 4.0])
                        elif action == 'hard':
                            if self.hard_ok():
                                self.start_spin('hard')
                            else:
                                self.toasts.append(["Hard mode needs 2 custom zombies and one Medium match played", 4.0])
                        elif action == 'quit':
                            pygame.quit(); sys.exit()
                        else:
                            self.state = action
        elif self.state == "ach":
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if pygame.Rect(350, 810, 300, 70).collidepoint(e.pos):
                    self.state = "menu"
                for i, tr in enumerate(self.ach_tabs()):
                    if tr.collidepoint(e.pos):
                        self.ach_page = i
        elif self.state == "custom":
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if pygame.Rect(350, 810, 300, 70).collidepoint(e.pos):
                    self.state = "menu"
                for i, tr in enumerate(self.custom_tabs()):
                    if tr.collidepoint(e.pos):
                        self.custom_page = i
                for key, r in zip(self.custom_keys_page(), self.custom_cards()):
                    if self.custom_buy_rect(r).collidepoint(e.pos):
                        self.buy_custom(key)
                    elif self.custom_up_rect(r).collidepoint(e.pos):
                        self.buy(key)
        elif self.state == "boosts":
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if pygame.Rect(350, 840, 300, 70).collidepoint(e.pos):
                    self.state = "menu"
                for n, r in zip(sorted(SPEED_SHOP), self.speed_rows()):
                    if self.speed_buy_rect(r).collidepoint(e.pos):
                        self.buy_speed(n)
                for key, r in zip(BOOST_KEYS, self.boost_rows()):
                    if self.boost_buy_rect(r).collidepoint(e.pos):
                        self.buy_boost(key)
        elif self.state == "store":
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if pygame.Rect(350, 810, 300, 70).collidepoint(e.pos):
                    self.state = "menu"
                tabs = self.store_tabs()
                if tabs[0].collidepoint(e.pos):
                    self.store_page = 0
                elif tabs[1].collidepoint(e.pos):
                    if self.medium_played:
                        self.store_page = 1
                    else:
                        self.toasts.append(["Play Medium mode once to unlock special zombie upgrades", 4.0])
                elif tabs[2].collidepoint(e.pos):
                    if self.hard_played:
                        self.store_page = 2
                    else:
                        self.toasts.append(["Play Hard mode once to unlock elite zombie upgrades", 4.0])
                for key, r in zip(self.store_keys(), self.store_rows()):
                    if self.buy_rect(r).collidepoint(e.pos):
                        self.buy(key)
        elif self.state == "spin":
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONDOWN and self.spin_t >= SPIN_T + HOLD_T:
                self.new_match()
        elif self.state == "result":
            if e.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                self.state = "menu"
        elif self.state == "play":
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:       # right-click cancels Zombie-Alike
                self.alike_cancel()
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if self.exit_btn.collidepoint(e.pos):                    # EXIT MATCH button (same as Esc)
                    if self.alike_mode:
                        self.alike_cancel()
                    self.research_open = self.boost_open = False
                    self.state = "menu"
                    return
                if self.alike_mode and self.alike_click(e.pos):          # picking towers for Zombie-Alike
                    return
                if self.phase == 'plan' and self.start_btn.collidepoint(e.pos):
                    self.begin_wave()
                    return
                for k, r in self.buttons:
                    if r.collidepoint(e.pos):
                        self.spawn(k)
                for name, tr in self.tab_rects.items():
                    if tr.collidepoint(e.pos) and name != self.tab:
                        self.tab = name
                        self.build_buttons()
                if self.speed_btn.collidepoint(e.pos):
                    self.cycle_speed()
                if self.form_btn.collidepoint(e.pos):
                    self.formation = 'spread' if self.formation == 'cluster' else 'cluster'
                if self.boost_btn.collidepoint(e.pos):
                    self.boost_open = not self.boost_open
                elif self.boost_open:
                    for key, r in self.boost_panel_rows():
                        if self.boost_use_rect(r).collidepoint(e.pos):
                            self.use_boost(key)
                if self.research_btn.collidepoint(e.pos):
                    self.research_open = not self.research_open
                elif self.research_open:
                    for key, r in self.tech_rects().items():
                        if r.collidepoint(e.pos):
                            self.buy_tech(key)
                if self.confusers() or self.alike_mode:
                    if self.conf_path_btn.collidepoint(e.pos):
                        self.use_path()
                    elif self.conf_alike_btn.collidepoint(e.pos):
                        if self.alike_mode:
                            self.alike_cancel()
                        else:
                            self.alike_start()
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    if self.alike_mode:
                        self.alike_cancel()
                    elif self.research_open or self.boost_open:
                        self.research_open = self.boost_open = False
                    else:
                        self.state = "menu"
                elif e.key in (pygame.K_SPACE, pygame.K_RETURN):
                    if self.phase == 'plan':
                        self.begin_wave()
                    elif self.alike_mode == 'target' and self.alike_picks:
                        self.alike_fire()
                elif e.key == pygame.K_e:
                    self.boost_open = not self.boost_open
                elif e.key == pygame.K_t:
                    self.research_open = not self.research_open
                elif e.key == pygame.K_p:
                    self.use_path()
                elif e.key == pygame.K_z:
                    self.alike_cancel() if self.alike_mode else self.alike_start()
                elif e.key == pygame.K_g:
                    self.formation = 'spread' if self.formation == 'cluster' else 'cluster'
                elif e.key == pygame.K_h:
                    self.show_heat = not self.show_heat
                elif self.boost_open and pygame.K_1 <= e.key <= pygame.K_4:
                    self.use_boost(BOOST_KEYS[e.key - pygame.K_1])      # 1-4 use boosts while the panel is open
                elif e.key == pygame.K_r:
                    self.show_ranges = not self.show_ranges
                elif e.key == pygame.K_TAB:
                    order = ['normal', 'special', 'elite', 'custom']
                    self.tab = order[(order.index(self.tab) + 1) % 4]
                    self.build_buttons()
                elif pygame.K_1 <= e.key <= pygame.K_9:
                    i = e.key - pygame.K_1
                    if i < len(self.buttons):
                        self.spawn(self.buttons[i][0])

    # ---------- update
    def update(self, dt):
        self.t += dt
        if not getattr(self, 'alike_mode', None):          # (particles freeze too while time is stopped)
            self.update_fx(dt)
        for t in self.toasts[:]:
            t[1] -= dt
            if t[1] <= 0:
                self.toasts.remove(t)
        if self.state == "spin":
            self.spin_t += dt
            if self.spin_t >= AUTO_T:
                self.new_match()
            return
        if self.state != "play":
            return
        if self.phase == 'plan':                   # planning: the world is frozen until START WAVE
            return
        if getattr(self, 'alike_mode', None):              # ZOMBIE-ALIKE: time is stopped until you pick the tower(s)
            return
        for _ in range(self.speed):                        # 2x / 3x speed = several small simulation steps
            self._sim(dt)
            if self.state != "play" or self.phase != 'run':
                break

    def _sim(self, dt):
        self.msg_timer = max(0, self.msg_timer - dt)
        self.base_flash = max(0.0, self.base_flash - dt)
        self.spit_flash = max(0.0, self.spit_flash - dt)
        self.spit_t = max(0.0, self.spit_t - dt)
        self.boots_t = max(0.0, self.boots_t - dt)
        self.big_t = max(0.0, self.big_t - dt)
        self.drunk_t = max(0.0, self.drunk_t - dt)
        if self.drunk_t <= 0:
            self.drunk_n = 0

        # Confuser: Illusionary Path timer + Zombie-Alike cooldowns
        if self.illusion_t > 0:
            self.illusion_t -= dt
            self.illusion_fade = min(1.0, self.illusion_fade + dt / 0.5)
            if self.illusion_t <= 0:
                self.illusion_t = 0.0
                self.end_illusion()
        else:
            self.illusion_fade = max(0.0, self.illusion_fade - dt / 0.5)
        for z in self.zombies:
            if z.kind == 'confuser':
                z.alike_cd = max(0.0, z.alike_cd - dt)
        # boosts + research that change zombies: Bigger Zombies, Heaven Boots, Thick Skin, Regeneration
        for z in self.zombies:
            z.set_big(self.big_t > 0)
            if z.tech_m != self.m['hp']:
                ratio = self.m['hp'] / z.tech_m
                z.hp *= ratio
                z.max *= ratio
                z.tech_m = self.m['hp']
            if self.m['regen'] > 0 and z.hp < z.max:
                z.hp = min(z.max, z.hp + z.max * self.m['regen'] * dt)
        bm = (BOOTS_MULT if self.boots_t > 0 else 1.0) * (BIG_SPEED if self.big_t > 0 else 1.0) * self.m['spd']
        # move zombies
        for z in self.zombies[:]:
            z.move(dt, bm)
            if z.leaped:
                z.leaped = False
                self.leap_fx(z)
            z.animate(dt)
            if z.dist >= z.map.length:
                dmg = math.ceil(z.hp)
                self.base_hp -= dmg
                self.base_hit_fx(dmg)
                self.zombies.remove(z)
        if self.base_hp <= 0:
            self.base_hp = 0
            self.finish(True)          # base destroyed -> automatic win
            return

        # Medic aura: heals nearby zombies
        for m in self.zombies:
            if m.kind == 'medic':
                mpos = m.pos
                for z in self.zombies:
                    if z is not m and z.hp < z.max and math.dist(mpos, z.pos) <= HEAL_RANGE:
                        z.hp = min(z.max, z.hp + z.max * HEAL_PCT * dt)
        # Screamer aura / Phantom phasing / Broodmother spawning / Overlord shockwave
        for z in self.zombies[:]:
            k = z.kind
            if k == 'screamer':
                zp = z.pos
                for o in self.zombies:
                    if o is not z and math.dist(zp, o.pos) <= SCREAM_RANGE:
                        o.scream_t = 0.25
            elif k in ('ghost', 'brood', 'overlord'):
                if k == 'ghost' and z.phased:
                    z.phase_t -= dt
                    if z.phase_t <= 0:
                        z.phased = False
                z.ability_t -= dt
                if z.ability_t <= 0:
                    z.ability_t = z.cd_total
                    if k == 'ghost':
                        z.phased, z.phase_t = True, PHASE_TIME
                    elif k == 'brood':
                        for j in range(BROOD_COUNT):
                            child = Zombie('zombie', z.map, self.upg)
                            child.dist = max(0.0, z.dist - 10 + j * 20)
                            self.zombies.append(child)
                            self.spawn_fx(child)
                    else:
                        zx, zy = z.pos
                        for t in self.towers:
                            if math.dist((zx, zy), t.pos) <= OVERLORD_RANGE:
                                t.stun = max(t.stun, OVERLORD_STUN)
                        self.add_fx(type='ring', pos=[zx, zy], t=0.0, life=0.7, r0=10, r1=OVERLORD_RANGE, col=(255, 70, 90), layer=0)
        # mortar shells in flight
        for sh_ in self.shells[:]:
            sh_[0] -= dt
            if sh_[0] <= 0:
                self.shells.remove(sh_)
                lx, ly = sh_[1]
                self.add_fx(type='ring', pos=[lx, ly], t=0.0, life=0.35, r0=6, r1=sh_[3], col=(255, 170, 60), layer=0)
                for _ in range(8):
                    a = random.uniform(0, 2 * math.pi)
                    sp = random.uniform(40, 150)
                    self.add_fx(type='puff', pos=[lx, ly], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0, life=0.4,
                                col=random.choice([(255, 180, 70), (120, 120, 120)]), r0=random.uniform(4, 8), r1=1, layer=1)
                for z in self.zombies[:]:
                    if z.dist >= 0 and math.dist((lx, ly), z.pos) <= sh_[3]:
                        self.damage(z, sh_[2])
        # towers
        # Stunner ability: spit on the nearest un-stunned tower in range
        for z in self.zombies:
            if z.kind == 'stun':
                z.ability_t -= dt
                if z.ability_t <= 0:
                    zp = z.pos
                    cands = [t for t in self.towers if t.stun <= 0 and math.dist(zp, t.pos) <= STUN_RANGE]
                    if cands:
                        tgt = min(cands, key=lambda t: math.dist(zp, t.pos))
                        tgt.stun = STUN_TIME
                        z.ability_t = z.stun_cd
                        self.shots.append([zp, tgt.pos, 0.3, 'spit'])
                        self.splash_fx(tgt.pos)
                    else:
                        z.ability_t = 0.0      # ready, waits for a tower to come in range
        has_cmd = any(t.kind == 'cmd' and t.stun <= 0 for t in self.towers)
        for t in self.towers:
            t.fire_t = max(0.0, t.fire_t - dt)
            if t.stun > 0:
                t.stun = max(0.0, t.stun - dt)
                t.hijack_t = 0.0
                continue
            st = t.stats
            dmg = st[0] * TOWER_DMG_MULT * self.m['tdmg']
            cd = st[1] * self.m['tcd']
            rng = st[2] * self.m['trng']
            if has_cmd and t.kind != 'cmd':
                dmg *= CMD_DMG_BONUS
                cd *= CMD_CD_MULT
            if self.drunk_t > 0:                       # Drunk Towers boost
                cd *= DRUNK_CD_MULT
            if t.hijack_t > 0:                         # Zombie-Alike: this tower shoots OTHER towers
                t.hijack_t -= dt
                t.cd -= dt
                if t.cd <= 0:
                    t.cd += max(cd, 0.3)
                    for tg in t.hijack_targets:
                        t.aim, t.fire_t = math.atan2(tg.pos[1] - t.pos[1], tg.pos[0] - t.pos[0]), 0.12
                        self.shots.append([t.pos, tg.pos, 0.1, 'alike'])
                continue
            t.cd -= dt
            if t.cd > 0:
                continue
            best = self.pick_target(t, rng)
            if best is None:
                t.cd = 0
                continue
            t.cd += cd
            miss = (self.drunk_t > 0 and random.random() < DRUNK_MISS * self.drunk_n) or random.random() < self.m['miss']
            if t.kind == 'shot':
                # Shotgunner: hits EVERY zombie inside a cone aimed at the front-most one
                bx_, by_ = best.pos
                aim = math.atan2(by_ - t.pos[1], bx_ - t.pos[0])
                half = math.radians(st[3] / 2)
                t.aim, t.fire_t = aim, 0.15
                self.blast_fx(t, aim, half, rng)
                if miss:
                    self.miss_fx(best.pos)
                for z in ([] if miss else [o for o in self.zombies if o.dist >= 0]):
                    zx, zy = z.pos
                    d = math.hypot(zx - t.pos[0], zy - t.pos[1])
                    if d <= rng:
                        diff = (math.atan2(zy - t.pos[1], zx - t.pos[0]) - aim + math.pi) % (2 * math.pi) - math.pi
                        if abs(diff) <= half:
                            self.damage(z, dmg)
            elif t.kind == 'mortar':
                # Mortar: lobbed shell that lands where the target WILL be and blasts everything nearby
                bx_, by_ = best.pos
                t.aim, t.fire_t = math.atan2(by_ - t.pos[1], bx_ - t.pos[0]), 0.2
                lx, ly = best.map.pos_at(best.dist + best.speed * MORTAR_FLIGHT)
                if miss:
                    lx, ly = lx + random.uniform(-90, 90), ly + random.uniform(-90, 90)
                    self.miss_fx((lx, ly))
                self.shells.append([MORTAR_FLIGHT, (lx, ly), dmg, MORTAR_R[t.lvl], t.pos])
                self.add_fx(type='shell', a=[t.pos[0], t.pos[1]], b=[lx, ly], pos=[t.pos[0], t.pos[1]], t=0.0, life=MORTAR_FLIGHT, layer=1)
            elif t.kind == 'tesla':
                # Tesla: arc that chains from the target to nearby zombies
                bx_, by_ = best.pos
                t.aim, t.fire_t = math.atan2(by_ - t.pos[1], bx_ - t.pos[0]), 0.15
                chain, cur, dd = [best], best, dmg
                for _j in range(TESLA_JUMPS[t.lvl]):
                    nxt = None
                    for o in self.zombies:
                        if o not in chain and o.dist >= 0 and not o.phased and math.dist(cur.pos, o.pos) <= TESLA_RANGE:
                            if nxt is None or math.dist(cur.pos, o.pos) < math.dist(cur.pos, nxt.pos):
                                nxt = o
                    if nxt is None:
                        break
                    chain.append(nxt)
                    cur = nxt
                pts = [list(t.pos)] + [list(c.pos) for c in chain]
                self.add_fx(type='arc', pts=pts, t=0.0, life=0.16, layer=1)
                if miss:
                    self.miss_fx(best.pos)
                else:
                    for c in chain:
                        self.damage(c, dd)
                        dd *= TESLA_FALLOFF
            elif t.kind == 'cryo':
                # Cryo: weak hit that SLOWS the zombie
                bx_, by_ = best.pos
                t.aim, t.fire_t = math.atan2(by_ - t.pos[1], bx_ - t.pos[0]), 0.12
                if miss:
                    self.shots.append([t.pos, (bx_ + random.uniform(-45, 45), by_ + random.uniform(-45, 45)), 0.07, t.kind])
                    self.miss_fx(best.pos)
                else:
                    self.shots.append([t.pos, best.pos, 0.07, t.kind])
                    fac, dur = CRYO_SLOW[t.lvl]
                    best.slow_mult = min(best.slow_mult if best.slow_t > 0 else 1.0, fac)
                    best.slow_t = max(best.slow_t, dur)
                    self.damage(best, dmg)
            else:
                bx_, by_ = best.pos
                t.aim = math.atan2(by_ - t.pos[1], bx_ - t.pos[0])      # turret turns to face its target
                t.fire_t = 0.12
                if miss:                                # shot flies wide
                    self.shots.append([t.pos, (bx_ + random.uniform(-45, 45), by_ + random.uniform(-45, 45)), 0.07, t.kind])
                    self.miss_fx(best.pos)
                else:
                    self.shots.append([t.pos, best.pos, 0.07, t.kind])
                    self.damage(best, dmg)

        for s in self.shots[:]:
            s[2] -= dt
            if s[2] <= 0:
                self.shots.remove(s)

        # automatic wave completion: nothing alive and nothing left to send
        if not self.zombies and not self.can_spawn():
            self.complete_timer += dt
            if self.complete_timer >= WAVE_END_DELAY:
                self.next_wave()       # after the last wave this ends the match (loss)
        else:
            self.complete_timer = 0.0

    # ---------- drawing helpers
    def text(self, s, font, col, pos, center=False, shadow=False):
        img = font.render(s, True, col)
        r = img.get_rect()
        if center:
            r.center = pos
        else:
            r.topleft = pos
        if shadow:                                                 # dark drop-shadow so text reads on any ground
            sh = font.render(s, True, (10, 14, 10))
            self.screen.blit(sh, sh.get_rect(center=(r.centerx + 1, r.centery + 2)))
        self.screen.blit(img, r)

    def minimap(self, mp, rect):
        sc = self.screen
        th = THEMES[mp.name]
        pygame.draw.rect(sc, _col(th['ground'], 0.85), rect, border_radius=10)
        pygame.draw.rect(sc, (160, 230, 150), rect, 3, border_radius=10)
        pts = [(rect.x + x * rect.w / W, rect.y + y * rect.h / H) for x, y in mp.path]
        pygame.draw.lines(sc, th['path'], False, pts, 12)
        for p in pts:
            pygame.draw.circle(sc, th['path'], p, 6)
        pygame.draw.circle(sc, (90, 220, 90), pts[0], 9)
        pygame.draw.circle(sc, (220, 70, 70), pts[-1], 9)

    def draw(self):
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "spin":
            self.draw_spin()
        elif self.state == "store":
            self.draw_store()
        elif self.state == "custom":
            self.draw_custom()
        elif self.state == "boosts":
            self.draw_boosts()
        elif self.state == "ach":
            self.draw_ach()
        else:
            self.draw_play()
            if self.state == "result":
                self.draw_result()
        self.draw_toasts()
        present()

    def draw_menu(self):
        sc = self.screen
        sc.fill((25, 40, 28))
        self.text("ZOMBIE RUSH", self.f_xl, (120, 210, 90), (W // 2, 250), True)
        self.text("Reverse tower defense - destroy the enemy base!", self.f_m, (200, 220, 200), (W // 2, 330), True)
        self.text(f"Coins: {self.coins}", self.f_l, (250, 210, 60), (W // 2, 402), True)
        mp = mouse_pos()
        for _action, label, rect in self.menu_buttons():
            locked = (_action == 'medium' and not self.owned) or (_action == 'hard' and not self.hard_ok())
            col = (70, 150, 70) if rect.collidepoint(mp) else (45, 110, 50)
            if locked:
                col = (52, 58, 54)
            pygame.draw.rect(sc, col, rect, border_radius=12)
            pygame.draw.rect(sc, (95, 105, 98) if locked else (160, 230, 150), rect, 3, border_radius=12)
            if _action in ('easy', 'medium', 'hard'):
                sub = {'easy': "10 waves", 'medium': "LOCKED: need 1 custom" if locked else "15 waves",
                       'hard': "LOCKED: 2 custom + Medium" if locked else "20 waves"}[_action]
                self.text(label, self.f_m, (140, 150, 142) if locked else (255, 255, 255), (rect.centerx, rect.centery - 11), True)
                self.text(sub, self.f_s, (150, 160, 150) if locked else (200, 235, 200), (rect.centerx, rect.centery + 16), True)
            else:
                self.text(label, self.f_m, (255, 255, 255), rect.center, True)
        self.text("A random map is picked every match", self.f_s, (150, 170, 150), (W // 2, 872), True)
        self.text("Medium needs 1 custom zombie  -  Hard needs 2 custom zombies + a played Medium match", self.f_s, (150, 170, 150), (W // 2, 897), True)
        for i, kind in enumerate(ZSPEC):                      # zombie parade along the bottom
            x = (self.t * 55 + i * 135) % (W + 160) - 80
            self.blit_zombie(kind, x, 952, 0, (x / (SIZE[kind] * 0.6)) % 1.0, max_px=70)

    def draw_store(self):
        sc = self.screen
        sc.fill((25, 40, 28))
        self.text("UPGRADE STORE", self.f_l, (120, 210, 90), (W // 2 + 130, 50), True)
        self.text(f"Coins: {self.coins}", self.f_m, (250, 210, 60), (W // 2, 100), True)
        mp = mouse_pos()
        for i, (tr, name) in enumerate(zip(self.store_tabs(), ("BASIC", "SPECIAL", "ELITE"))):
            locked = (i == 1 and not self.medium_played) or (i == 2 and not self.hard_played)
            active = i == self.store_page
            pygame.draw.rect(sc, (60, 100, 60) if active else ((38, 42, 40) if locked else (35, 55, 38)), tr, border_radius=8)
            pygame.draw.rect(sc, (160, 230, 150) if active else (90, 105, 92), tr, 2, border_radius=8)
            self.text(name + (" (locked)" if locked else ""), self.f_s, (150, 160, 150) if locked else (255, 255, 255), tr.center, True)
        for key, r in zip(self.store_keys(), self.store_rows()):
            d = UPGRADES[key]
            lvl = self.upg[key]
            ucol = UNITS[d['unit']]['col']
            pygame.draw.rect(sc, (40, 60, 42), r, border_radius=10)
            pygame.draw.rect(sc, ucol, r, 3, border_radius=10)
            self.blit_zombie(d['unit'], r.x + 30, r.y + 45, 0, (self.t * 1.4) % 1.0, max_px=66)
            self.text(d['label'], self.f_m, (255, 255, 255), (r.x + 58, r.y + 10))
            if lvl >= MAX_UP:
                desc = f"{upg_value(key, lvl):g} {d['suffix']}  (MAX)"
            else:
                desc = f"{upg_value(key, lvl):g}  ->  {upg_value(key, lvl + 1):g} {d['suffix']}   (+{d['step']:g} per level)"
            self.text(desc, self.f_s, (200, 220, 200), (r.x + 58, r.y + 40))
            for j in range(MAX_UP):
                col = (250, 210, 60) if j < lvl else (70, 85, 70)
                pygame.draw.rect(sc, col, (r.x + 58 + j * 17, r.y + 66, 13, 12))
            self.text(f"Lv {lvl}/{MAX_UP}", self.f_s, (255, 255, 255), (r.x + 58 + MAX_UP * 17 + 8, r.y + 63))
            b = self.buy_rect(r)
            if lvl >= MAX_UP:
                bcol, label = (70, 70, 80), "MAXED"
            else:
                cost = upg_cost(key, lvl)
                ok = self.coins >= cost
                bcol = ((80, 150, 80) if b.collidepoint(mp) else (55, 115, 60)) if ok else (90, 50, 50)
                label = f"BUY  {cost}"
            pygame.draw.rect(sc, bcol, b, border_radius=8)
            pygame.draw.rect(sc, (255, 255, 255), b, 2, border_radius=8)
            self.text(label, self.f_m, (255, 255, 255), b.center, True)
        back = pygame.Rect(350, 810, 300, 70)
        pygame.draw.rect(sc, (70, 150, 70) if back.collidepoint(mp) else (45, 110, 50), back, border_radius=12)
        pygame.draw.rect(sc, (160, 230, 150), back, 3, border_radius=12)
        self.text("BACK", self.f_m, (255, 255, 255), back.center, True)

    # ---------- damage + deaths
    def damage(self, z, dmg):
        if z not in self.zombies or z.phased:        # a phased-out Phantom can't be hurt
            return
        dmg *= 1 - ARMOR.get(z.kind, 0)              # Juggernaut armour
        dmg *= 1 - self.m['dr']                      # Iron Hide research
        if z.shield > 0:                       # Riot: the shield soaks damage first
            absorbed = min(z.shield, dmg)
            z.shield -= absorbed
            dmg -= absorbed
        z.hp -= dmg
        z.flash = 0.08
        if z.hp <= 0:
            self.kill(z)

    def kill(self, z):
        if z in self.zombies:
            self.zombies.remove(z)
        z.reward = int(round(z.reward * self.m['rew']))       # Scavengers / Bounty Day
        self.money += z.reward
        self.money_earned += z.reward
        self.death_fx(z)
        if z.kind == 'rand':                   # 'mysterious' effect: becomes a Zombie or a Speedy
            child = Zombie(random.choice(['zombie', 'speedy']), z.map, self.upg)
            child.dist = z.dist
            self.zombies.append(child)
            self.spawn_fx(child)
        elif z.kind == 'splitter':             # splits into two zombies
            for k in range(SPLIT_COUNT):
                child = Zombie('zombie', z.map, self.upg)
                child.dist = z.dist + (k - 0.5) * 14
                self.zombies.append(child)
                self.spawn_fx(child)
        elif z.kind == 'bomber':               # explodes and stuns nearby towers
            x, y = z.pos
            for t in self.towers:
                if math.dist((x, y), t.pos) <= BOMB_RANGE:
                    t.stun = max(t.stun, BOMB_STUN)
            self.add_fx(type='ring', pos=[x, y], t=0.0, life=0.5, r0=8, r1=BOMB_RANGE, col=(255, 150, 50), layer=0)
            for _ in range(16):
                a = random.uniform(0, 2 * math.pi)
                sp = random.uniform(80, 220)
                self.add_fx(type='puff', pos=[x, y], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0,
                            life=random.uniform(0.3, 0.6), col=random.choice([(255, 170, 50), (255, 90, 40), (90, 90, 90)]),
                            r0=random.uniform(5, 9), r1=1, layer=1)

    def blast_fx(self, t, aim, half, rng):
        rays = [random.uniform(-half, half) for _ in range(10)]
        self.add_fx(type='blast', pos=[t.pos[0], t.pos[1]], angle=aim, half=half, rng=rng, rays=rays,
                    t=0.0, life=0.18, layer=1)

    def leap_fx(self, z):
        x, y = z.pos
        for _ in range(6):
            a = random.uniform(0, 2 * math.pi)
            sp = random.uniform(20, 70)
            self.add_fx(type='puff', pos=[x, y + z.off], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0,
                        life=0.4, col=(200, 190, 160), r0=5, r1=1, layer=0)

    # ---------- tower drawing
    def ring_a(self, x, y, R, col, alpha, width=3):
        R = max(4, int(R))
        surf = pygame.Surface((R * 2 + 4, R * 2 + 4), pygame.SRCALPHA)
        pygame.draw.circle(surf, (col[0], col[1], col[2], max(0, min(255, int(alpha)))), (R + 2, R + 2), R, width)
        self.screen.blit(surf, (int(x - R - 2), int(y - R - 2)))

    def draw_tower(self, t):
        """Textured, turning turrets: each tower faces its target and kicks back when it fires."""
        sc = self.screen
        x, y = t.pos
        lvl = t.lvl
        ux, uy = math.cos(t.aim), math.sin(t.aim)
        px, py = -uy, ux                                   # sideways direction
        kick = 4 * t.fire_t / 0.12 if t.fire_t > 0 else 0.0
        cx_, cy_ = x - ux * kick, y - uy * kick
        trim = (190, 196, 208) if lvl == 3 else (236, 196, 60) if lvl == 4 else None      # upgrade trim colour
        firing = t.fire_t > 0

        def P(a, b=0.0):
            return (cx_ + ux * a + px * b, cy_ + uy * a + py * b)

        def tube(a0, a1, b, w, col):
            pygame.draw.line(sc, OUT, P(a0, b), P(a1, b), w + 4)
            pygame.draw.line(sc, col, P(a0, b), P(a1, b), w)

        def disc(col, r, ox=0.0, oy=0.0):
            pygame.draw.circle(sc, col, (int(x + ox), int(y + oy)), r)

        if t.kind == 'scout':                              # sniper nest: round base + long scoped rifle
            body = (60, 110, 220)
            disc(OUT, 23)
            disc(_col(body, 0.7), 20)
            disc(body, 17, -1, -2)
            disc(_col(body, 1.3), 7, -5, -6)
            if trim:
                pygame.draw.circle(sc, trim, (int(x), int(y)), 21, 3)
            for sd in (-1, 1):                              # little sandbags
                pygame.draw.circle(sc, (150, 130, 90), (int(x + px * sd * 17 - ux * 9), int(y + py * sd * 17 - uy * 9)), 5)
            tube(-12, 14, 0, 9, (96, 68, 44))               # stock
            tube(8, 38, 0, 5, (40, 42, 50))                 # barrel
            tube(10, 36, 0, 3, (160, 166, 178))
            pygame.draw.circle(sc, OUT, (int(P(38)[0]), int(P(38)[1])), 4)      # muzzle brake
            tube(12, 24, 0, 7, (52, 76, 130))               # scope
            pygame.draw.circle(sc, (130, 230, 255), (int(P(25)[0]), int(P(25)[1])), 3)
            if firing:
                pygame.draw.circle(sc, (255, 240, 150), (int(P(42)[0]), int(P(42)[1])), 7)
        elif t.kind == 'mini':                             # armoured red gun platform with a 3-barrel gatling
            body = (210, 60, 60)
            pygame.draw.rect(sc, OUT, (x - 23, y - 23, 46, 46), border_radius=8)
            pygame.draw.rect(sc, _col(body, 0.7), (x - 20, y - 20, 40, 40), border_radius=6)
            pygame.draw.rect(sc, body, (x - 19, y - 20, 36, 36), border_radius=6)
            pygame.draw.rect(sc, _col(body, 1.25), (x - 16, y - 17, 18, 12), border_radius=4)
            if trim:
                pygame.draw.rect(sc, trim, (x - 22, y - 22, 44, 44), 3, border_radius=7)
            for dx, dy in ((-16, -16), (16, -16), (-16, 16), (16, 16)):          # rivets
                pygame.draw.circle(sc, (235, 200, 200), (int(x + dx), int(y + dy)), 2)
            bx1, by1 = P(-4, -27)                           # ammo box with a feed belt
            box = [P(-12, -34), P(8, -34), P(8, -22), P(-12, -22)]
            pygame.draw.polygon(sc, OUT, box)
            pygame.draw.polygon(sc, (96, 108, 62), [P(-10, -32), P(6, -32), P(6, -24), P(-10, -24)])
            pygame.draw.line(sc, (214, 176, 70), P(-2, -22), P(2, -8), 3)
            disc(OUT, 14, cx_ - x, cy_ - y)
            pygame.draw.circle(sc, (88, 92, 104), (int(cx_), int(cy_)), 11)
            pygame.draw.circle(sc, (130, 134, 146), (int(cx_ - 3), int(cy_ - 3)), 5)
            hot = int(self.t * 30) % 3 if firing else -1
            for i, b in enumerate((-6, 0, 6)):             # barrels (one glows while firing)
                tube(6, 36, b, 5, (255, 160, 70) if i == hot else (68, 72, 84))
            tube(18, 23, 0, 19, (116, 120, 132))            # barrel shroud
            if firing:
                pygame.draw.circle(sc, (255, 230, 120), (int(P(40)[0]), int(P(40)[1])), 7)
        elif t.kind == 'shot':                             # double-barrel scatter gun
            pygame.draw.circle(sc, (50, 30, 18), (int(cx_), int(cy_)), 23)
            pygame.draw.circle(sc, (158, 94, 40), (int(cx_), int(cy_)), 20)
            pygame.draw.circle(sc, (196, 118, 52), (int(cx_ - 1), int(cy_ - 2)), 17)
            pygame.draw.circle(sc, (228, 164, 92), (int(cx_ - 5), int(cy_ - 6), ), 8)
            if trim:
                pygame.draw.circle(sc, trim, (int(cx_), int(cy_)), 22, 3)
            tube(-10, 12, 0, 12, (104, 70, 40))             # wooden stock
            for b in (-5, 5):
                tube(4, 34, b, 7, (130, 134, 144))
                pygame.draw.circle(sc, OUT, (int(P(34, b)[0]), int(P(34, b)[1])), 4)
            tube(10, 14, 0, 18, (200, 150, 70))             # brass band
            if firing:
                pygame.draw.circle(sc, (255, 210, 90), (int(P(40)[0]), int(P(40)[1])), 10)
        elif t.kind == 'cryo':                             # frost projector: icy base + spinning snowflake emitter
            disc(OUT, 23)
            disc((100, 160, 214), 20)
            disc((150, 208, 246), 17, -1, -2)
            disc((206, 238, 255), 7, -5, -6)
            if trim:
                pygame.draw.circle(sc, trim, (int(x), int(y)), 21, 3)
            for k in range(3):                              # snowflake
                a = self.t * 0.6 + k * math.pi / 3
                pygame.draw.line(sc, (255, 255, 255), (x - math.cos(a) * 12, y - math.sin(a) * 12), (x + math.cos(a) * 12, y + math.sin(a) * 12), 2)
            tube(6, 30, 0, 11, (82, 130, 182))              # nozzle
            tube(26, 32, 0, 15, (190, 232, 255))
            pygame.draw.circle(sc, (230, 250, 255), (int(P(34)[0]), int(P(34)[1])), 4)
            if firing:
                for k in range(5):
                    pygame.draw.circle(sc, (220, 245, 255), (int(P(40 + k * 5, (k - 2) * 4)[0]), int(P(40 + k * 5, (k - 2) * 4)[1])), 2)
        elif t.kind == 'mortar':                           # squat bunker with a fat lobbing tube and a shell rack
            pygame.draw.rect(sc, OUT, (x - 24, y - 24, 48, 48), border_radius=10)
            pygame.draw.rect(sc, (66, 76, 50), (x - 21, y - 21, 42, 42), border_radius=8)
            pygame.draw.rect(sc, (96, 110, 72), (x - 20, y - 20, 36, 34), border_radius=7)
            if trim:
                pygame.draw.rect(sc, trim, (x - 23, y - 23, 46, 46), 3, border_radius=9)
            for k in range(3):                              # shells
                sx_, sy_ = P(-12 - k * 7, 22)
                pygame.draw.circle(sc, OUT, (int(sx_), int(sy_)), 5)
                pygame.draw.circle(sc, (214, 170, 70), (int(sx_), int(sy_)), 3)
            tube(-6, 24, 0, 17, (52, 56, 48))               # barrel
            tube(-4, 22, 0, 11, (110, 118, 96))
            tube(20, 27, 0, 21, (36, 38, 34))               # muzzle ring
            pygame.draw.circle(sc, (14, 16, 14), (int(P(27)[0]), int(P(27)[1])), 6)
            if firing:
                pygame.draw.circle(sc, (200, 200, 200), (int(P(34)[0]), int(P(34)[1])), 11)
                pygame.draw.circle(sc, (255, 190, 80), (int(P(30)[0]), int(P(30)[1])), 6)
        elif t.kind == 'tesla':                            # copper coil with a crackling orb
            disc(OUT, 24)
            disc((54, 54, 66), 21)
            for k, r in enumerate((17, 13, 9)):
                disc((196, 112, 56), r)
                disc((226, 150, 84), r - 3)
            pulse = 6 + 2 * math.sin(self.t * 8)
            pygame.draw.circle(sc, (120, 160, 255), (int(x), int(y)), int(pulse + 4))
            pygame.draw.circle(sc, (210, 230, 255), (int(x), int(y)), int(pulse))
            pygame.draw.circle(sc, (255, 255, 255), (int(x - 2), int(y - 2)), 3)
            if trim:
                pygame.draw.circle(sc, trim, (int(x), int(y)), 23, 3)
            rnd = random.Random(int(self.t * 14) + int(x))
            for _ in range(3 if not firing else 6):          # sparks
                a = rnd.uniform(0, 6.28)
                pygame.draw.line(sc, (190, 210, 255), (x + math.cos(a) * 8, y + math.sin(a) * 8),
                                 (x + math.cos(a + rnd.uniform(-0.4, 0.4)) * rnd.uniform(15, 26), y + math.sin(a) * rnd.uniform(15, 26)), 1)
        else:                                              # commander: gold fortress with a spinning radar
            if t.stun <= 0:
                ph = (self.t * 0.6) % 1.0
                self.ring_a(x, y, 30 + 90 * ph, (255, 220, 90), 110 * (1 - ph), 3)       # aura pulse
            gold = (240, 200, 50)
            oct_ = lambda r: [(x + math.cos(math.radians(22.5 + k * 45)) * r, y + math.sin(math.radians(22.5 + k * 45)) * r) for k in range(8)]
            pygame.draw.polygon(sc, OUT, oct_(28))
            pygame.draw.polygon(sc, _col(gold, 0.7), oct_(25))
            pygame.draw.polygon(sc, gold, oct_(22))
            pygame.draw.polygon(sc, (255, 236, 150), [(x - 14, y - 14), (x + 6, y - 14), (x - 14, y + 6)])
            disc(OUT, 14)
            disc((70, 56, 22), 11)
            rot = self.t * 1.8 if t.stun <= 0 else 0.7
            ex, ey = x + math.cos(rot) * 17, y + math.sin(rot) * 17
            pygame.draw.line(sc, OUT, (x, y), (ex, ey), 9)
            pygame.draw.line(sc, (190, 196, 208), (x, y), (ex, ey), 5)
            pygame.draw.circle(sc, OUT, (int(ex), int(ey)), 7)
            pygame.draw.circle(sc, (240, 244, 250), (int(ex), int(ey)), 5)
            blink = int(self.t * 2) % 2 == 0
            pygame.draw.circle(sc, (255, 70, 60) if blink else (120, 30, 30), (int(x), int(y)), 4)
            for k in range(4):
                a = math.radians(45 + 90 * k)
                pygame.draw.circle(sc, (255, 255, 230), (int(x + math.cos(a) * 21), int(y + math.sin(a) * 21)), 2)
        if self.drunk_t > 0:                               # Drunk Towers: purple pulse + orbiting stars
            self.ring_a(x, y, 27 + 3 * math.sin(self.t * 6), (200, 150, 255), 160, 2)
            for k in range(3):
                a = self.t * 3 + k * 2.1
                pygame.draw.circle(sc, (230, 200, 255), (int(x + math.cos(a) * 28), int(y + math.sin(a) * 28 - 4)), 3)
        # level badge
        bx, by = x + 18, y + 18
        pygame.draw.circle(sc, OUT, (bx, by), 10)
        pygame.draw.circle(sc, (236, 196, 60) if lvl == 4 else (190, 196, 208) if lvl == 3 else (126, 136, 130), (bx, by), 8)
        self.text(str(lvl), self.f_xs, (20, 24, 20), (bx, by), True)

    # ---------- zombie drawing + effects
    def blob_a(self, x, y, r, col, alpha):
        """Soft translucent disc (used for smoke / dust / aura)."""
        r = max(1, int(r))
        s = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (col[0], col[1], col[2], max(0, min(255, int(alpha)))), (r + 1, r + 1), r)
        self.screen.blit(s, (int(x - r - 1), int(y - r - 1)))

    def blit_zombie(self, kind, x, y, ang=0.0, phase=0.0, flash=False, scale=1.0, alpha=255, max_px=None):
        if max_px and SIZE[kind] * scale > max_px:
            scale = max_px / SIZE[kind]
        spr = get_sprite(kind, int(math.floor(phase * FRAMES)) % FRAMES, ang, flash, scale)
        if alpha < 255:
            spr = spr.copy()
            spr.set_alpha(alpha)
        self.screen.blit(spr, spr.get_rect(center=(x, y)))

    def draw_zombie(self, z):
        sc = self.screen
        x, y = z.pos
        y += z.off
        kind, t = z.kind, self.t
        size = SIZE[kind]
        phase = (z.dist / (size * 0.6)) % 1.0                 # one walk cycle per stride
        ang = z.angle + math.sin(phase * 2 * math.pi) * SWAY[kind]
        bob = math.sin(phase * 4 * math.pi) * (0.8 + size / 70)
        sh = SHADOWS[kind]
        sc.blit(sh, sh.get_rect(center=(x + 2, y + size * 0.14)))
        if self.boots_t > 0:                                  # Heaven Boots: cyan speed streaks
            for k_, off_ in enumerate((-10, 0, 10)):
                px_, py_ = x + math.cos(math.radians(z.angle) + math.pi / 2) * off_, y + math.sin(math.radians(z.angle) + math.pi / 2) * off_
                bx0, by0 = -math.cos(math.radians(z.angle)), -math.sin(math.radians(z.angle))
                pygame.draw.line(sc, (140, 230, 255), (px_ + bx0 * size * 0.3, py_ + by0 * size * 0.3),
                                 (px_ + bx0 * size * (0.55 + 0.1 * k_), py_ + by0 * size * (0.55 + 0.1 * k_)), 2)
        if kind in ('speedy', 'bolt', 'sboss'):               # after-image trail
            for k, a in ((1, 90), (2, 45)):
                gx, gy = z.map.pos_at(z.dist - k * 13)
                self.blit_zombie(kind, gx, gy + z.off, ang, phase - 0.1 * k, alpha=a)
        if kind == 'boss':
            self.blob_a(x, y, size * 0.5 + 3 * math.sin(t * 3), (170, 70, 220), 40)
        elif kind == 'sboss':
            self.blob_a(x, y, size * 0.5 + 3 * math.sin(t * 4), (255, 140, 50), 40)
        elif kind == 'overlord':
            self.blob_a(x, y, size * 0.5 + 4 * math.sin(t * 3), (255, 50, 80), 45)
        lift = 0.0
        if z.leap_t > 0:                                      # Leaper: jump (sprite grows, shadow stays)
            lift = math.sin(math.pi * (1 - z.leap_t / LEAP_TIME))
        scale = 1.0
        if z.age < 0.3:                                       # pop-in when spawned
            scale = 0.35 + 0.65 * (1 - (1 - z.age / 0.3) ** 2)
            if scale >= 0.995:
                scale = 1.0
        if lift > 0:
            scale = scale * (1 + 0.3 * lift)
        if z.big:                                             # Bigger Zombies boost
            scale = scale * BIG_SCALE
        alpha = 255
        if z.phased:                                          # Phantom: flickering ghost form
            alpha = int(70 + 30 * math.sin(t * 22))
        self.blit_zombie(kind, x, y + bob - lift * 8, ang, phase, flash=z.flash > 0, scale=scale, alpha=alpha)
        if z.slow_t > 0:                                      # Cryo slow: icy glow + flakes
            self.blob_a(x, y, size * 0.42, (150, 220, 255), 60)
            for k_ in range(3):
                a_ = t * 2 + k_ * 2.1
                pygame.draw.circle(sc, (235, 250, 255), (int(x + math.cos(a_) * size * 0.35), int(y + math.sin(a_) * size * 0.35)), 2)
        self.zombie_fx(z, x, y, t, size)

    def zombie_fx(self, z, x, y, t, size):
        """Per-zombie animated extras drawn on top of the sprite."""
        sc, k = self.screen, z.kind
        rad = math.radians(z.angle)
        bx, by = -math.cos(rad), -math.sin(rad)               # unit vector pointing behind the zombie
        if k == 'bolt':                                       # flickering electric arcs
            rnd = random.Random(int(t * 16) * 31 + id(z) % 97)
            for _ in range(2):
                a = rnd.uniform(0, 2 * math.pi)
                pts = [(x + math.cos(a) * size * 0.2, y + math.sin(a) * size * 0.2)]
                for s_ in range(1, 4):
                    aa = a + rnd.uniform(-0.5, 0.5)
                    rr = size * (0.2 + 0.17 * s_)
                    pts.append((x + math.cos(aa) * rr, y + math.sin(aa) * rr))
                pygame.draw.lines(sc, (255, 245, 140), False, pts, 2)
        elif k == 'rand':                                     # twinkling stars
            for i, c in enumerate(((255, 255, 150), (150, 255, 255), (255, 160, 255))):
                a = t * 2.4 + i * 2.1
                rr = size * 0.5 + 3 * math.sin(t * 6 + i)
                sx, sy = x + math.cos(a) * rr, y + math.sin(a) * rr
                r_ = 3 + 2 * math.sin(t * 9 + i * 2)
                pygame.draw.line(sc, c, (sx - r_, sy), (sx + r_, sy), 2)
                pygame.draw.line(sc, c, (sx, sy - r_), (sx, sy + r_), 2)
        elif k == 'stun':                                     # toxic bubbles + spit-charge ring
            for i in range(3):
                ph = (t * 0.8 + i / 3) % 1.0
                px = x + (i - 1) * 9 + math.sin(t * 3 + i) * 3
                py = y - size * 0.1 - ph * size * 0.5
                pygame.draw.circle(sc, (170, 255, 100), (int(px), int(py)), int(2 + 3 * ph), 1)
            if z.stun_cd:
                frac = 1.0 - max(0.0, z.ability_t) / z.stun_cd
                rr = int(size * 0.48)
                if frac > 0.03:
                    col = (140, 255, 90) if frac < 0.999 else (255, 255, 120)
                    pygame.draw.arc(sc, col, pygame.Rect(int(x) - rr, int(y) - rr, rr * 2, rr * 2),
                                    0, 2 * math.pi * min(frac, 1.0), 3)
        elif k == 'tank':                                     # exhaust smoke
            for i in range(3):
                ph = (t * 1.2 + i / 3) % 1.0
                d = size * 0.42 + ph * size * 0.5
                self.blob_a(x + bx * d, y + by * d - ph * 10, 3 + ph * 7, (150, 150, 150), 150 * (1 - ph))
        elif k == 'medic':                                    # healing aura + floating crosses
            self.blob_a(x, y, HEAL_RANGE * (0.92 + 0.04 * math.sin(t * 3)), (90, 255, 150), 16)
            for i in range(2):
                ph = (t * 0.7 + i * 0.5) % 1.0
                px, py = x + (i * 2 - 1) * 14, y - size * 0.2 - ph * 30
                pygame.draw.line(sc, (120, 255, 160), (px - 4, py), (px + 4, py), 2)
                pygame.draw.line(sc, (120, 255, 160), (px, py - 4), (px, py + 4), 2)
        elif k == 'bomber':                                   # fizzing fuse
            rnd = random.Random(int(t * 20) * 7 + id(z) % 89)
            sx, sy = x + bx * size * 0.42, y + by * size * 0.42
            for _ in range(3):
                pygame.draw.circle(sc, (255, rnd.randint(150, 230), 60),
                                   (int(sx + rnd.uniform(-5, 5)), int(sy + rnd.uniform(-5, 5))), 2)
        elif k == 'ghost':                                    # sparkles while phased
            if z.phased:
                for i in range(3):
                    a = t * 5 + i * 2.1
                    pygame.draw.circle(sc, (220, 245, 255), (int(x + math.cos(a) * size * 0.4), int(y + math.sin(a) * size * 0.4)), 2)
        elif k == 'brood':                                    # glows when a new brood is about to hatch
            if z.cd_total and z.ability_t < 0.9:
                self.ring_a(x, y, size * 0.5 + 8 * (1 - z.ability_t / 0.9), (170, 255, 120), 150, 3)
        elif k == 'screamer':                                 # pulsing sound-wave ring over its boost radius
            ph = (t * 1.2) % 1.0
            self.ring_a(x, y, SCREAM_RANGE * ph, (255, 150, 150), 80 * (1 - ph), 2)
        elif k == 'overlord':                                 # shockwave charge ring
            if z.cd_total:
                frac = 1.0 - max(0.0, z.ability_t) / z.cd_total
                rr = int(size * 0.55)
                if frac > 0.03:
                    pygame.draw.arc(sc, (255, 90, 110), pygame.Rect(int(x) - rr, int(y) - rr, rr * 2, rr * 2), 0, 2 * math.pi * min(frac, 1.0), 4)
            for i in range(4):
                a = t * 1.3 + i * 1.57
                pygame.draw.circle(sc, (255, 150, 60), (int(x + math.cos(a) * size * 0.5), int(y + math.sin(a) * size * 0.5)), 3)
        elif k in ('boss', 'sboss'):                          # orbiting embers
            for i in range(3):
                a = t * 1.5 + i * 2.09
                pygame.draw.circle(sc, (255, 160, 60), (int(x + math.cos(a) * size * 0.46), int(y + math.sin(a) * size * 0.46)), 3)

    def draw_hpbar(self, z):
        x, y = z.pos
        y += z.off
        if z.hp < z.max or (z.shield_max and z.shield < z.shield_max):
            size = SIZE[z.kind]
            w = max(22, size * 0.55)
            by = y - size * 0.3 - 6
            pygame.draw.rect(self.screen, (90, 0, 0), (x - w / 2, by, w, 4))
            pygame.draw.rect(self.screen, (60, 230, 60), (x - w / 2, by, w * max(0, z.hp) / z.max, 4))
        if z.shield > 0:
            size = SIZE[z.kind]
            w = max(22, size * 0.55)
            by = y - size * 0.3 - 11
            pygame.draw.rect(self.screen, (30, 50, 100), (x - w / 2, by, w, 4))
            pygame.draw.rect(self.screen, (100, 170, 255), (x - w / 2, by, w * z.shield / z.shield_max, 4))

    def add_fx(self, **kw):
        self.fx.append(kw)
        if len(self.fx) > 350:
            del self.fx[:60]

    def spawn_fx(self, z):
        x, y = z.pos
        y += z.off
        size = SIZE[z.kind]
        for _ in range(14 if z.kind == 'boss' else 5):
            a = random.uniform(0, 2 * math.pi)
            sp = random.uniform(20, 60)
            self.add_fx(type='puff', pos=[x, y], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0, life=0.4,
                        col=(190, 175, 140), r0=3 + size / 30, r1=1, layer=0)
        self.add_fx(type='ring', pos=[x, y], t=0.0, life=0.45, r0=4, r1=int(size * 0.7), col=(255, 255, 255), layer=0)

    def death_fx(self, z):
        x, y = z.pos
        y += z.off
        size = SIZE[z.kind]
        phase = (z.dist / (size * 0.6)) % 1.0
        self.add_fx(type='corpse', kind=z.kind, frame=int(phase * FRAMES) % FRAMES, pos=[x, y], angle=z.angle,
                    t=0.0, life=0.5, layer=0)
        big = z.kind in ('boss', 'tank')
        for i in range(30 if z.kind == 'boss' else 16 if big else 9):
            a = random.uniform(0, 2 * math.pi)
            sp = random.uniform(50, 150) * (0.8 + size / 90)
            self.add_fx(type='puff', pos=[x, y], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0,
                        life=random.uniform(0.3, 0.65), col=z.col if i % 2 else (225, 225, 215),
                        r0=random.uniform(3, 6) * (0.7 + size / 80), r1=1, layer=1)
        self.add_fx(type='puff', pos=[x, y - 4], vel=(0, -25), t=0.0, life=0.6, col=(175, 175, 170),
                    r0=size * 0.2, r1=size * 0.55, layer=1)
        self.add_fx(type='text', pos=[x, y - size * 0.35], txt=f"+${z.reward}", t=0.0, life=0.9, col=(255, 224, 90), layer=1)
        if big:
            self.add_fx(type='ring', pos=[x, y], t=0.0, life=0.55, r0=6, r1=int(size * 1.1), col=(255, 220, 150), layer=0)

    def splash_fx(self, pos):
        for _ in range(7):
            a = random.uniform(0, 2 * math.pi)
            sp = random.uniform(30, 90)
            self.add_fx(type='puff', pos=[pos[0], pos[1]], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0,
                        life=0.5, col=(130, 235, 70), r0=5, r1=1, layer=1)

    def base_hit_fx(self, dmg):
        self.base_flash = 0.35
        bx, by = self.map.path[-1]
        for _ in range(8):
            a = random.uniform(0, 2 * math.pi)
            sp = random.uniform(40, 120)
            self.add_fx(type='puff', pos=[bx, by], vel=(math.cos(a) * sp, math.sin(a) * sp), t=0.0,
                        life=0.5, col=(255, 90, 70), r0=6, r1=1, layer=1)
        self.add_fx(type='text', pos=[bx, by - 44], txt=f"-{dmg}", t=0.0, life=1.0, col=(255, 90, 80), layer=1)

    def update_fx(self, dt):
        for f in self.fx[:]:
            f['t'] += dt
            if 'vel' in f:
                f['pos'][0] += f['vel'][0] * dt
                f['pos'][1] += f['vel'][1] * dt
                drag = max(0.0, 1 - 3 * dt)
                f['vel'] = (f['vel'][0] * drag, f['vel'][1] * drag)
            if f['t'] >= f['life']:
                self.fx.remove(f)

    def draw_fx(self, layer):
        sc = self.screen
        for f in self.fx:
            if f['layer'] != layer:
                continue
            fr = min(1.0, f['t'] / f['life'])
            x, y = f.get('pos', (0, 0))               # (tesla arcs carry their own points)
            ty = f['type']
            if ty == 'puff':
                self.blob_a(x, y, f['r0'] + (f['r1'] - f['r0']) * fr, f['col'], 210 * (1 - fr))
            elif ty == 'ring':
                R = max(4, int(f['r0'] + (f['r1'] - f['r0']) * fr))
                s = pygame.Surface((R * 2 + 4, R * 2 + 4), pygame.SRCALPHA)
                c = f['col']
                pygame.draw.circle(s, (c[0], c[1], c[2], int(200 * (1 - fr))), (R + 2, R + 2), R, 3)
                sc.blit(s, (int(x - R - 2), int(y - R - 2)))
            elif ty == 'corpse':
                spr = get_sprite(f['kind'], f['frame'], f['angle'] + 160 * fr, True, 1.02 + 0.4 * fr)
                spr.set_alpha(int(255 * (1 - fr)))
                sc.blit(spr, spr.get_rect(center=(x, y)))
            elif ty == 'blast':
                ext = f['rng'] * min(1.0, 0.25 + fr * 3)
                a0, h = f['angle'], f['half']
                pts = [(x, y)] + [(x + math.cos(a0 + h * (k / 6 * 2 - 1)) * ext, y + math.sin(a0 + h * (k / 6 * 2 - 1)) * ext)
                                  for k in range(7)]
                pygame.draw.polygon(sc, (255, 170, 60), pts, 2)
                for ra in f['rays']:
                    pygame.draw.line(sc, (255, 240, 160), (x + math.cos(a0 + ra) * ext * 0.45, y + math.sin(a0 + ra) * ext * 0.45),
                                     (x + math.cos(a0 + ra) * ext, y + math.sin(a0 + ra) * ext), 2)
                pygame.draw.circle(sc, (255, 210, 90), (int(x + math.cos(a0) * 26), int(y + math.sin(a0) * 26)), max(2, int(11 * (1 - fr))))
            elif ty == 'shell':
                sx_ = f['a'][0] + (f['b'][0] - f['a'][0]) * fr
                sy_ = f['a'][1] + (f['b'][1] - f['a'][1]) * fr
                lift = math.sin(math.pi * fr) * 70
                pygame.draw.ellipse(sc, (30, 40, 30), pygame.Rect(int(sx_ - 6), int(sy_ - 2), 12, 5))
                pygame.draw.circle(sc, OUT, (int(sx_), int(sy_ - lift)), 6)
                pygame.draw.circle(sc, (200, 160, 70), (int(sx_), int(sy_ - lift)), 4)
            elif ty == 'arc':
                rnd = random.Random(int(f['t'] * 100))
                for p0, p1 in zip(f['pts'], f['pts'][1:]):
                    pts = [(p0[0], p0[1])]
                    for k in range(1, 5):
                        tt = k / 5
                        pts.append((p0[0] + (p1[0] - p0[0]) * tt + rnd.uniform(-9, 9), p0[1] + (p1[1] - p0[1]) * tt + rnd.uniform(-9, 9)))
                    pts.append((p1[0], p1[1]))
                    pygame.draw.lines(sc, (150, 130, 255), False, pts, 4)
                    pygame.draw.lines(sc, (235, 240, 255), False, pts, 1)
            elif ty == 'text':
                img = self.f_m.render(f['txt'], True, f['col'])
                img.set_alpha(int(255 * (1 - fr * fr)))
                sc.blit(img, img.get_rect(center=(x, y - 34 * fr)))

    def draw_boost_icon(self, key, cx, cy, s):
        sc = self.screen
        if key == 'spit':                                   # slime splat
            pygame.draw.circle(sc, OUT, (cx, cy), s // 2 + 2)
            pygame.draw.circle(sc, (130, 235, 70), (cx, cy), s // 2)
            pygame.draw.circle(sc, (190, 255, 130), (cx - s // 6, cy - s // 6), s // 6)
            for dx in (-s // 3, 0, s // 3):
                pygame.draw.circle(sc, (130, 235, 70), (cx + dx, cy + s // 2 + 2), 3)
        elif key == 'boots':                                # winged boot
            boot = [(cx - 10, cy - 12), (cx + 2, cy - 12), (cx + 2, cy + 2), (cx + 16, cy + 6), (cx + 16, cy + 14), (cx - 10, cy + 14)]
            pygame.draw.polygon(sc, OUT, boot)
            pygame.draw.polygon(sc, (210, 140, 70), [(cx - 8, cy - 10), (cx, cy - 10), (cx, cy + 4), (cx + 14, cy + 8), (cx + 14, cy + 12), (cx - 8, cy + 12)])
            for k in range(3):
                pygame.draw.polygon(sc, (245, 250, 255), [(cx - 10, cy - 4 - k * 6), (cx - 24 + k * 3, cy - 14 - k * 6), (cx - 12, cy - 9 - k * 6)])
        elif key == 'big':                                  # a big zombie
            self.blit_zombie('zombie', cx, cy, 0, (self.t * 1.4) % 1.0, max_px=s * 2)
        else:                                               # drunk: bottle + swirl
            pygame.draw.polygon(sc, OUT, [(cx - 6, cy - 16), (cx + 6, cy - 16), (cx + 6, cy - 6), (cx + 14, cy + 4), (cx + 14, cy + 16), (cx - 14, cy + 16), (cx - 14, cy + 4), (cx - 6, cy - 6)])
            pygame.draw.polygon(sc, (90, 190, 110), [(cx - 4, cy - 14), (cx + 4, cy - 14), (cx + 4, cy - 4), (cx + 12, cy + 6), (cx + 12, cy + 14), (cx - 12, cy + 14), (cx - 12, cy + 6), (cx - 4, cy - 4)])
            pygame.draw.rect(sc, (170, 120, 70), (cx - 4, cy - 20, 8, 6))
            for k in range(3):
                a = self.t * 3 + k * 2.1
                pygame.draw.circle(sc, (230, 200, 255), (int(cx + math.cos(a) * 20), int(cy - 14 + math.sin(a) * 6)), 2)

    def draw_boosts(self):
        sc = self.screen
        sc.fill((26, 22, 38))
        self.text("BOOST SHOP", self.f_l, (210, 170, 255), (W // 2, 50), True)
        self.text(f"Coins: {self.coins}", self.f_m, (250, 210, 60), (W // 2, 100), True)
        mp = mouse_pos()
        for key, r in zip(BOOST_KEYS, self.boost_rows()):
            bdef = BOOSTS[key]
            pygame.draw.rect(sc, (40, 34, 58), r, border_radius=12)
            pygame.draw.rect(sc, bdef['col'], r, 3, border_radius=12)
            self.draw_boost_icon(key, r.x + 46, r.centery, 50)
            self.text(bdef['name'], self.f_l, (255, 255, 255), (r.x + 100, r.y + 6))
            for i, line in enumerate(bdef['desc']):
                self.text(line, self.f_s, (210, 200, 230), (r.x + 100, r.y + 56 + i * 20))
            self.text(f"Owned: {self.boosts.get(key, 0)}", self.f_m, (250, 210, 60), (r.right - 230, r.y + 4))
            b = self.boost_buy_rect(r)
            ok = self.coins >= bdef['price']
            bcol = ((80, 150, 80) if b.collidepoint(mp) else (55, 115, 60)) if ok else (90, 50, 50)
            pygame.draw.rect(sc, bcol, b, border_radius=8)
            pygame.draw.rect(sc, (255, 255, 255), b, 2, border_radius=8)
            self.text(f"BUY 1  -  {bdef['price']}", self.f_m, (255, 255, 255), b.center, True)
        self.text("GAME SPEED", self.f_m, (255, 190, 110), (W // 2, 650), True)
        for n, r in zip(sorted(SPEED_SHOP), self.speed_rows()):
            own = n in self.speeds
            pygame.draw.rect(sc, (50, 40, 30), r, border_radius=12)
            pygame.draw.rect(sc, (255, 170, 80) if own else (160, 110, 60), r, 3, border_radius=12)
            for k in range(n):                                                 # n play-arrows
                ax = r.x + 24 + k * 24
                pygame.draw.polygon(sc, (255, 190, 90) if own else (150, 120, 80), [(ax, r.centery - 14), (ax + 20, r.centery), (ax, r.centery + 14)])
            self.text(f"{n}x Game Speed", self.f_m, (255, 255, 255), (r.x + 120, r.y + 8))
            self.text("Run the match 2x as fast" if n == 2 else "Run the match 3x as fast", self.f_s, (230, 210, 190), (r.x + 120, r.y + 36))
            b = self.speed_buy_rect(r)
            if own:
                bcol, label = (60, 70, 62), "UNLOCKED"
            else:
                ok = self.coins >= SPEED_SHOP[n]
                bcol = ((80, 150, 80) if b.collidepoint(mp) else (55, 115, 60)) if ok else (90, 50, 50)
                label = f"BUY  {SPEED_SHOP[n]}"
            pygame.draw.rect(sc, bcol, b, border_radius=8)
            pygame.draw.rect(sc, (255, 255, 255), b, 2, border_radius=8)
            self.text(label, self.f_m, (255, 255, 255), b.center, True)
        back = pygame.Rect(350, 840, 300, 70)
        pygame.draw.rect(sc, (70, 150, 70) if back.collidepoint(mp) else (45, 110, 50), back, border_radius=12)
        pygame.draw.rect(sc, (160, 230, 150), back, 3, border_radius=12)
        self.text("BACK", self.f_m, (255, 255, 255), back.center, True)

    def tech_rects(self):
        out = {}
        for bi, br in enumerate(TECH_BRANCHES):
            keys = [k for k, d in TECHS.items() if d['branch'] == br]
            for ki, k in enumerate(keys):
                out[k] = pygame.Rect(312 + ki * 160, 212 + bi * 118, 150, 104)
        return out

    def draw_heat(self):
        """Planning aid: colours the road by how much tower damage-per-second covers each spot."""
        veil = pygame.Surface((W, H), pygame.SRCALPHA)
        for a, b, L, _s in self.pmap.seg:
            n = max(1, int(L // 14))
            for i in range(n + 1):
                x, y = a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n
                r = min(1.0, self.threat_at(x, y) / HEAT_MAX)
                col = (int(255 * min(1, r * 2)), int(255 * min(1, (1 - r) * 2)), 50)
                pygame.draw.circle(veil, (col[0], col[1], col[2], 150), (int(x), int(y)), 15)
        self.screen.blit(veil, (0, 0))

    def path_threat(self):
        tot, n, peak = 0.0, 0, 0.0
        for a, b, L, _s in self.pmap.seg:
            k = max(1, int(L // 40))
            for i in range(k + 1):
                d = self.threat_at(a[0] + (b[0] - a[0]) * i / k, a[1] + (b[1] - a[1]) * i / k)
                tot += d
                n += 1
                peak = max(peak, d)
        return (tot / max(1, n), peak)

    def draw_overlays(self, mp):
        sc = self.screen
        # --- planning card + START button
        if self.phase == 'plan':
            avg, peak = self.path_threat()
            card = pygame.Rect(260, 628, 480, 136)
            pygame.draw.rect(sc, (16, 22, 30), card, border_radius=12)
            pygame.draw.rect(sc, (120, 200, 255), card, 3, border_radius=12)
            self.text(f"PLANNING  -  WAVE {self.wave}/{self.total_waves}", self.f_m, (255, 230, 120), (card.centerx, card.y + 20), True)
            lvl = "LOW" if avg < 60 else "MEDIUM" if avg < 130 else "HIGH" if avg < 220 else "EXTREME"
            self.text(f"Road threat: {lvl}   (avg {avg:.0f} / peak {peak:.0f} dmg per sec)", self.f_s, (255, 255, 255), (card.centerx, card.y + 48), True)
            md = MODIFIERS.get(self.mod_id)
            if md:
                self.text(f"MODIFIER: {md['name']} - {md['desc']}", self.f_s, md['col'], (card.centerx, card.y + 72), True)
            else:
                self.text("No modifier this wave", self.f_s, (150, 165, 150), (card.centerx, card.y + 72), True)
            self.text("hover towers for intel  |  [T] research  |  [G] formation  |  [H] heat", self.f_xs, (170, 190, 205), (card.centerx, card.y + 100), True)
            self.text("units, boosts and abilities unlock when the wave starts", self.f_xs, (170, 190, 205), (card.centerx, card.y + 118), True)
            sb = self.start_btn
            pygame.draw.rect(sc, (70, 170, 80) if sb.collidepoint(mp) else (46, 130, 58), sb, border_radius=10)
            pygame.draw.rect(sc, (190, 255, 190), sb, 3, border_radius=10)
            self.text("START WAVE  [SPACE]", self.f_m, (255, 255, 255), sb.center, True)
        # --- Zombie-Alike tower picking
        if self.alike_mode:
            veil = pygame.Surface((W, H), pygame.SRCALPHA)           # the world is frozen: tint it
            veil.fill((70, 40, 110, 55))
            sc.blit(veil, (0, 0))
            self.text("TIME STOPPED", self.f_l, (230, 190, 255), (W // 2, 150), True, shadow=True)
            src = self.alike_src
            pulse = 26 + 3 * math.sin(self.t * 8)
            if self.alike_mode == 'source':
                msg = "ZOMBIE-ALIKE: click the TOWER you want to hijack   (right-click to cancel)"
                for t in self.towers:
                    ok = t.stun <= 0 and t.kind != 'cmd'
                    pygame.draw.circle(sc, (230, 120, 255) if ok else (120, 90, 130), (int(t.pos[0]), int(t.pos[1])), int(pulse), 3)
            else:
                need = self.alike_targets_needed()
                msg = (f"Hijacking {TOWER_NAMES[src.kind]}: click {need - len(self.alike_picks)} tower(s) in its range to shoot "
                       f"{'(click it again / ENTER to fire)' if need == 2 and self.alike_picks else ''}")
                rr = int(src.stats[2] * self.m['trng'])
                pygame.draw.circle(sc, (230, 120, 255), (int(src.pos[0]), int(src.pos[1])), rr, 2)
                pygame.draw.circle(sc, (255, 200, 255), (int(src.pos[0]), int(src.pos[1])), int(pulse), 4)
                for t in self.towers:
                    if t is src:
                        continue
                    if t in self.alike_picks:
                        pygame.draw.circle(sc, (255, 80, 80), (int(t.pos[0]), int(t.pos[1])), int(pulse), 4)
                        pygame.draw.line(sc, (255, 80, 80), (t.pos[0] - 14, t.pos[1]), (t.pos[0] + 14, t.pos[1]), 3)
                        pygame.draw.line(sc, (255, 80, 80), (t.pos[0], t.pos[1] - 14), (t.pos[0], t.pos[1] + 14), 3)
                    elif math.dist(src.pos, t.pos) <= rr:
                        pygame.draw.circle(sc, (120, 255, 140), (int(t.pos[0]), int(t.pos[1])), int(pulse), 3)
            self.text(msg, self.f_m, (255, 190, 255), (W // 2, 200), True, shadow=True)
        # --- hijacked towers glow
        for t in self.towers:
            if t.hijack_t > 0:
                self.ring_a(t.pos[0], t.pos[1], 30 + 3 * math.sin(self.t * 10), (230, 120, 255), 200, 4)
        # --- Confuser control panel
        if self.confusers() or self.alike_mode or self.illusion_t > 0:
            pr = pygame.Rect(690, 62, 300, 106)
            pygame.draw.rect(sc, (30, 18, 44), pr, border_radius=10)
            pygame.draw.rect(sc, (220, 130, 255), pr, 2, border_radius=10)
            self.text("CONFUSER ABILITIES", self.f_s, (240, 200, 255), (pr.centerx, pr.y + 14), True)
            pb, ab = self.conf_path_btn, self.conf_alike_btn
            ready_p = self.path_ready() > 0 and self.illusion_t <= 0 and self.phase == 'run'
            pygame.draw.rect(sc, (110, 60, 160) if ready_p else (50, 44, 60), pb, border_radius=8)
            pygame.draw.rect(sc, (230, 170, 255) if ready_p else (90, 80, 100), pb, 2, border_radius=8)
            self.text("ILLUSION PATH [P]", self.f_xs, (255, 255, 255), (pb.centerx, pb.y + 16), True)
            st_ = f"ACTIVE {self.illusion_t:.1f}s" if self.illusion_t > 0 else (f"{self.path_ready()} ready (1 use each)" if self.path_ready() else "used up")
            self.text(st_, self.f_xs, (255, 220, 255) if ready_p else (150, 140, 160), (pb.centerx, pb.y + 38), True)
            self.text("straight road", self.f_xs, (190, 170, 210), (pb.centerx, pb.y + 56), True)
            rdy = self.alike_ready()
            ready_a = bool(rdy) and self.phase == 'run'
            pygame.draw.rect(sc, (150, 50, 120) if (ready_a or self.alike_mode) else (50, 44, 60), ab, border_radius=8)
            pygame.draw.rect(sc, (255, 150, 230) if (ready_a or self.alike_mode) else (90, 80, 100), ab, 2, border_radius=8)
            self.text("ZOMBIE-ALIKE [Z]", self.f_xs, (255, 255, 255), (ab.centerx, ab.y + 16), True)
            cons = self.confusers()
            if self.alike_mode:
                st_ = "picking... (cancel)"
            elif rdy:
                st_ = f"READY x{len(rdy)}"
            elif cons:
                st_ = f"cooldown {min(c.alike_cd for c in cons):.0f}s"
            else:
                st_ = "no Confuser"
            self.text(st_, self.f_xs, (255, 220, 255) if (ready_a or self.alike_mode) else (150, 140, 160), (ab.centerx, ab.y + 38), True)
            lv = max((c.clevel for c in cons), default=0)
            self.text("2 targets" if lv >= ALIKE_LVL2 else f"1 target (2 at Lv {ALIKE_LVL2})", self.f_xs, (190, 170, 210), (ab.centerx, ab.y + 56), True)
        # --- research panel
        if self.research_open:
            pr = pygame.Rect(190, 140, 630, 570)
            pygame.draw.rect(sc, (16, 24, 34), pr, border_radius=14)
            pygame.draw.rect(sc, (140, 220, 255), pr, 3, border_radius=14)
            self.text("RESEARCH", self.f_l, (150, 230, 255), (pr.centerx, pr.y + 34), True)
            self.text("Spend match $ on upgrades. Tier 2 is an EITHER/OR choice - think about what the towers are doing!", self.f_xs, (190, 205, 220), (pr.centerx, pr.y + 66), True)
            self.text(f"${self.money}", self.f_m, (110, 230, 110), (pr.right - 60, pr.y + 34), True)
            for bi, br in enumerate(TECH_BRANCHES):
                self.text(br, self.f_s, (255, 220, 150), (pr.x + 70, 262 + bi * 118), True)
            rects = self.tech_rects()
            for key, r in rects.items():
                d = TECHS[key]
                stt = self.tech_state(key)
                fill = {'owned': (46, 120, 66), 'locked': (36, 40, 46), 'excluded': (70, 36, 36), 'afford': (40, 70, 100), 'poor': (44, 50, 62)}[stt]
                edge = {'owned': (150, 255, 170), 'locked': (80, 86, 94), 'excluded': (150, 70, 70), 'afford': (150, 220, 255), 'poor': (100, 110, 130)}[stt]
                if stt == 'afford' and r.collidepoint(mp):
                    fill = (60, 100, 140)
                pygame.draw.rect(sc, fill, r, border_radius=8)
                pygame.draw.rect(sc, edge, r, 2, border_radius=8)
                self.text(d['name'], self.f_s, (255, 255, 255), (r.centerx, r.y + 16), True)
                for i, ln in enumerate(d['desc']):
                    self.text(ln, self.f_xs, (210, 225, 240), (r.centerx, r.y + 42 + i * 16), True)
                lab = {'owned': 'RESEARCHED', 'locked': f"needs {TECHS[d['req']]['name']}" if d.get('req') else '', 'excluded': 'ruled out',
                       'afford': f"${d['cost']}", 'poor': f"${d['cost']}"}[stt]
                self.text(lab, self.f_xs, (250, 230, 120) if stt in ('afford', 'poor') else (190, 200, 210), (r.centerx, r.y + 86), True)
        # --- hover intel for towers
        hov = None
        for t in self.towers:
            if math.dist(mp, t.pos) <= 24:
                hov = t
        if hov is not None and not self.alike_mode:
            st = hov.stats
            lines = [f"{TOWER_NAMES[hov.kind]}  LVL {hov.lvl}"]
            if hov.kind != 'cmd':
                lines += [f"Damage {st[0] * TOWER_DMG_MULT * self.m['tdmg']:.1f} per shot   Cooldown {st[1] * self.m['tcd']:.2f}s",
                          f"Range {st[2] * self.m['trng']:.0f}px"]
            lines.append(TARGET_INFO[hov.kind])
            if hov.stun > 0:
                lines.append(f"STUNNED {hov.stun:.1f}s")
            wd = max(len(l) for l in lines) * 7 + 24
            card = pygame.Rect(int(min(max(10, mp[0] + 18), W - wd - 10)), int(min(max(70, mp[1] - 80), 760)), wd, 22 * len(lines) + 12)
            pygame.draw.rect(sc, (14, 18, 24), card, border_radius=8)
            pygame.draw.rect(sc, (255, 220, 120), card, 2, border_radius=8)
            for i, l in enumerate(lines):
                self.text(l, self.f_s if i == 0 else self.f_xs, (255, 230, 150) if i == 0 else (225, 235, 245), (card.x + 12, card.y + 8 + i * 22))

    def draw_toasts(self):
        for i, tst in enumerate(self.toasts):
            txt = tst[0]
            aid = tst[2] if len(tst) > 2 else None
            img = self.f_m.render(txt, True, (255, 255, 255))
            pad = 52 if aid else 0
            r = pygame.Rect(0, 0, img.get_width() + 40 + pad, 52 if aid else 40)
            r.center = (W // 2, 44 + i * 60)
            pygame.draw.rect(self.screen, (60, 50, 10), r, border_radius=10)
            pygame.draw.rect(self.screen, (250, 210, 60), r, 3, border_radius=10)
            if aid:
                self.draw_ach_icon(aid, r.x + 34, r.centery, 44, True)
            self.screen.blit(img, img.get_rect(center=(r.centerx + pad // 2, r.centery)))

    def draw_ach_icon(self, aid, cx, cy, size, done):
        """Medal with a little picture for each achievement (colour when earned, dim + padlock when locked)."""
        sc = self.screen
        k = size / 64.0

        def P(x, y):
            return (int(cx + x * k), int(cy + y * k))

        def poly(pts, col, ow=2):
            pygame.draw.polygon(sc, col, [P(x, y) for x, y in pts])
            pygame.draw.polygon(sc, OUT, [P(x, y) for x, y in pts], max(1, int(ow * k)))

        pal = {'easy': ((236, 196, 60), (44, 60, 112)), 'medium': ((190, 150, 250), (66, 40, 104)),
               'hard': ((236, 90, 90), (96, 30, 34)), 'general': ((90, 210, 196), (20, 70, 72))}[ACH[aid].get('mode', 'easy')]
        gold = pal[0] if done else (100, 106, 114)
        pygame.draw.circle(sc, OUT, (cx, cy), int(35 * k))                    # medal
        pygame.draw.circle(sc, gold, (cx, cy), int(32 * k))
        pygame.draw.circle(sc, _col(gold, 0.72), (cx, cy), int(27 * k))
        pygame.draw.circle(sc, pal[1] if done else (42, 46, 54), (cx, cy), int(25 * k))
        if done:
            pygame.draw.circle(sc, (74, 96, 160), (int(cx - 8 * k), int(cy - 9 * k)), max(1, int(9 * k)))
        col = (lambda c: c) if done else (lambda c: _col((c[0] * 0.45 + 40, c[1] * 0.45 + 42, c[2] * 0.45 + 46)))
        if aid == 'beat_easy':                                                 # trophy
            gcol = col((255, 214, 70))
            for sd in (-1, 1):
                pygame.draw.circle(sc, OUT, P(sd * 17, -9), max(2, int(8 * k)), max(1, int(4 * k)))
                pygame.draw.circle(sc, gcol, P(sd * 17, -9), max(2, int(7 * k)), max(1, int(2 * k)))
            poly([(-14, -18), (14, -18), (12, -1), (6, 8), (-6, 8), (-12, -1)], gcol)
            poly([(-3, 8), (3, 8), (3, 15), (-3, 15)], col((230, 180, 50)))
            poly([(-11, 15), (11, 15), (11, 21), (-11, 21)], col((200, 150, 40)))
            pygame.draw.line(sc, col((255, 250, 200)), P(-7, -14), P(-8, -3), max(1, int(3 * k)))
        elif aid == 'buy_custom':                                              # a custom zombie + coin
            self.blit_zombie('bolt', cx - int(2 * k), cy, 0, (self.t * 1.2) % 1.0, alpha=255 if done else 90, max_px=int(size * 0.95))
            pygame.draw.circle(sc, OUT, P(18, 16), max(2, int(10 * k)))
            pygame.draw.circle(sc, col((236, 196, 60)), P(18, 16), max(2, int(8 * k)))
            pygame.draw.circle(sc, col((255, 232, 140)), P(16, 14), max(1, int(3 * k)))
        elif aid == 'map_win':                                                 # map + flag
            pygame.draw.rect(sc, OUT, (*P(-17, -14), int(34 * k), int(28 * k)), border_radius=4)
            pygame.draw.rect(sc, col((70, 140, 80)), (*P(-15, -12), int(30 * k), int(24 * k)), border_radius=3)
            pts = [P(-12, -4), P(2, -4), P(2, 8), P(-6, 8)]
            pygame.draw.lines(sc, col((140, 108, 70)), False, pts, max(2, int(5 * k)))
            pygame.draw.line(sc, OUT, P(8, 9), P(8, -12), max(2, int(3 * k)))
            poly([(8, -12), (18, -8), (8, -4)], col((226, 60, 60)), 1)
        elif aid == 'no_boss':                                                 # boss with a 'no' sign
            self.blit_zombie('boss', cx, cy, 0, (self.t * 1.0) % 1.0, alpha=255 if done else 90, max_px=int(size * 0.8))
            ring = col((235, 60, 60))
            pygame.draw.circle(sc, OUT, (cx, cy), int(21 * k), max(2, int(7 * k)))
            pygame.draw.circle(sc, ring, (cx, cy), int(21 * k), max(2, int(4 * k)))
            pygame.draw.line(sc, OUT, P(-15, -15), P(15, 15), max(2, int(7 * k)))
            pygame.draw.line(sc, ring, P(-15, -15), P(15, 15), max(2, int(4 * k)))
        elif aid == 'med_win':                                                 # silver trophy with a star
            scol = col((214, 222, 240))
            for sd in (-1, 1):
                pygame.draw.circle(sc, OUT, P(sd * 17, -9), max(2, int(8 * k)), max(1, int(4 * k)))
                pygame.draw.circle(sc, scol, P(sd * 17, -9), max(2, int(7 * k)), max(1, int(2 * k)))
            poly([(-14, -18), (14, -18), (12, -1), (6, 8), (-6, 8), (-12, -1)], scol)
            poly([(-3, 8), (3, 8), (3, 15), (-3, 15)], col((176, 184, 204)))
            poly([(-11, 15), (11, 15), (11, 21), (-11, 21)], col((140, 148, 170)))
            star = [(math.cos(-math.pi / 2 + i * math.pi / 5) * (8 if i % 2 == 0 else 3.4),
                     -6 + math.sin(-math.pi / 2 + i * math.pi / 5) * (8 if i % 2 == 0 else 3.4)) for i in range(10)]
            poly(star, col((255, 214, 70)), 1)
        elif aid in ('med_no_boss', 'hard_no_boss'):                           # boss with a 'no' sign
            self.blit_zombie('sboss' if aid == 'med_no_boss' else 'overlord', cx, cy, 0, (self.t * 1.0) % 1.0, alpha=255 if done else 90, max_px=int(size * 0.8))
            ring = col((235, 60, 60))
            pygame.draw.circle(sc, OUT, (cx, cy), int(21 * k), max(2, int(7 * k)))
            pygame.draw.circle(sc, ring, (cx, cy), int(21 * k), max(2, int(4 * k)))
            pygame.draw.line(sc, OUT, P(-15, -15), P(15, 15), max(2, int(7 * k)))
            pygame.draw.line(sc, ring, P(-15, -15), P(15, 15), max(2, int(4 * k)))
        elif aid == 'med_map':                                                 # sandy map, straight road + flag
            pygame.draw.rect(sc, OUT, (*P(-17, -14), int(34 * k), int(28 * k)), border_radius=4)
            pygame.draw.rect(sc, col((218, 188, 124)), (*P(-15, -12), int(30 * k), int(24 * k)), border_radius=3)
            pygame.draw.line(sc, OUT, P(-14, 2), P(14, 2), max(2, int(8 * k)))
            pygame.draw.line(sc, col((84, 86, 94)), P(-14, 2), P(14, 2), max(2, int(5 * k)))
            for dx_ in (-9, -1, 7):
                pygame.draw.line(sc, col((244, 204, 60)), P(dx_, 2), P(dx_ + 4, 2), max(1, int(2 * k)))
            pygame.draw.line(sc, OUT, P(8, 0), P(8, -14), max(2, int(3 * k)))
            poly([(8, -14), (18, -10), (8, -6)], col((226, 60, 60)), 1)
        elif aid == 'med_special':                                             # four special-zombie badges
            for (bx_, by_, kd) in ((-12, -12, 'medic'), (12, -12, 'bomber'), (-12, 12, 'leaper'), (12, 12, 'riot')):
                bx0, by0 = P(bx_, by_)
                rr = max(3, int(10 * k))
                pygame.draw.circle(sc, OUT, (bx0, by0), rr + 2)
                if kd == 'medic':
                    pygame.draw.circle(sc, col((240, 244, 250)), (bx0, by0), rr)
                    pygame.draw.rect(sc, col((214, 44, 52)), (bx0 - int(6 * k), by0 - int(2 * k), int(12 * k), max(2, int(4 * k))))
                    pygame.draw.rect(sc, col((214, 44, 52)), (bx0 - int(2 * k), by0 - int(6 * k), max(2, int(4 * k)), int(12 * k)))
                elif kd == 'bomber':
                    pygame.draw.circle(sc, col((70, 70, 78)), (bx0, by0), rr)
                    pygame.draw.line(sc, OUT, (bx0 + int(4 * k), by0 - int(6 * k)), (bx0 + int(9 * k), by0 - int(11 * k)), max(1, int(2 * k)))
                    pygame.draw.circle(sc, col((255, 190, 60)), (bx0 + int(9 * k), by0 - int(11 * k)), max(2, int(3 * k)))
                elif kd == 'leaper':
                    pygame.draw.circle(sc, col((80, 210, 180)), (bx0, by0), rr)
                    pygame.draw.lines(sc, col((255, 226, 90)), False, [(bx0 - int(5 * k), by0 + int(3 * k)), (bx0, by0 - int(4 * k)), (bx0 + int(5 * k), by0 + int(3 * k))], max(2, int(3 * k)))
                else:
                    pygame.draw.circle(sc, col((80, 130, 220)), (bx0, by0), rr)
                    pygame.draw.rect(sc, col((200, 226, 255)), (bx0 - int(3 * k), by0 - int(6 * k), max(2, int(6 * k)), int(12 * k)), border_radius=2)
        elif aid == 'med_boosts':                                              # four boost orbs
            for (bx_, by_, kd) in ((-12, -12, 'spit'), (12, -12, 'boots'), (-12, 12, 'big'), (12, 12, 'drunk')):
                bx0, by0 = P(bx_, by_)
                rr = max(3, int(10 * k))
                pygame.draw.circle(sc, OUT, (bx0, by0), rr + 2)
                pygame.draw.circle(sc, col(BOOSTS[kd]['col']), (bx0, by0), rr)
                pygame.draw.circle(sc, col(_col(BOOSTS[kd]['col'], 1.35)), (bx0 - int(3 * k), by0 - int(3 * k)), max(1, int(3 * k)))
                if kd == 'boots':
                    pygame.draw.line(sc, OUT, (bx0 - int(5 * k), by0 + int(2 * k)), (bx0 + int(5 * k), by0 + int(2 * k)), max(1, int(2 * k)))
                elif kd == 'big':
                    pygame.draw.polygon(sc, OUT, [(bx0 - int(4 * k), by0 + int(3 * k)), (bx0, by0 - int(4 * k)), (bx0 + int(4 * k), by0 + int(3 * k))])
                elif kd == 'drunk':
                    pygame.draw.circle(sc, OUT, (bx0 + int(2 * k), by0 + int(2 * k)), max(1, int(2 * k)))
        elif aid == 'hard_win':                                                # red trophy with a skull
            rcol = col((236, 96, 96))
            for sd in (-1, 1):
                pygame.draw.circle(sc, OUT, P(sd * 17, -9), max(2, int(8 * k)), max(1, int(4 * k)))
                pygame.draw.circle(sc, rcol, P(sd * 17, -9), max(2, int(7 * k)), max(1, int(2 * k)))
            poly([(-14, -18), (14, -18), (12, -1), (6, 8), (-6, 8), (-12, -1)], rcol)
            poly([(-3, 8), (3, 8), (3, 15), (-3, 15)], col((170, 60, 60)))
            poly([(-11, 15), (11, 15), (11, 21), (-11, 21)], col((130, 44, 44)))
            pygame.draw.circle(sc, col((244, 240, 226)), P(0, -8), max(2, int(6 * k)))
            for dx_ in (-2.5, 2.5):
                pygame.draw.circle(sc, OUT, P(dx_, -9), max(1, int(1.6 * k)))
        elif aid == 'hard_map':                                                # icy map with a spiral road + flag
            pygame.draw.rect(sc, OUT, (*P(-17, -14), int(34 * k), int(28 * k)), border_radius=4)
            pygame.draw.rect(sc, col((198, 226, 246)), (*P(-15, -12), int(30 * k), int(24 * k)), border_radius=3)
            route = [P(-12, -8), P(12, -8), P(12, 8), P(-8, 8), P(-8, 0), P(4, 0)]
            pygame.draw.lines(sc, OUT, False, route, max(2, int(5 * k)))
            pygame.draw.lines(sc, col((120, 160, 200)), False, route, max(1, int(3 * k)))
            pygame.draw.line(sc, OUT, P(4, 0), P(4, -10), max(2, int(3 * k)))
            poly([(4, -10), (14, -6), (4, -2)], col((226, 60, 60)), 1)
        elif aid == 'hard_elite':                                              # three elite badges
            for (bx_, by_, kd) in ((0, -12, 'splitter'), (-13, 10, 'screamer'), (13, 10, 'juggernaut')):
                bx0, by0 = P(bx_, by_)
                rr = max(3, int(10 * k))
                pygame.draw.circle(sc, OUT, (bx0, by0), rr + 2)
                if kd == 'splitter':
                    pygame.draw.circle(sc, col((184, 124, 220)), (bx0, by0), rr)
                    pygame.draw.lines(sc, col((255, 230, 255)), False, [(bx0 - rr + 2, by0), (bx0 - rr // 2, by0 - 3), (bx0, by0 + 3), (bx0 + rr // 2, by0 - 3), (bx0 + rr - 2, by0)], max(1, int(2 * k)))
                elif kd == 'screamer':
                    pygame.draw.circle(sc, col((238, 160, 160)), (bx0, by0), rr)
                    pygame.draw.ellipse(sc, col((60, 12, 20)), (bx0 - int(4 * k), by0 - int(5 * k), int(8 * k), int(10 * k)))
                else:
                    pygame.draw.circle(sc, col((120, 126, 140)), (bx0, by0), rr)
                    pygame.draw.circle(sc, col((255, 140, 50)), (bx0, by0), max(2, int(4 * k)))
        elif aid == 'collector':                                               # all five custom zombies
            for i_, kd in enumerate(CUSTOM_KEYS):
                a_ = -math.pi / 2 + i_ * 2 * math.pi / len(CUSTOM_KEYS)
                bx0, by0 = P(math.cos(a_) * 15, math.sin(a_) * 15)
                rr = max(3, int(8 * k))
                pygame.draw.circle(sc, OUT, (bx0, by0), rr + 2)
                pygame.draw.circle(sc, col(UNITS[kd]['col']), (bx0, by0), rr)
                pygame.draw.circle(sc, col(_col(UNITS[kd]['col'], 1.4)), (bx0 - 2, by0 - 2), max(1, int(2.5 * k)))
        elif aid == 'cartographer':                                            # world map with pins + a compass
            pygame.draw.rect(sc, OUT, (*P(-18, -15), int(36 * k), int(30 * k)), border_radius=4)
            pygame.draw.rect(sc, col((226, 200, 140)), (*P(-16, -13), int(32 * k), int(26 * k)), border_radius=3)
            for dx_, dy_ in ((-10, -5), (4, -8), (8, 6), (-6, 7)):
                pygame.draw.circle(sc, OUT, P(dx_, dy_), max(2, int(4.5 * k)))
                pygame.draw.circle(sc, col((226, 56, 56)), P(dx_, dy_), max(1, int(3 * k)))
            pygame.draw.lines(sc, col((120, 84, 44)), False, [P(-10, -5), P(4, -8), P(8, 6), P(-6, 7)], max(1, int(1.5 * k)))
        else:                                                                  # stopwatch + lightning
            pygame.draw.rect(sc, OUT, (*P(-4, -22), int(8 * k), int(6 * k)))
            pygame.draw.circle(sc, OUT, P(0, 1), int(19 * k))
            pygame.draw.circle(sc, col((236, 240, 248) if aid == 'fast_win' else (255, 206, 206)), P(0, 1), int(16 * k))
            for a_ in range(4):
                an = a_ * math.pi / 2
                pygame.draw.line(sc, OUT, P(math.cos(an) * 12, 1 + math.sin(an) * 12), P(math.cos(an) * 15, 1 + math.sin(an) * 15), max(1, int(2 * k)))
            pygame.draw.line(sc, OUT, P(0, 1), P(0, -9), max(1, int(3 * k)))
            pygame.draw.line(sc, OUT, P(0, 1), P(7, 5), max(1, int(3 * k)))
            poly([(12, -2), (4, 11), (9, 11), (6, 24), (19, 7), (13, 7), (17, -2)], col((255, 226, 60)), 1)
        if done:                                                               # twinkle
            tw = 3 + 2 * math.sin(self.t * 5 + (hash(aid) % 7))
            sx, sy = P(24, -24)
            pygame.draw.line(sc, (255, 255, 220), (sx - tw * k * 1.6, sy), (sx + tw * k * 1.6, sy), 2)
            pygame.draw.line(sc, (255, 255, 220), (sx, sy - tw * k * 1.6), (sx, sy + tw * k * 1.6), 2)
        else:                                                                  # padlock
            lx, ly = P(15, 15)
            pygame.draw.circle(sc, OUT, (lx, ly - int(5 * k)), max(2, int(6 * k)), max(1, int(3 * k)))
            pygame.draw.rect(sc, OUT, (lx - int(8 * k), ly - int(3 * k), int(16 * k), int(12 * k)), border_radius=3)
            pygame.draw.rect(sc, (170, 176, 186), (lx - int(6 * k), ly - int(1 * k), int(12 * k), int(8 * k)), border_radius=2)

    @staticmethod
    def ach_tabs():
        return [pygame.Rect(20, 28, 110, 40), pygame.Rect(140, 28, 130, 40), pygame.Rect(280, 28, 110, 40), pygame.Rect(400, 28, 130, 40)]

    def ach_visible(self, mode):
        return [a for a in ACHIEVEMENTS if a['mode'] == mode and
                (not a.get('secret') or a.get('reveal') in self.achieved or a['id'] in self.achieved)]

    def draw_ach(self):
        sc = self.screen
        sc.fill((25, 40, 28))
        self.text("ACHIEVEMENTS", self.f_l, (120, 210, 90), (W // 2 + 200, 50), True)
        mp = mouse_pos()
        for i, (tr, name, mode) in enumerate(zip(self.ach_tabs(), ("EASY", "MEDIUM", "HARD", "GENERAL"), ("easy", "medium", "hard", "general"))):
            v = self.ach_visible(mode)
            got = sum(1 for a in v if a['id'] in self.achieved)
            active = i == self.ach_page
            pygame.draw.rect(sc, (60, 100, 60) if active else (35, 55, 38), tr, border_radius=8)
            pygame.draw.rect(sc, (160, 230, 150) if active else (90, 105, 92), tr, 2, border_radius=8)
            self.text(f"{name} {got}/{len(v)}", self.f_s, (255, 255, 255), tr.center, True)
        vis = self.ach_visible(("easy", "medium", "hard", "general")[self.ach_page])
        self.text(f"Coins: {self.coins}", self.f_m, (250, 210, 60), (W // 2 + 200, 100), True)
        for i, a in enumerate(vis):
            r = pygame.Rect(90, 130 + i * 106, 820, 94)
            done = a['id'] in self.achieved
            pygame.draw.rect(sc, (40, 70, 44) if done else (38, 45, 40), r, border_radius=12)
            pygame.draw.rect(sc, (250, 210, 60) if done else (90, 100, 92), r, 3, border_radius=12)
            self.draw_ach_icon(a['id'], r.x + 50, r.centery, 76, done)
            self.text(a['title'], self.f_m, (255, 255, 255) if done else (190, 195, 190), (r.x + 104, r.y + 18))
            self.text(('[SECRET] ' if a.get('secret') else '') + a['sub'], self.f_s, (200, 220, 200) if done else (140, 150, 142), (r.x + 104, r.y + 54))
            self.text(f"+{a['reward']} coins", self.f_m, (250, 210, 60) if done else (150, 150, 120), (r.right - 20 - 140, r.y + 16))
            self.text("UNLOCKED" if done else "LOCKED", self.f_s, (120, 240, 120) if done else (150, 150, 150), (r.right - 20 - 140, r.y + 54))
        back = pygame.Rect(350, 810, 300, 70)
        pygame.draw.rect(sc, (70, 150, 70) if back.collidepoint(mp) else (45, 110, 50), back, border_radius=12)
        pygame.draw.rect(sc, (160, 230, 150), back, 3, border_radius=12)
        self.text("BACK", self.f_m, (255, 255, 255), back.center, True)

    def draw_custom(self):
        sc = self.screen
        sc.fill((25, 40, 28))
        self.text("CUSTOM ZOMBIE SHOP", self.f_l, (120, 210, 90), (W // 2 + 130, 45), True)
        self.text(f"Coins: {self.coins}", self.f_m, (250, 210, 60), (W // 2 + 130, 92), True)
        mp = mouse_pos()
        for i, (tr, name) in enumerate(zip(self.custom_tabs(), ("PAGE 1", "PAGE 2"))):
            active = i == self.custom_page
            pygame.draw.rect(sc, (60, 100, 60) if active else (35, 55, 38), tr, border_radius=8)
            pygame.draw.rect(sc, (160, 230, 150) if active else (90, 105, 92), tr, 2, border_radius=8)
            self.text(name, self.f_s, (255, 255, 255), tr.center, True)
        for key, r in zip(self.custom_keys_page(), self.custom_cards()):
            c, u, lvl = CUSTOM[key], UNITS[key], self.upg[key]
            owned = key in self.owned
            pygame.draw.rect(sc, (40, 60, 42), r, border_radius=12)
            pygame.draw.rect(sc, u['col'], r, 3, border_radius=12)
            self.blit_zombie(key, r.x + 30, r.y + 36, 0, (self.t * 1.4) % 1.0, max_px=66)
            self.text(c['title'], self.f_l, (255, 255, 255), (r.x + 56, r.y + 4))
            self.text(f'"{c["desc"]}"', self.f_s, (200, 220, 200), (r.x + 56, r.y + 56))
            self.text(f"HP {unit_hp(key, self.upg):g}   |   Speed {u['speed']:g} px/s ({u['speed'] / UNITS['zombie']['speed']:.2f}x zombie)"
                      f"   |   ${c['spawn_cost']} per zombie in a match", self.f_s, (255, 255, 255), (r.x + 20, r.y + 82))
            effect = c['effect']
            if key == 'stun':
                effect = (f"Every {stun_cd(self.upg):g}s: spits on a nearby tower (within {STUN_RANGE} px), "
                          f"stunning it for {STUN_TIME:g}s")
            if key == 'ghost':
                effect = f"Every {phase_cd(self.upg):g}s: turns intangible for {PHASE_TIME:g}s - towers can't hurt it"
            elif key == 'brood':
                effect = f"Every {brood_cd(self.upg):g}s: spawns {BROOD_COUNT} zombies for free"
            elif key == 'confuser':
                effect = f"YOU trigger his 2 abilities in a match: Illusionary Path ({ILLUSION_TIME:g}s, once) + Zombie-Alike ({ALIKE_CD:g}s cooldown)"
            if effect:
                self.text(effect, self.f_s, (255, 190, 230) if key not in ('stun', 'ghost', 'brood', 'confuser') else (170, 255, 120), (r.x + 20, r.y + 102))
            pygame.draw.line(sc, (80, 110, 80), (r.x + 20, r.y + 126), (r.right - 20, r.y + 126), 2)
            b = self.custom_buy_rect(r)
            if owned:
                bcol, label = (60, 70, 62), "OWNED"
            else:
                ok = self.coins >= c['price']
                bcol = ((80, 150, 80) if b.collidepoint(mp) else (55, 115, 60)) if ok else (90, 50, 50)
                label = f"BUY  {c['price']}"
            pygame.draw.rect(sc, bcol, b, border_radius=8)
            pygame.draw.rect(sc, (255, 255, 255), b, 2, border_radius=8)
            self.text(label, self.f_m, (255, 255, 255), b.center, True)
            mx = max_up(key)
            if not owned:
                self.text("Buy this zombie to unlock its upgrades", self.f_s, (150, 160, 150), (r.x + 20, r.y + 150))
                continue
            d = UPGRADES[key]
            if lvl >= mx:
                desc = f"HP {upg_value(key, lvl):g}  (MAX)"
            else:
                desc = f"HP {upg_value(key, lvl):g}  ->  {upg_value(key, lvl + 1):g}   (+{d['step']:g} per level)"
            self.text(desc, self.f_s, (200, 220, 200), (r.x + 20, r.y + 136))
            if key == 'stun':
                if lvl >= mx:
                    cdt = f"Spit cooldown {stun_cd_at(lvl):g}s  (MAX)"
                else:
                    cdt = f"Spit cooldown {stun_cd_at(lvl):g}s  ->  {stun_cd_at(lvl + 1):g}s   (-{STUN_CD_STEP:g}s per level)"
                self.text(cdt, self.f_s, (170, 255, 120), (r.x + 20, r.y + 156))
            elif key == 'confuser':
                tg = "2 targets" if lvl >= ALIKE_LVL2 else f"1 target  (2 targets at Lv {ALIKE_LVL2})"
                self.text(f"Zombie-Alike hijacks a tower: {tg}", self.f_s, (170, 255, 120), (r.x + 20, r.y + 156))
            elif key in ('ghost', 'brood'):
                fn_, lab_, st_ = (phase_cd, "Phase cooldown", PHASE_CD_STEP) if key == 'ghost' else (brood_cd, "Brood cooldown", BROOD_CD_STEP)
                cur_ = (PHASE_CD_BASE if key == 'ghost' else BROOD_CD_BASE) - st_ * lvl
                if lvl >= mx:
                    cdt = f"{lab_} {cur_:.2f}s  (MAX)".replace('.00s', 's')
                else:
                    cdt = f"{lab_} {cur_:g}s  ->  {round(cur_ - st_, 2):g}s   (-{st_:g}s per level)"
                self.text(cdt, self.f_s, (170, 255, 120), (r.x + 20, r.y + 156))
            for j in range(mx):
                col = (250, 210, 60) if j < lvl else (70, 85, 70)
                pygame.draw.rect(sc, col, (r.x + 20 + j * 24, r.y + 180, 20, 14))
            self.text(f"Lv {lvl}/{mx}", self.f_s, (255, 255, 255), (r.x + 20 + mx * 24 + 8, r.y + 178))
            b = self.custom_up_rect(r)
            if lvl >= mx:
                bcol, label = (70, 70, 80), "MAXED"
            else:
                cost = upg_cost(key, lvl)
                ok = self.coins >= cost
                bcol = ((80, 150, 80) if b.collidepoint(mp) else (55, 115, 60)) if ok else (90, 50, 50)
                label = f"UPGRADE  {cost}"
            pygame.draw.rect(sc, bcol, b, border_radius=8)
            pygame.draw.rect(sc, (255, 255, 255), b, 2, border_radius=8)
            self.text(label, self.f_m, (255, 255, 255), b.center, True)
        back = pygame.Rect(350, 810, 300, 70)
        pygame.draw.rect(sc, (70, 150, 70) if back.collidepoint(mp) else (45, 110, 50), back, border_radius=12)
        pygame.draw.rect(sc, (160, 230, 150), back, 3, border_radius=12)
        self.text("BACK", self.f_m, (255, 255, 255), back.center, True)

    def draw_wheel(self, angle, highlight):
        sc = self.screen
        cx, cy, R = 500, 500, 300
        n = len(MAPS)
        step = 360 / n
        pygame.draw.circle(sc, (15, 20, 15), (cx, cy), R + 14)
        for i, m in enumerate(MAPS):
            a0 = math.radians(angle + i * step)
            a1 = math.radians(angle + (i + 1) * step)
            pts = [(cx, cy)] + [(cx + R * math.cos(a0 + (a1 - a0) * k / 20),
                                 cy + R * math.sin(a0 + (a1 - a0) * k / 20)) for k in range(21)]
            pygame.draw.polygon(sc, m.col, pts)
            pygame.draw.polygon(sc, (15, 20, 15), pts, 3)
        for i, m in enumerate(MAPS):
            mid = math.radians(angle + (i + 0.5) * step)
            lx, ly = cx + R * 0.64 * math.cos(mid), cy + R * 0.64 * math.sin(mid)
            self.text(m.name, self.f_m, (255, 255, 255), (lx, ly - 11), True)
            self.text(f"x{m.mult:.1f} coins", self.f_s, (255, 255, 255), (lx, ly + 12), True)
        if highlight is not None:
            a0 = math.radians(angle + highlight * step)
            a1 = math.radians(angle + (highlight + 1) * step)
            pts = [(cx, cy)] + [(cx + R * math.cos(a0 + (a1 - a0) * k / 20),
                                 cy + R * math.sin(a0 + (a1 - a0) * k / 20)) for k in range(21)]
            pygame.draw.polygon(sc, (255, 255, 255), pts, 6)
        pygame.draw.circle(sc, (15, 20, 15), (cx, cy), 36)
        pygame.draw.circle(sc, (250, 210, 60), (cx, cy), 36, 4)
        pygame.draw.polygon(sc, (255, 255, 255), [(cx - 24, cy - R - 38), (cx + 24, cy - R - 38), (cx, cy - R + 8)])
        pygame.draw.polygon(sc, (15, 20, 15), [(cx - 24, cy - R - 38), (cx + 24, cy - R - 38), (cx, cy - R + 8)], 3)

    def draw_spin(self):
        sc = self.screen
        sc.fill((25, 40, 28))
        if self.spin_t < SPIN_T + HOLD_T:
            u = min(1.0, self.spin_t / SPIN_T)
            angle = self.spin_final * (1 - (1 - u) ** 3)     # fast start, slow stop
            done = self.spin_t >= SPIN_T
            self.text("Map selected!" if done else "Choosing your map...", self.f_l,
                      (250, 210, 60) if done else (255, 255, 255), (W // 2, 70), True)
            self.draw_wheel(angle, self.map_idx if done else None)
        else:
            m = self.map
            self.text("YOUR MAP", self.f_l, (255, 255, 255), (W // 2, 120), True)
            self.text(m.name, self.f_xl, m.col, (W // 2, 210), True)
            self.text(f"Coin multiplier: x{m.mult:.1f}", self.f_l, (250, 210, 60), (W // 2, 295), True)
            self.minimap(m, pygame.Rect(300, 360, 400, 400))
            self.text("green = enemy spawn   red = your target", self.f_s, (200, 220, 200), (W // 2, 785), True)
            left = max(0, math.ceil(AUTO_T - self.spin_t))
            self.text(f"Click to start  (auto-start in {left})", self.f_m, (255, 255, 255), (W // 2, 840), True)

    def draw_play(self):
        sc = self.screen
        mp_ = self.map
        sc.blit(get_map_bg(mp_), (0, 0))
        for i, cs in enumerate(CLOUDS):                           # drifting cloud shadows
            sc.blit(cs, (int((self.t * (10 + 3 * i) + i * 430) % (W + 400)) - 380, int(150 + i * 260 + 30 * math.sin(self.t * 0.15 + i))))
        if self.illusion_fade > 0:                                # Illusionary Path: the real road fades, a straight one appears
            f_ = self.illusion_fade
            gcol = THEMES[mp_.name]['ground']
            veil = pygame.Surface((W, H), pygame.SRCALPHA)
            for a_, b_, _l, _s in mp_.seg:
                pygame.draw.line(veil, (gcol[0], gcol[1], gcol[2], int(215 * f_)), (int(a_[0]), int(a_[1])), (int(b_[0]), int(b_[1])), 62)
            for pt_ in mp_.path[1:-1]:
                pygame.draw.circle(veil, (gcol[0], gcol[1], gcol[2], int(215 * f_)), (int(pt_[0]), int(pt_[1])), 31)
            stm = self.straight or self.fade_straight
            if stm is not None:
                a_, b_ = stm.path[0], stm.path[1]
                pygame.draw.line(veil, (70, 40, 110, int(235 * f_)), (int(a_[0]), int(a_[1])), (int(b_[0]), int(b_[1])), 54)
                pygame.draw.line(veil, (190, 140, 255, int(235 * f_)), (int(a_[0]), int(a_[1])), (int(b_[0]), int(b_[1])), 44)
                ln_ = b_[0] - a_[0]
                for k_ in range(0, int(abs(ln_)), 40):                # shimmering dashes
                    xx = a_[0] + (1 if ln_ > 0 else -1) * ((k_ + self.t * 120) % abs(ln_))
                    pygame.draw.line(veil, (255, 235, 255, int(220 * f_)), (int(xx), int(a_[1])), (int(xx + (10 if ln_ > 0 else -10)), int(a_[1])), 3)
            sc.blit(veil, (0, 0))
        if self.phase == 'plan' or self.show_heat:
            self.draw_heat()
        sx, sy = mp_.path[0]
        self.text("SPAWN", self.f_s, (255, 255, 255), (min(max(sx, 30), W - 30), sy - 36), True, shadow=True)
        # base
        bx, by = self.pmap.path[-1]
        hit = self.base_flash > 0
        ox = int(math.sin(self.t * 70) * 3) if hit else 0        # shake when hit
        pygame.draw.rect(sc, (230, 90, 80) if hit else (150, 50, 50), (bx - 34 + ox, by - 34, 68, 68), border_radius=6)
        pygame.draw.rect(sc, (230, 200, 200), (bx - 34 + ox, by - 34, 68, 68), 3, border_radius=6)
        self.text("BASE", self.f_s, (255, 255, 255), (bx, by), True)

        # ranges
        mp = mouse_pos()
        for t in self.towers:
            if self.show_ranges or math.dist(mp, t.pos) < 22:
                pygame.draw.circle(sc, (255, 255, 255), t.pos, t.stats[2], 1)
                if t.kind == 'shot':                                           # show the firing cone
                    hh = math.radians(t.stats[3] / 2)
                    for sgn in (-1, 1):
                        pygame.draw.line(sc, (255, 200, 90), t.pos,
                                         (t.pos[0] + math.cos(t.aim + sgn * hh) * t.stats[2], t.pos[1] + math.sin(t.aim + sgn * hh) * t.stats[2]), 1)

        # zombies
        self.draw_fx(0)
        for z in sorted(self.zombies, key=lambda z: z.dist):
            self.draw_zombie(z)
        for z in self.zombies:
            self.draw_hpbar(z)
        self.draw_fx(1)

        # shots
        for a, b, _, k in self.shots:
            if k == 'alike':
                pygame.draw.line(sc, (230, 120, 255), a, b, 5)
                pygame.draw.line(sc, (255, 230, 255), a, b, 2)
                pygame.draw.circle(sc, (230, 120, 255), (int(b[0]), int(b[1])), 8)
            elif k == 'spit':
                pygame.draw.line(sc, (120, 255, 80), a, b, 5)
                pygame.draw.circle(sc, (120, 255, 80), b, 9)
            else:
                pygame.draw.line(sc, {'cmd': (255, 160, 60), 'cryo': (150, 225, 255)}.get(k, (255, 240, 120)), a, b, 2)

        # towers
        for t in self.towers:
            x, y = t.pos
            self.draw_tower(t)
            self.text(TOWER_NAMES[t.kind], self.f_s, (255, 255, 255), (x, y - 32), True, shadow=True)
            if t.stun > 0:
                pygame.draw.circle(sc, (120, 255, 80), t.pos, 27, 3)
                self.text(f"STUNNED {t.stun:.1f}s", self.f_xs, (140, 255, 100), (x, y + 34), True)

        # top HUD
        pygame.draw.rect(sc, (20, 25, 20), (0, 0, W, 56))
        self.text(f"Wave {self.wave}/{self.total_waves}", self.f_m, (255, 255, 255), (12, 14))
        self.text(f"${self.money}", self.f_m, (110, 230, 110), (140, 14))
        self.text(f"Coins: {self.coins}", self.f_m, (250, 210, 60), (235, 14))
        label = {'medium': "MED | ", 'hard': "HARD | "}.get(self.mode, "") + f"{mp_.name} x{mp_.mult:.1f}"
        self.text(label, self.f_xs, (200, 220, 200), (385, 14))
        self.text(f"Kill bonus: +{self.bonus_coins()} coins", self.f_s, (250, 210, 60), (385, 33))
        self.text("BASE", self.f_m, (255, 255, 255), (565, 14))
        pygame.draw.rect(sc, (80, 0, 0), (625, 16, 355, 24))
        pygame.draw.rect(sc, (210, 50, 50), (625, 16, 355 * self.base_hp / BASE_HP, 24))
        pygame.draw.rect(sc, (255, 255, 255), (625, 16, 355, 24), 2)
        self.text(f"{self.base_hp}/{BASE_HP}", self.f_s, (255, 255, 255), (802, 28), True)

        # wave messages / banners
        if self.msg_timer > 0:
            for i, m in enumerate(self.messages):
                self.text(m, self.f_m, (255, 230, 120), (W // 2, 78 + i * 26), True, shadow=True)
        if self.complete_timer > 0:
            txt = "FINAL WAVE COMPLETE!" if self.wave >= self.total_waves else f"WAVE {self.wave} COMPLETE!"
            self.text(txt, self.f_l, (250, 210, 60), (W // 2, 800), True)

        # bottom panel
        pygame.draw.rect(sc, (20, 25, 20), (0, 850, W, 150))
        for name, tr in self.tab_rects.items():
            active = name == self.tab
            pygame.draw.rect(sc, (60, 100, 60) if active else (35, 45, 37), tr, border_radius=6)
            pygame.draw.rect(sc, (160, 230, 150) if active else (80, 100, 82), tr, 2, border_radius=6)
            if name == 'normal':
                label = "NORMAL"
            elif name == 'special':
                label = f"SPECIAL ({sum(1 for k in self.kinds if k in SPECIAL_KINDS)})"
            elif name == 'elite':
                label = f"ELITE ({sum(1 for k in self.kinds if k in ELITE_KINDS)})"
            else:
                label = f"CUSTOM ({sum(1 for k in CUSTOM_KEYS if k in self.owned)})"
            self.text(label, self.f_s, (255, 255, 255) if active else (150, 165, 150), tr.center, True)
        rb = self.research_btn
        pygame.draw.rect(sc, (30, 90, 120) if self.research_open else (30, 46, 60), rb, border_radius=6)
        pygame.draw.rect(sc, (140, 220, 255) if self.research_open else (80, 110, 130), rb, 2, border_radius=6)
        self.text(f"RESEARCH [T] ({len(self.tech)})", self.f_s, (255, 255, 255), rb.center, True)
        if not self.buttons:
            msg = {'custom': "No custom zombies yet - buy some in the Custom Zombie Shop (main menu)",
                   'special': "No special zombies in this wave (they appear in Medium and Hard mode)",
                   'elite': "No elite zombies in this wave (they appear in Hard mode)",
                   'normal': "No normal zombies this wave"}[self.tab]
            self.text(msg, self.f_s, (150, 165, 150), (410, 935), True)
        small = len(self.buttons) > 5
        fb = self.f_xs if small else self.f_s
        fn = self.f_s if small else self.f_m
        for i, (k, r) in enumerate(self.buttons):
            u = UNITS[k]
            hp_line = (f"HP {unit_hp(k, self.upg):g} +${u['reward']}", (200, 200, 200))
            if k in CUSTOM:
                cost = self.price(CUSTOM[k]['spawn_cost'])
                usable = self.phase == 'run' and self.money >= cost
                lines = [hp_line, (custom_tag(k, self.upg), (150, 220, 255)), (f"Cost: ${cost}", (240, 220, 120))]
            else:
                fr = self.free.get(k, 0)
                pn, pp = self.paid.get(k, (0, 0))
                usable = self.phase == 'run' and (fr > 0 or (pn > 0 and self.money >= self.price(pp)))
                lines = [hp_line, (f"Free: {fr}", (120, 240, 120))]
                if k in self.paid:
                    lines.append((f"Paid: {pn} x ${self.price(pp)}", (240, 220, 120)))
            col = (55, 75, 55) if usable else (45, 45, 45)
            if usable and r.collidepoint(mp):
                col = (80, 110, 80)
            pygame.draw.rect(sc, col, r, border_radius=8)
            pygame.draw.rect(sc, u['col'], r, 3, border_radius=8)
            self.blit_zombie(k, r.x + 17, r.y + 22, 0, (self.t * 1.4) % 1.0, max_px=40)
            nm = f"[{i + 1}] {u['name']}"
            self.text(nm, fn if len(nm) <= 10 else self.f_s, (255, 255, 255), (r.x + 34, r.y + 10))
            for j, (t, c) in enumerate(lines):
                self.text(t, fb, c, (r.x + 8, r.y + 40 + j * 20))

        # active-boost chips (top-left) + boosts tab/panel
        chips = []
        if self.mod_id and self.phase == 'run':
            chips.append((f"{MODIFIERS[self.mod_id]['name']}: {MODIFIERS[self.mod_id]['desc']}", MODIFIERS[self.mod_id]['col']))
        if self.spit_t > 0:
            chips.append((f"Big Spit  {self.spit_t:.1f}s", BOOSTS['spit']['col']))
        if self.boots_t > 0:
            chips.append((f"Heaven Boots  {self.boots_t:.1f}s", BOOSTS['boots']['col']))
        if self.big_t > 0:
            chips.append((f"Bigger Zombies  {self.big_t:.1f}s", BOOSTS['big']['col']))
        if self.drunk_t > 0:
            chips.append((f"Drunk Towers x{self.drunk_n} ({round(DRUNK_MISS * self.drunk_n * 100)}% miss)  {self.drunk_t:.1f}s", BOOSTS['drunk']['col']))
        for i, (txt, col) in enumerate(chips):
            self.text(txt, self.f_s, col, (12, 66 + i * 22))
        bb = self.boost_btn
        pygame.draw.rect(sc, (120, 80, 170) if self.boost_open else (45, 38, 64), bb, border_radius=6)
        pygame.draw.rect(sc, (210, 170, 255) if self.boost_open else (110, 96, 140), bb, 2, border_radius=6)
        self.text(f"BOOSTS [E]  ({sum(self.boosts.values())})", self.f_s, (255, 255, 255), bb.center, True)
        if self.boost_open:
            pr = pygame.Rect(480, 548, 510, 300)
            pygame.draw.rect(sc, (24, 20, 34), pr, border_radius=12)
            pygame.draw.rect(sc, (210, 170, 255), pr, 3, border_radius=12)
            self.text("BOOSTS  -  click USE or press 1-4   (E to close)", self.f_s, (230, 210, 255), (pr.centerx, pr.y + 20), True)
            for i, (key, r) in enumerate(self.boost_panel_rows()):
                bdef = BOOSTS[key]
                n = self.boosts.get(key, 0)
                ok, status = self.boost_state(key)
                pygame.draw.rect(sc, (40, 34, 58), r, border_radius=8)
                pygame.draw.rect(sc, bdef['col'], r, 2, border_radius=8)
                self.draw_boost_icon(key, r.x + 30, r.centery, 34)
                self.text(f"[{i + 1}] {bdef['name']}", self.f_m, (255, 255, 255), (r.x + 58, r.y + 6))
                self.text(f"{status}", self.f_xs, (200, 190, 225), (r.x + 58, r.y + 34))
                self.text(f"x{n}", self.f_m, (250, 210, 60) if n else (120, 110, 130), (r.right - 150, r.y + 14))
                ur = self.boost_use_rect(r)
                usable = n > 0 and ok
                pygame.draw.rect(sc, ((90, 160, 90) if ur.collidepoint(mp) else (60, 120, 66)) if usable else (60, 56, 66), ur, border_radius=8)
                pygame.draw.rect(sc, (255, 255, 255) if usable else (110, 106, 118), ur, 2, border_radius=8)
                self.text("USE", self.f_m, (255, 255, 255) if usable else (130, 126, 140), ur.center, True)
        if self.spit_flash > 0:                             # Big Spit screen flash
            veil = pygame.Surface((W, H), pygame.SRCALPHA)
            veil.fill((120, 255, 80, int(90 * self.spit_flash / 0.45)))
            sc.blit(veil, (0, 0))
        # speed + formation buttons
        r = self.speed_btn
        fast = self.speed > 1
        col = (200, 120, 40) if fast else (55, 75, 55)
        if r.collidepoint(mp):
            col = (225, 145, 60) if fast else (80, 110, 80)
        pygame.draw.rect(sc, col, r, border_radius=8)
        pygame.draw.rect(sc, (255, 190, 110) if fast else (160, 230, 150), r, 3, border_radius=8)
        if self.speeds:
            self.text(f"SPEED {self.speed}x", self.f_m, (255, 255, 255), r.center, True)
        else:
            self.text("SPEED 1x - locked", self.f_s, (170, 180, 170), r.center, True)
        r = self.form_btn
        spread = self.formation == 'spread'
        col = (40, 90, 120) if spread else (60, 60, 40)
        if r.collidepoint(mp):
            col = (60, 120, 150) if spread else (90, 90, 56)
        pygame.draw.rect(sc, col, r, border_radius=8)
        pygame.draw.rect(sc, (140, 220, 255) if spread else (220, 210, 120), r, 3, border_radius=8)
        self.text("SPREAD [G]" if spread else "CLUSTER [G]", self.f_s, (255, 255, 255), (r.centerx, r.centery - 8), True)
        self.text("spaced out" if spread else "arrive together", self.f_xs, (200, 210, 220), (r.centerx, r.centery + 11), True)
        xb = self.exit_btn
        pygame.draw.rect(sc, (190, 70, 70) if xb.collidepoint(mp) else (140, 45, 45), xb, border_radius=8)
        pygame.draw.rect(sc, (255, 170, 170), xb, 3, border_radius=8)
        self.text("EXIT", self.f_m, (255, 255, 255), xb.center, True)
        self.draw_overlays(mp)

    def draw_result(self):
        sc = self.screen
        veil = pygame.Surface((W, H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 190))
        sc.blit(veil, (0, 0))
        win, earned, base, bonus = self.result
        if win:
            self.text("VICTORY!", self.f_xl, (110, 240, 110), (W // 2, 340), True)
            self.text("The enemy base has been destroyed", self.f_m, (255, 255, 255), (W // 2, 410), True)
        else:
            self.text("DEFEAT", self.f_xl, (240, 80, 80), (W // 2, 340), True)
            self.text(f"The base survived all {self.total_waves} waves", self.f_m, (255, 255, 255), (W // 2, 410), True)
        self.text(f"+{earned + bonus} coins", self.f_l, (250, 210, 60), (W // 2, 490), True)
        self.text(f"{self.cfg['name']} reward: {base} x {self.map.mult:.1f} ({self.map.name}) = {earned}", self.f_s, (200, 200, 200), (W // 2, 535), True)
        self.text(f"Kill bonus: ${self.money_earned} earned = {bonus}", self.f_s, (200, 200, 200), (W // 2, 560), True)
        y = 590
        for aid in self.new_achs:
            msg = f"Achievement: {ACH[aid]['title']}  +{ACH[aid]['reward']} coins"
            wdt = self.f_s.render(msg, True, (250, 210, 60)).get_width()
            self.draw_ach_icon(aid, int(W // 2 - wdt / 2 - 24), y, 34, True)
            self.text(msg, self.f_s, (250, 210, 60), (W // 2, y), True)
            y += 36
        self.text(f"Total coins: {self.coins}", self.f_m, (250, 210, 60), (W // 2, y + 25), True)
        self.text("Click anywhere to return to the main menu", self.f_s, (200, 200, 200), (W // 2, y + 90), True)


# ======================================================================
#  FULL SCREEN - the 1000x1000 game canvas is scaled to fill ANY display
# ======================================================================
VIEW = None


class View:
    """Opens a full-screen window and scales the square game canvas to the biggest size that fits,
    centred. On wide/tall screens the spare space is filled with a dimmed, blurred copy of the game."""

    def __init__(self):
        info = pygame.display.Info()
        self.desktop = (info.current_w, info.current_h)
        self.full = True
        self.win = None
        self.canvas = None
        self.frames = 0
        self.open(True)

    def open(self, full):
        self.full = full
        try:
            if WEB:                                  # browser/phone: fixed canvas, the page scales it to fit
                self.win = pygame.display.set_mode((W, H))
            elif full:
                self.win = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            else:
                side = int(min(self.desktop) * 0.9) or W
                self.win = pygame.display.set_mode((side, side))
        except Exception:
            self.win = pygame.display.set_mode((W, H))
        if self.canvas is None:
            self.canvas = pygame.Surface((W, H)).convert()
        ww, wh = self.win.get_size()
        self.scale = min(ww / W, wh / H)
        self.size = (max(1, int(W * self.scale)), max(1, int(H * self.scale)))
        self.ox, self.oy = (ww - self.size[0]) // 2, (wh - self.size[1]) // 2
        self.bars = self.size[0] < ww - 1 or self.size[1] < wh - 1
        self.ambient = None

    def toggle(self):
        if not WEB:
            self.open(not self.full)

    def to_logical(self, p):
        return ((p[0] - self.ox) / self.scale, (p[1] - self.oy) / self.scale)

    def present(self):
        win = self.win
        if self.bars:
            if self.ambient is None or self.frames % 8 == 0:        # blurred, dimmed copy fills the side bars
                tiny = pygame.transform.smoothscale(self.canvas, (24, 24))
                amb = pygame.transform.smoothscale(tiny, win.get_size())
                amb.fill((70, 70, 70), special_flags=pygame.BLEND_RGB_MULT)
                self.ambient = amb
            win.blit(self.ambient, (0, 0))
        if self.size == (W, H):
            win.blit(self.canvas, (self.ox, self.oy))
        else:
            win.blit(pygame.transform.smoothscale(self.canvas, self.size), (self.ox, self.oy))
        pygame.display.flip()
        self.frames += 1


def mouse_pos():
    """Mouse position in game (1000x1000) coordinates, whatever the screen size."""
    p = pygame.mouse.get_pos()
    return VIEW.to_logical(p) if VIEW else p


def present():
    if VIEW:
        VIEW.present()
    else:
        pygame.display.flip()


async def main():
    global VIEW
    pygame.init()
    pygame.display.set_caption("Zombie Rush")
    VIEW = View()
    pygame.mouse.set_visible(True)
    clock = pygame.time.Clock()
    g = Game(VIEW.canvas)
    while True:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for e in pygame.event.get():
            if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                e.pos = VIEW.to_logical(e.pos)               # clicks arrive in game coordinates
            elif e.type == pygame.KEYDOWN and e.key == pygame.K_F11:
                VIEW.toggle()
                continue
            g.handle(e)
        g.update(dt)
        g.draw()
        await asyncio.sleep(0)


asyncio.run(main())